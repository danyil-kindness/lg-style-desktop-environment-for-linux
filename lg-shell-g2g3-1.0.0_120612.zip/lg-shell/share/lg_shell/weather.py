# -*- coding: utf-8 -*-
"""Погода для виджета LG G2/G3: wttr.in с кэшем и мягким фолбэком.

Запрос выполняется в фоновом потоке и не задерживает домашний экран.
Если сети нет, виджет показывает «--°» и «Погода недоступна»; это не
ломает запуск оболочки.
"""

import json
import os
import threading
import time
import urllib.parse
import urllib.request

from gi.repository import GLib

from . import config, i18n

CACHE_TTL = 30 * 60
_CACHE_DIR = os.path.join(
    os.environ.get("XDG_CACHE_HOME", os.path.join(os.path.expanduser("~"), ".cache")),
    "lg-shell",
)
_CACHE_FILE = os.path.join(_CACHE_DIR, "weather.json")

_CONDITIONS = {
    "clear": "Ясно",
    "sunny": "Солнечно",
    "partly cloudy": "Переменная облачность",
    "cloudy": "Облачно",
    "overcast": "Пасмурно",
    "mist": "Туман",
    "fog": "Туман",
    "patchy rain nearby": "Местами дождь",
    "patchy rain possible": "Возможен дождь",
    "light rain": "Небольшой дождь",
    "light drizzle": "Морось",
    "moderate rain": "Дождь",
    "heavy rain": "Сильный дождь",
    "light snow": "Небольшой снег",
    "moderate snow": "Снег",
    "heavy snow": "Сильный снег",
    "thundery outbreaks possible": "Возможна гроза",
    "thunderstorm": "Гроза",
}


def city_name():
    """Город из config.ini; пустая строка означает автоопределение по IP."""
    value = (config.get("weather", "city", "auto") or "").strip()
    if value.lower() in ("", "auto", "авто"):
        return ""
    return value


def _cache_key():
    return city_name() or "auto"


def clear_cache():
    try:
        os.unlink(_CACHE_FILE)
    except OSError:
        pass


def _read_cache():
    try:
        with open(_CACHE_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
        if str(data.get("city", "auto")).lower() != _cache_key().lower():
            return None
        if time.time() - float(data.get("ts", 0)) <= CACHE_TTL:
            return data
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    return None


def _write_cache(data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = _CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, _CACHE_FILE)
    except OSError:
        pass


def cached():
    return _read_cache()


def _translate(desc):
    key = (desc or "").strip().lower()
    ru = _CONDITIONS.get(key)
    if ru:
        return i18n.gettext(ru)
    return desc or ""


def _parse(text):
    parts = [p.strip() for p in text.strip().split("|")]
    if len(parts) < 2 or not parts[0]:
        return None
    raw_temp = parts[0].replace("°C", "°").replace("+", "").strip()
    desc = _translate(parts[1])
    location = parts[2] if len(parts) > 2 else ""
    location = location.split(",")[0].strip()
    return {
        "temp": raw_temp or "--°",
        "desc": desc or i18n.gettext("Погода"),
        "location": location or city_name(),
        "city": _cache_key(),
        "ts": time.time(),
    }


_request_seq = 0


def fetch_async(callback):
    """callback(data|None) вызывается в главном потоке GTK."""
    global _request_seq
    _request_seq += 1
    seq = _request_seq

    def work():
        data = None
        try:
            city = city_name()
            path = urllib.parse.quote(city, safe="") if city else ""
            req = urllib.request.Request(
                "https://wttr.in/%s?format=%%t|%%C|%%l" % path,
                headers={"User-Agent": "lg-shell/1.0"},
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                text = resp.read().decode("utf-8", "replace")
            data = _parse(text)
        except Exception:
            data = None
        # пока запрос ходил в сеть, пользователь мог выбрать другой город
        if seq != _request_seq:
            return
        if data:
            _write_cache(data)
        GLib.idle_add(lambda: (callback(data), False)[1])

    threading.Thread(target=work, daemon=True).start()

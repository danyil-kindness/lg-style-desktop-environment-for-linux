# -*- coding: utf-8 -*-
"""Нижний док LG: закреплённые и запущенные приложения."""

from gi.repository import Gdk, Gio, GLib, Gtk, Pango

from . import apps, config, theme, widgets, windows, x11
from .i18n import _


class DockApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.lgux.Dock")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(DockWindow(self))
        self.win.present()


class DockWindow(widgets.ThemedWindow):
    MARGIN = 8

    def __init__(self, app):
        super().__init__()
        self.set_title("LG Dock")
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        widgets.set_rgba(self)

        cfg = config.load()
        self.icon_size = cfg.getint("dock", "icon_size", fallback=48)
        self.autohide = cfg.getboolean("dock", "autohide", fallback=False)
        pinned = cfg.get("dock", "pinned").strip()
        if not pinned:
            pinned = config.default_pinned()
            config.set_option("dock", "pinned", pinned)
        self.pinned = [p for p in pinned.split(",") if p]

        self.box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.box.set_margin_top(6)
        self.box.set_margin_bottom(0)
        self.box.set_margin_start(14)
        self.box.set_margin_end(14)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.pack_start(self.box, False, False, 0)
        self.home_bar = Gtk.DrawingArea()
        self.home_bar.set_size_request(46, 4)
        self.home_bar.set_halign(Gtk.Align.CENTER)
        self.home_bar.set_margin_bottom(5)
        self.home_bar.connect("draw", self._draw_home_bar)
        outer.pack_start(self.home_bar, False, False, 0)
        self.add(outer)
        self.get_style_context().add_class("lg-dock")
        self.css_prov = widgets.css_provider(self.build_css())
        self.use_css(self.css_prov)

        self.connect("button-press-event", self._on_press)
        self._signature = None
        self.show_all()
        self._refresh()
        self._position()
        GLib.timeout_add_seconds(2, self._tick)

        self._app_monitor = Gio.AppInfoMonitor.get()
        self._app_monitor.connect("changed", lambda *_: GLib.idle_add(self._invalidate))

        # Док убирается, когда активное окно перекрывает его (видео во весь
        # экран, развёрнутое приложение) и возвращается при наведении вниз.
        GLib.timeout_add(400, self._autohide_poll)
        GLib.timeout_add(700, self._keep_raised)
        self.connect("enter-notify-event", lambda *_: self._show_dock())

    # ---------------------------------------------------------------- тема

    def build_css(self):
        pal = theme.palette()
        return """
            window.lg-dock {{
                background-color: rgba(6,18,22,0.34);
                border: 1px solid rgba(255,255,255,0.18);
                border-radius: 22px;
                box-shadow: 0 8px 26px rgba(0,0,0,0.30);
            }}
            .lg-dockitem {{
                background: transparent; border: none;
                border-radius: 14px; padding: 4px 5px 3px;
            }}
            .lg-dockitem:hover {{
                background-color: rgba(255,255,255,0.15);
            }}
            .lg-dockitem:active {{
                background-color: rgba(255,255,255,0.24);
            }}
            .lg-docklabel {{
                color: #FFFFFF;
                font-size: 9.5px;
                font-weight: 500;
                text-shadow: 0 1px 3px rgba(0,0,0,0.80);
            }}
        """.format()

    def apply_theme(self):
        widgets.update_provider(self.css_prov, self.build_css())
        self._invalidate()

    # ------------------------------------------------------------ наполнение

    def _running_apps(self):
        """[(app, первое окно)] для запущенных приложений."""
        all_apps = apps.list_apps()
        mapping = apps.running_map(all_apps)
        return [(app, mapping[app.app_id]) for app in all_apps
                if app.app_id in mapping]

    def _items(self):
        pal = theme.palette()
        tc = pal["panel_text"]
        running = self._running_apps()
        running_ids = {a.app_id for a, _w in running}
        running_by_id = {a.app_id: w for a, w in running}
        entries = []
        for app_id in self.pinned:
            app = apps.find(app_id)
            if app is None:
                continue
            entries.append((app, app_id in running_ids,
                            running_by_id.get(app_id), tc))
        for app, win in running:
            if app.app_id not in self.pinned:
                entries.append((app, True, win, tc))
        return entries

    def _draw_home_bar(self, area, cr):
        pal = theme.palette()
        cr.set_source_rgba(*theme.hex_rgba(pal["accent"], 0.95))
        theme.round_rect(cr, 0, 0, area.get_allocated_width(),
                         area.get_allocated_height(), 2)
        cr.fill()
        return False

    @staticmethod
    def _run_marker(color):
        area = Gtk.DrawingArea()
        area.set_size_request(16, 3)
        rgba = theme.hex_rgba(color)

        def draw(widget, cr):
            theme.round_rect(cr, 0, 0, widget.get_allocated_width(),
                             widget.get_allocated_height(), 1.5)
            cr.set_source_rgba(*rgba)
            cr.fill()
            return False

        area.connect("draw", draw)
        return area

    def _refresh(self):
        entries = self._items()
        signature = tuple((a.app_id, r) for a, r, _w, _c in entries)
        if signature == self._signature:
            return False
        self._signature = signature
        for child in self.box.get_children():
            self.box.remove(child)
        pal = theme.palette()
        for app, running, win, color in entries:
            btn = Gtk.Button()
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_can_focus(False)
            btn.set_tooltip_text(app.name)
            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
            pb = widgets.squircle_pixbuf(app.icon_pixbuf(self.icon_size),
                                         self.icon_size, pal["tile_bg"],
                                         radius=self.icon_size * 0.24)
            img = Gtk.Image()
            if pb is not None:
                img.set_from_pixbuf(pb)
            else:
                img.set_from_icon_name("application-x-executable", Gtk.IconSize.DIALOG)
            vbox.pack_start(img, False, False, 0)
            label = Gtk.Label(label=app.name)
            label.set_ellipsize(Pango.EllipsizeMode.END)
            label.set_max_width_chars(11)
            label.set_halign(Gtk.Align.CENTER)
            label.get_style_context().add_class("lg-docklabel")
            vbox.pack_start(label, False, False, 0)
            marker = self._run_marker(pal["accent"])
            marker.set_no_show_all(True)
            marker.set_visible(running)
            vbox.pack_start(marker, False, False, 0)
            btn.add(vbox)
            btn.get_style_context().add_class("lg-dockitem")
            btn.connect("button-press-event", self._on_item_press, app)
            btn.connect("clicked", self._on_item_clicked, app)
            btn.dot = marker
            btn.is_running = running
            self.box.pack_start(btn, False, False, 0)
        self.box.show_all()
        self._position()
        return False

    def _invalidate(self):
        apps.invalidate()
        self._signature = None
        self._refresh()
        return False

    def _tick(self):
        if config.is_locked():
            if self.get_visible():
                self.hide()
            return True
        self._refresh()
        return True

    # ------------------------------------------------------------ геометрия

    def _position(self):
        geo = widgets.primary_geometry()
        if self.get_visible():
            self.show_all()
        req = self.get_preferred_width()
        width = req[1]
        height = self.get_preferred_height()[1]
        x = geo.x + max(0, (geo.width - width) // 2)
        y = geo.y + geo.height - height - self.MARGIN
        self.resize(width, height)
        self.move(x, y)
        self._dock_rect = (x, y, width, height)

    def _keep_raised(self):
        """Не дать лаунчеру/панели перекрыть док.

        Лаунчер и док — разные keep-above окна; после показа лаунчера WM
        кладёт его сверху. Периодический raise возвращает док на место.
        Скрытый док не трогаем, чтобы не мешать полноэкранным приложениям.
        """
        try:
            if self.get_visible() and self.get_window() is not None:
                self.get_window().raise_()
        except Exception:
            pass
        return True

    def _autohide_poll(self):
        try:
            if config.is_locked():
                if self.get_visible():
                    self.hide()
                return True
            active = windows.active_app()
            # окно перекрывает док (развёрнутое приложение, видео во весь
            # экран) — док не показываем совсем, даже при наведении вниз:
            # иначе он мешает перематывать видео и работать с окном
            if (windows.is_fullscreen(active) or self._overlapped(active)):
                if self.get_visible():
                    self.hide()
                return True

            _screen, px, py = (Gdk.Display.get_default().get_default_seat()
                               .get_pointer().get_position())
            x, y, w, h = getattr(self, "_dock_rect", (0, 0, 0, 0))
            near = (x - 24 <= px <= x + w + 24) and (y - 24 <= py <= y + h + 24)

            if self.autohide and not near:
                if self.get_visible():
                    self.hide()
            else:
                self._show_dock()
        except Exception:
            pass
        return True

    def _overlapped(self, active):
        """Активное окно перекрывает область дока?"""
        if active is None:
            return False
        try:
            if active.is_minimized():
                return False
        except Exception:
            pass
        geo = windows.geometry(active)
        if geo is None:
            return False
        x, y, w, h = geo
        dx, dy, dw, dh = getattr(self, "_dock_rect", (0, 0, 0, 0))
        if dw <= 0 or dh <= 0:
            return False
        return not (x + w <= dx or x >= dx + dw or y + h <= dy or y >= dy + dh)

    def _show_dock(self):
        if not self.get_visible() or not self.get_mapped():
            self.show_all()
            self.deiconify()
            self._position()

    # ------------------------------------------------------------- события

    def _on_item_clicked(self, _btn, app):
        wins = apps.windows_for(app)
        if wins:
            x11.activate_window(wins[0])
        else:
            app.launch()
        return True

    def _on_item_press(self, btn, ev, app):
        if ev.button == 2:  # средняя — закрыть окна
            for win in apps.windows_for(app):
                x11.close_window(win)
            GLib.timeout_add_seconds(1, self._invalidate)
            return True
        if ev.button == 3:
            menu = Gtk.Menu()
            wins = apps.windows_for(app)
            if wins:
                mi = Gtk.MenuItem(label=_("Активировать окно"))
                mi.connect("activate", lambda *_: x11.activate_window(wins[0]))
                menu.append(mi)
            if app.app_id in self.pinned:
                mi = Gtk.MenuItem(label=_("Открепить"))
                mi.connect("activate", lambda *_: self._unpin(app.app_id))
            else:
                mi = Gtk.MenuItem(label=_("Закрепить"))
                mi.connect("activate", lambda *_: self._pin(app.app_id))
            menu.append(mi)
            if wins:
                mi = Gtk.MenuItem(label=_("Закрыть окна"))
                mi.connect("activate", self._close_windows, app)
                menu.append(mi)
            menu.show_all()
            menu.connect("selection-done", lambda m: GLib.idle_add(m.destroy))
            menu.popup_at_pointer(ev)
            return True
        return False

    def _on_press(self, _w, _ev):
        return False

    def _pin(self, app_id):
        if app_id not in self.pinned:
            self.pinned.append(app_id)
            config.set_option("dock", "pinned", ",".join(self.pinned))
        self._invalidate()

    def _unpin(self, app_id):
        self.pinned = [p for p in self.pinned if p != app_id]
        config.set_option("dock", "pinned", ",".join(self.pinned))
        self._invalidate()

    def _close_windows(self, _mi, app):
        for win in apps.windows_for(app):
            x11.close_window(win)
        GLib.timeout_add_seconds(1, self._invalidate)


def main():
    DockApp().run([])


if __name__ == "__main__":
    main()

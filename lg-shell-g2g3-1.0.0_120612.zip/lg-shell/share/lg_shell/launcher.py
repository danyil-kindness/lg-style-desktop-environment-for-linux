# -*- coding: utf-8 -*-
"""Домашний экран LG G2/G3: виджет, поиск, вкладки и сетка приложений.

Фон — яркие обои без «матового стекла», сверху виджет времени/погоды в духе
LG Weather, ниже поисковая строка и вкладки категорий. Подписи приложений
белые с тенью, как на домашнем экране G2/G3.
"""

import datetime

import cairo

from gi.repository import Gdk, Gio, GLib, Gtk, Pango

from . import apps, config, theme, weather, widgets
from .i18n import _

CATEGORIES = (
    ("all", "Все"),
    ("internet", "Интернет"),
    ("media", "Медиа"),
    ("games", "Игры"),
    ("office", "Офис"),
    ("system", "Система"),
)

# Ключевые слова Categories= из .desktop
CAT_WORDS = {
    "internet": ("network", "webbrowser", "email", "news", "remoteaccess"),
    "media": ("audiovideo", "audio", "video", "graphics", "player",
              "photography", "recorder"),
    "games": ("game",),
    "office": ("office", "texteditor", "spreadsheet", "wordprocessor",
               "presentation", "calendar", "database"),
    "system": ("system", "settings", "utility", "terminalemulator",
               "filemanager", "package", "monitor"),
}


def _app_category(app):
    try:
        raw = (app.info.get_categories() or "").lower()
    except Exception:
        raw = ""
    for key, words in CAT_WORDS.items():
        if any(word in raw for word in words):
            return key
    return "system"


class LauncherApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.lgux.Launcher")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(LauncherWindow(self))
        self.win.toggle()


class LauncherWindow(widgets.ThemedWindow):
    def __init__(self, app):
        super().__init__()
        self.set_title("LG Home")
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(True)
        # Не keep_above: иначе док (тоже keep_above) остаётся под лаунчером.
        # Лаунчер и так поднимается по present() и находится выше обычных окон,
        # а панель и док остаются поверх него.
        self.set_keep_above(False)
        widgets.set_rgba(self)
        self.get_style_context().add_class("lg-launcher")
        self.css_prov = widgets.css_provider(self.build_css())
        self.use_css(self.css_prov)

        self.category = "all"
        self.query = ""
        self.chips = {}
        self.all_apps = apps.list_apps()
        self._apps_reload_id = 0
        self._app_monitor = Gio.AppInfoMonitor.get()
        self._app_monitor.connect("changed", self._on_apps_changed)
        self.visible_apps = list(self.all_apps)

        # фон — яркие обои без матового стекла, как на домашнем экране G2/G3
        self.bg_area = Gtk.DrawingArea()
        self.bg_area.set_hexpand(True)
        self.bg_area.set_vexpand(True)
        self.bg_area.connect("draw", self._draw_bg)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        content.set_margin_top(20)
        content.set_margin_bottom(92)
        content.set_margin_start(30)
        content.set_margin_end(30)

        pal = theme.palette()

        # ------------------------------------------- виджет времени/погоды
        self.weather_card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                                    spacing=0)
        self.weather_card.get_style_context().add_class("lg-weather")
        self.weather_card.set_size_request(-1, 148)

        wleft = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        wleft.set_valign(Gtk.Align.CENTER)
        wleft.set_size_request(210, -1)
        loc = Gtk.Label(label=_("Погода"))
        loc.set_halign(Gtk.Align.START)
        loc.get_style_context().add_class("lg-weather-loc")
        wleft.pack_start(loc, False, False, 0)
        self.city_label = Gtk.Label(label=weather.city_name() or _("Локально"))
        self.city_label.set_halign(Gtk.Align.START)
        self.city_label.set_ellipsize(Pango.EllipsizeMode.END)
        self.city_label.set_max_width_chars(18)
        self.city_label.get_style_context().add_class("lg-weather-city")
        wleft.pack_start(self.city_label, False, False, 0)
        self.weather_note = Gtk.Label(label=_("Погода"))
        self.weather_note.set_halign(Gtk.Align.START)
        self.weather_note.set_ellipsize(Pango.EllipsizeMode.END)
        self.weather_note.set_max_width_chars(22)
        self.weather_note.get_style_context().add_class("lg-weather-note")
        wleft.pack_start(self.weather_note, False, False, 0)
        self.weather_card.pack_start(wleft, False, False, 0)

        wcenter = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        wcenter.set_halign(Gtk.Align.CENTER)
        wcenter.set_valign(Gtk.Align.CENTER)
        wcenter.set_hexpand(True)
        self.weather_icon = widgets.IconArea("sun", (1, 1, 1), 66)
        wcenter.pack_start(self.weather_icon, False, False, 0)
        self.temp_label = Gtk.Label(label="--°")
        self.temp_label.get_style_context().add_class("lg-weather-temp")
        wcenter.pack_start(self.temp_label, False, False, 0)
        self.weather_card.pack_start(wcenter, True, True, 0)

        wright = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        wright.set_halign(Gtk.Align.END)
        wright.set_valign(Gtk.Align.CENTER)
        self.widget_clock = Gtk.Label(label="--:--")
        self.widget_clock.set_halign(Gtk.Align.END)
        self.widget_clock.get_style_context().add_class("lg-weather-clock")
        wright.pack_start(self.widget_clock, False, False, 0)
        self.widget_date = Gtk.Label(label="")
        self.widget_date.set_halign(Gtk.Align.END)
        self.widget_date.get_style_context().add_class("lg-weather-date")
        wright.pack_start(self.widget_date, False, False, 0)
        self.weather_card.pack_end(wright, False, False, 0)
        self.weather_card.set_hexpand(True)

        self.weather_event = Gtk.EventBox()
        self.weather_event.set_visible_window(False)
        self.weather_event.set_hexpand(True)
        self.weather_event.add(self.weather_card)
        self.weather_event.set_tooltip_text(_("Нажмите, чтобы выбрать город"))
        try:
            self.weather_event.set_cursor(
                Gdk.Cursor.new_from_name(Gdk.Display.get_default(), "pointer"))
        except Exception:
            pass
        self.weather_event.connect("button-press-event", self._on_weather_click)
        content.pack_start(self.weather_event, False, False, 0)

        # --------------------------------------------------------- поиск
        search_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        search_wrap = Gtk.Overlay()
        search_wrap.set_hexpand(True)
        self.search = Gtk.SearchEntry()
        self.search.set_hexpand(True)
        self.search.set_size_request(-1, 44)
        self.search.get_style_context().add_class("lg-search")
        self.search.connect("changed", self._on_search_changed)
        self.search.connect("key-press-event", self._on_search_key)
        search_wrap.add(self.search)

        # Собственная подсказка: некоторые темы Xfce рисуют placeholder
        # белым на белом фоне поисковой строки.
        self.search_ph = Gtk.Label(label=_("Поиск приложений…"))
        self.search_ph.set_halign(Gtk.Align.START)
        self.search_ph.set_valign(Gtk.Align.CENTER)
        self.search_ph.set_margin_start(44)
        self.search_ph.set_can_focus(False)
        self.search_ph.get_style_context().add_class("lg-search-ph")
        search_wrap.add_overlay(self.search_ph)
        search_row.pack_start(search_wrap, True, True, 0)

        close = widgets.icon_button("close", (1, 1, 1), icon_size=16,
                                    tooltip=_("Esc — закрыть"))
        close.get_style_context().add_class("lg-closebtn")
        close.connect("clicked", lambda *_: self.hide())
        search_row.pack_start(close, False, False, 0)
        content.pack_start(search_row, False, False, 0)

        # ------------------------------------------ вкладки категорий G3
        cats = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        cats.set_halign(Gtk.Align.START)
        cats.get_style_context().add_class("lg-tabs")
        for key, label in CATEGORIES:
            chip = Gtk.Button(label=_(label))
            chip.set_relief(Gtk.ReliefStyle.NONE)
            chip.set_can_focus(False)
            chip.get_style_context().add_class("lg-tab")
            if key == "all":
                chip.get_style_context().add_class("lg-tab-active")
            chip.connect("clicked", self._on_category, key)
            self.chips[key] = chip
            cats.pack_start(chip, False, False, 0)
        content.pack_start(cats, False, False, 0)

        # ------------------------------------------------------------ сетка
        self.flow = Gtk.FlowBox()
        self.flow.set_valign(Gtk.Align.START)
        self.flow.set_halign(Gtk.Align.FILL)
        self.flow.set_max_children_per_line(6)
        self.flow.set_min_children_per_line(3)
        self.flow.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.flow.set_activate_on_single_click(False)
        self.flow.set_homogeneous(True)
        self.flow.set_column_spacing(6)
        self.flow.set_row_spacing(10)
        self.flow.connect("child-activated", self._on_child_activated)
        self.flow.connect("move-cursor", self._on_move_cursor)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_overlay_scrolling(True)
        scroller.set_vexpand(True)
        scroller.add(self.flow)
        scroller.get_style_context().add_class("lg-scroll")
        content.pack_start(scroller, True, True, 0)

        # ------------------------------------------------------------ низ
        foot = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.count_label = Gtk.Label()
        self.count_label.get_style_context().add_class("lg-foot")
        foot.pack_start(self.count_label, False, False, 0)

        center = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        center.set_halign(Gtk.Align.CENTER)
        center.set_hexpand(True)
        home_line = Gtk.DrawingArea()
        home_line.set_size_request(52, 4)
        home_line.set_valign(Gtk.Align.CENTER)
        home_line.connect("draw", self._draw_home_line)
        center.pack_start(home_line, False, False, 0)
        foot.pack_start(center, True, True, 0)

        hint = Gtk.Label(label=_("Enter — запустить · Esc — закрыть"))
        hint.get_style_context().add_class("lg-foot")
        foot.pack_end(hint, False, False, 0)
        content.pack_start(foot, False, False, 0)

        overlay = Gtk.Overlay()
        overlay.add(self.bg_area)
        overlay.add_overlay(content)
        self.add(overlay)
        self.connect("key-press-event", self._on_key)

        self._apply_filter()
        self._update_weather_clock()
        cached = weather.cached()
        if cached:
            self._on_weather(cached)
        else:
            weather.fetch_async(self._on_weather)
        GLib.timeout_add_seconds(1, self._tick_weather_clock)
        self.connect("show", self._on_show)

    # ---------------------------------------------------------------- тема

    def build_css(self):
        pal = theme.palette()
        return """
            window.lg-launcher {{
                background-color: transparent;
            }}
            .lg-weather {{
                background-image: linear-gradient(135deg, #009FB8 0%,
                                                   #27C4D8 52%,
                                                   #8AE8F2 100%);
                border: 1px solid rgba(255,255,255,0.28);
                border-radius: 6px;
                padding: 16px 26px;
                color: #FFFFFF;
                box-shadow: 0 8px 26px rgba(0,0,0,0.20);
            }}
            .lg-weather-loc {{
                color: rgba(255,255,255,0.82);
                font-size: 11.5px;
                font-weight: 800;
                letter-spacing: 1.1px;
            }}
            .lg-weather-city {{
                color: #FFFFFF;
                font-size: 24px;
                font-weight: 700;
            }}
            .lg-weather-note {{
                color: rgba(255,255,255,0.64);
                font-size: 10.5px;
            }}
            .lg-weather-temp {{
                color: #FFFFFF;
                font-size: 64px;
                font-weight: 300;
                letter-spacing: -2px;
            }}
            .lg-weather-clock {{
                color: #FFFFFF;
                font-size: 42px;
                font-weight: 300;
                letter-spacing: -1px;
            }}
            .lg-weather-date {{
                color: rgba(255,255,255,0.82);
                font-size: 12px;
            }}
            .lg-search {{
                background-color: rgba(255,255,255,0.94);
                border: 1px solid rgba(255,255,255,0.62);
                border-radius: 4px;
                padding: 0 16px;
                color: #17272D;
                font-size: 13.5px;
                caret-color: {accent};
                box-shadow: 0 3px 12px rgba(0,0,0,0.16);
            }}
            .lg-search:focus {{
                border-color: #FFFFFF;
                box-shadow: 0 0 0 2px rgba(0,166,192,0.52);
            }}
            .lg-search-ph {{
                color: #647982;
                font-size: 13.5px;
            }}
            .lg-closebtn {{
                background: rgba(0,0,0,0.24);
                border: 1px solid rgba(255,255,255,0.28);
                border-radius: 22px;
                padding: 8px;
            }}
            .lg-closebtn:hover {{
                background: rgba(0,0,0,0.42);
            }}
            .lg-tabs {{
                background: transparent;
                border: none;
                padding: 0;
            }}
            .lg-tab {{
                background: transparent;
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 0;
                padding: 7px 14px;
                color: rgba(255,255,255,0.88);
                font-size: 12.5px;
                font-weight: 600;
                text-shadow: 0 1px 2px rgba(0,0,0,0.92),
                             0 0 7px rgba(0,0,0,0.48);
            }}
            .lg-tab:hover {{
                color: #FFFFFF;
                background: rgba(255,255,255,0.10);
                border-radius: 4px 4px 0 0;
            }}
            .lg-tab-active, .lg-tab-active:hover {{
                color: #FFFFFF;
                border-bottom-color: #FFFFFF;
                font-weight: 700;
            }}
            .lg-homeapp {{
                background: transparent;
                border: none;
                border-radius: 18px;
                padding: 8px 4px 10px;
                color: #FFFFFF;
            }}
            .lg-homeapp:hover {{
                background: rgba(255,255,255,0.14);
            }}
            .lg-homeapp:selected {{
                background: rgba(255,255,255,0.22);
            }}
            .lg-applabel {{
                color: #FFFFFF;
                font-size: 11.5px;
                font-weight: 600;
                text-shadow: 0 1px 2px rgba(0,0,0,0.95),
                             0 0 7px rgba(0,0,0,0.55);
            }}
            .lg-foot {{
                color: rgba(255,255,255,0.88);
                font-size: 11px;
                text-shadow: 0 1px 2px rgba(0,0,0,0.88),
                             0 0 7px rgba(0,0,0,0.45);
            }}
            .lg-scroll, .lg-scroll frame,
            .lg-scroll viewport, .lg-scroll scrolledwindow {{
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar {{
                min-width: 14px;
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar trough {{
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar slider {{
                background-color: {slider};
                border: none;
                border-radius: 6px;
                min-width: 10px;
                min-height: 48px;
            }}
            scrollbar slider:hover {{
                background-color: {slider_hover};
            }}
            scrollbar slider:active {{
                background-color: {accent};
            }}
            scrollbar button {{
                min-width: 0; min-height: 0;
                padding: 0; margin: 0;
                border: none;
                background: none;
                box-shadow: none;
            }}
        """.format(
            accent=pal["accent"],
            slider=theme.css_rgba("#FFFFFF", 0.36),
            slider_hover=theme.css_rgba("#FFFFFF", 0.58),
        )

    def apply_theme(self):
        widgets.update_provider(self.css_prov, self.build_css())
        if self.get_window() is not None:
            self.bg_area.queue_draw()

    # ------------------------------------------------------------ фон/стекло

    def _draw_home_line(self, area, cr):
        pal = theme.palette()
        accent = theme.hex_rgba(pal["accent"])
        cr.set_source_rgba(accent[0], accent[1], accent[2], 0.92)
        theme.round_rect(cr, 0, 0, area.get_allocated_width(),
                         area.get_allocated_height(), 2)
        cr.fill()
        return False

    def _draw_bg(self, area, cr):
        alloc = area.get_allocation()
        w = max(1, alloc.width)
        h = max(1, alloc.height)
        geo = widgets.workarea_geometry()
        # G2/G3 используют чёткие обои, а не матовое стекло
        pb = widgets.wallpaper_pixbuf(geo.x, geo.y, w, h)
        if pb is not None:
            Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
            cr.paint()
        else:
            grad = cairo.LinearGradient(0, 0, 0, h)
            grad.add_color_stop_rgb(0.0, 0.02, 0.62, 0.76)
            grad.add_color_stop_rgb(0.55, 0.22, 0.82, 0.88)
            grad.add_color_stop_rgb(1.0, 0.86, 0.97, 1.0)
            cr.set_source(grad)
            cr.paint()

        # затемнение сверху/снизу: белые подписи и панель читаются на любых
        # обоях, но сам фон остаётся ярким
        g = cairo.LinearGradient(0, 0, 0, h)
        g.add_color_stop_rgba(0.00, 0, 0, 0, 0.34)
        g.add_color_stop_rgba(0.24, 0, 0, 0, 0.10)
        g.add_color_stop_rgba(0.68, 0, 0, 0, 0.12)
        g.add_color_stop_rgba(1.00, 0, 0, 0, 0.46)
        cr.set_source(g)
        cr.paint()
        return False

    # ------------------------------------------------------------ наполнение

    def _apply_filter(self):
        q = self.query.lower().strip()
        out = []
        for app in self.all_apps:
            if self.category != "all" and _app_category(app) != self.category:
                continue
            if q and not app.matches(q):
                continue
            out.append(app)
        self.visible_apps = out
        self._fill(out)
        self.count_label.set_text(_("Приложений: %d") % len(out))

    def _fill(self, plist):
        for child in self.flow.get_children():
            self.flow.remove(child)
        pal = theme.palette()
        tile_bg = pal["tile_bg"]
        for app in plist:
            btn = Gtk.Button()
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_can_focus(False)
            btn.get_style_context().add_class("lg-homeapp")
            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
            pb = widgets.squircle_pixbuf(app.icon_pixbuf(48), 58, tile_bg,
                                         radius=14)
            img = Gtk.Image()
            if pb is not None:
                img.set_from_pixbuf(pb)
            else:
                img.set_from_icon_name("application-x-executable",
                                       Gtk.IconSize.DIALOG)
            img.set_halign(Gtk.Align.CENTER)
            vbox.pack_start(img, False, False, 0)
            label = Gtk.Label(label=app.name)
            label.set_ellipsize(Pango.EllipsizeMode.END)
            label.set_max_width_chars(24)
            label.set_halign(Gtk.Align.CENTER)
            label.get_style_context().add_class("lg-applabel")
            vbox.pack_start(label, False, False, 0)
            btn.add(vbox)
            btn.connect("clicked", self._on_button_clicked, app)
            self.flow.add(btn)
            btn.app_ref = app
        self.flow.show_all()
        if self.get_window() is not None:
            self.bg_area.queue_draw()

    def _on_category(self, _btn, key):
        self.category = key
        for name, chip in self.chips.items():
            ctx = chip.get_style_context()
            if name == key:
                ctx.add_class("lg-tab-active")
            else:
                ctx.remove_class("lg-tab-active")
        self._apply_filter()

    def _on_search_changed(self, entry):
        self.query = entry.get_text()
        if getattr(self, "search_ph", None) is not None:
            self.search_ph.set_visible(not self.query)
        self._apply_filter()

    # ------------------------------------------------------------- запуск

    def _launch(self, app):
        app.launch()
        self.hide()

    def _on_button_clicked(self, _btn, app):
        self._launch(app)

    def _on_child_activated(self, _fb, child):
        btn = child.get_child()
        app = getattr(btn, "app_ref", None)
        if app:
            self._launch(app)

    # ------------------------------------------------------------ клавиатура

    def _first_app(self):
        if not self.visible_apps:
            return None
        row = self.flow.get_children()
        if not row:
            return None
        sel = self.flow.get_selected_children()
        if sel:
            btn = sel[0].get_child()
            app = getattr(btn, "app_ref", None)
            if app:
                return app
        btn = row[0].get_child()
        return getattr(btn, "app_ref", None)

    def _on_search_key(self, _w, ev):
        key = ev.keyval
        if key in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_ISO_Enter):
            app = self._first_app()
            if app:
                self._launch(app)
            return True
        if key == Gdk.KEY_Escape:
            self.hide()
            return True
        if key == Gdk.KEY_Down:
            self.flow.grab_focus()
            return True
        return False

    def _on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.hide()
            return True
        return False

    def _on_move_cursor(self, _fb, _step, _count):
        return False

    # ---------------------------------------------------------------- показ

    def _on_apps_changed(self, *_a):
        # пакетный менеджер может создать десятки .desktop-файлов подряд
        if not self._apps_reload_id:
            self._apps_reload_id = GLib.timeout_add(250, self._reload_apps)
        return False

    def _reload_apps(self):
        self._apps_reload_id = 0
        apps.invalidate()
        self.all_apps = apps.list_apps()
        self._apply_filter()
        return False

    # ------------------------------------------------------ виджет времени

    def _update_weather_clock(self):
        now = datetime.datetime.now()
        self.widget_clock.set_text(now.strftime("%H:%M"))
        weekday = widgets.ru_weekday(now)
        if weekday:
            weekday = weekday[:1].upper() + weekday[1:]
        self.widget_date.set_text("%s, %s" % (weekday, now.strftime("%d.%m")))

    def _tick_weather_clock(self):
        self._update_weather_clock()
        return True

    def _on_weather(self, data):
        if not data:
            self.temp_label.set_text("--°")
            self.city_label.set_text(weather.city_name() or _("Локально"))
            self.weather_note.set_text(_("Погода недоступна"))
            self.weather_note.set_tooltip_text("")
            return
        self.temp_label.set_text(data.get("temp") or "--°")
        self.city_label.set_text(
            data.get("location") or weather.city_name() or _("Локально"))
        desc = data.get("desc") or _("Погода")
        self.weather_note.set_text(desc)
        self.weather_note.set_tooltip_text(desc)

    def _on_weather_click(self, _widget, event):
        if event.button == 1:
            self._open_weather_dialog()
            return True
        return False

    def _open_weather_dialog(self):
        """Выбор города погоды или автоопределение по IP."""
        current = config.get("weather", "city", "auto").strip()
        is_auto = current.lower() in ("", "auto", "авто")

        dlg = Gtk.Dialog(title=_("Город для погоды"),
                         transient_for=self, modal=True)
        dlg.set_size_request(390, -1)
        dlg.add_button(_("Отмена"), Gtk.ResponseType.CANCEL)
        dlg.add_button(_("Определить автоматически"), Gtk.ResponseType.APPLY)
        dlg.add_button(_("Сохранить"), Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK)

        box = dlg.get_content_area()
        box.set_spacing(8)
        box.set_margin_top(10)
        box.set_margin_bottom(6)
        box.set_margin_start(14)
        box.set_margin_end(14)

        hint = Gtk.Label(
            label=_("Введите город. Пустое поле — определять автоматически "
                    "по IP."))
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        hint.set_max_width_chars(44)
        box.pack_start(hint, False, False, 0)

        entry = Gtk.Entry()
        entry.set_text("" if is_auto else current)
        entry.set_placeholder_text(_("Например: Москва"))
        entry.set_activates_default(True)
        box.pack_start(entry, False, False, 0)

        dlg.show_all()
        response = dlg.run()
        text = entry.get_text().strip()
        dlg.destroy()

        if response not in (Gtk.ResponseType.OK, Gtk.ResponseType.APPLY):
            return
        value = "auto" if response == Gtk.ResponseType.APPLY else (text or "auto")
        config.set_option("weather", "city", value)
        weather.clear_cache()
        self.temp_label.set_text("--°")
        self.city_label.set_text(_("Локально") if value == "auto" else value)
        self.weather_note.set_text(_("Погода"))
        self.weather_note.set_tooltip_text("")
        weather.fetch_async(self._on_weather)

    def _on_show(self, *_a):
        geo = widgets.workarea_geometry()
        self.move(geo.x, geo.y)
        self.resize(geo.width, geo.height)
        # на случай, если монитор .desktop-файлов пропустил событие
        apps.invalidate()
        self.all_apps = apps.list_apps()
        self._apply_filter()
        self.bg_area.queue_draw()
        GLib.timeout_add(80, self._raise_dock)
        GLib.idle_add(lambda: (self.search.grab_focus(), False)[1])

    def _raise_dock(self):
        """Поднять док над полноэкранным домашним экраном (G2/G3).

        Лаунчер и док — разные процессы и оба keep-above; после показа
        лаунчера док оказывается ниже. Поднимаем его через GDK, не
        полагаясь на порядок запуска.
        """
        screen = Gdk.Screen.get_default()
        if screen is not None:
            for win in screen.get_window_stack():
                try:
                    cls = win.get_wm_class()
                except Exception:
                    cls = None
                if cls and "lg-dock" in cls:
                    win.raise_()
        return False

    def toggle(self):
        if self.get_visible():
            self.hide()
        else:
            self.search.set_text("")
            self.query = ""
            self.category = "all"
            for name, chip in self.chips.items():
                ctx = chip.get_style_context()
                if name == "all":
                    ctx.add_class("lg-tab-active")
                else:
                    ctx.remove_class("lg-tab-active")
            self._update_weather_clock()
            self._apply_filter()
            self.show_all()
            self.present()


def main():
    LauncherApp().run([])


if __name__ == "__main__":
    main()

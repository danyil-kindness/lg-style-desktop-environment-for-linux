# -*- coding: utf-8 -*-
"""Центр управления LG: быстрые переключатели, громкость, яркость."""

import datetime
import subprocess
import threading

from gi.repository import Gdk, Gio, GLib, Gtk, Pango

from . import config, i18n, sysinfo, theme, widgets
from .i18n import _

WIDTH = 860
MIN_HEIGHT = 560


def _spawn(cmd):
    try:
        subprocess.Popen(cmd, start_new_session=True)
    except Exception:
        pass


class ControlCenterApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.lgux.ControlCenter")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(ControlCenterWindow(self))
        self.win.toggle()

    def rebuild(self):
        """Пересоздать окно (после смены языка интерфейса)."""
        old = self.win
        self.win = self.track(ControlCenterWindow(self))
        i18n.mark_started()
        if old is not None:
            old.hide()
            old.destroy()
        self.win.toggle()


class ControlCenterWindow(widgets.ThemedWindow):
    # язык меняется прямо из этого окна — пересобираем его, а не процесс
    relaunch_on_language = False

    def __init__(self, app):
        super().__init__()
        self.app = app
        self._lang_busy = False
        self.set_title(_("Центр управления"))
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        # ширину фиксируем, высоту подгоняем под содержимое, но не меньше
        # MIN_HEIGHT — иначе шторка выглядит обрезанной
        self.set_resizable(True)
        self.set_size_request(WIDTH, -1)
        self.set_keep_above(True)
        self.set_accept_focus(True)
        widgets.set_rgba(self)

        self.css_prov = widgets.css_provider(self.build_css())
        self.use_css(self.css_prov)

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        card.set_margin_top(0)
        card.set_margin_bottom(0)
        card.set_margin_start(0)
        card.set_margin_end(0)
        card.get_style_context().add_class("lg-card")
        # клики по «карточке» не закрывают окно — только Esc или фон
        card.connect("button-press-event", lambda *_: True)

        # заголовок: знак LG, название и крупные часы справа
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        mark = widgets.IconArea("logo", (1, 1, 1), 24)
        head.pack_start(mark, False, False, 0)
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        header = Gtk.Label(label=_("Быстрые настройки"))
        header.set_halign(Gtk.Align.START)
        header.get_style_context().add_class("lg-header")
        names.pack_start(header, False, False, 0)
        subtitle = Gtk.Label(label=_("LG G2/G3 · Центр управления"))
        subtitle.set_halign(Gtk.Align.START)
        subtitle.get_style_context().add_class("lg-shade-sub")
        names.pack_start(subtitle, False, False, 0)
        head.pack_start(names, False, False, 0)
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        head.pack_start(spacer, True, True, 0)

        clockbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.clock_label = Gtk.Label(label="--:--")
        self.clock_label.set_halign(Gtk.Align.END)
        self.clock_label.get_style_context().add_class("lg-cc-time")
        clockbox.pack_start(self.clock_label, False, False, 0)
        self.date_label = Gtk.Label(label="")
        self.date_label.set_halign(Gtk.Align.END)
        self.date_label.get_style_context().add_class("lg-cc-date")
        clockbox.pack_start(self.date_label, False, False, 0)
        head.pack_start(clockbox, False, False, 0)

        close = widgets.icon_button("close", (1, 1, 1), icon_size=16,
                                    tooltip=_("Esc — закрыть"))
        close.get_style_context().add_class("lg-cc-close")
        close.connect("clicked", lambda *_: self.hide())
        head.pack_end(close, False, False, 0)
        card.pack_start(head, False, False, 0)

        # вкладки, как в шторке G2: Сети / Экран и звук / Общие
        tabs = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        tabs.get_style_context().add_class("lg-tabs")
        self.tab_buttons = {}
        for key, label in (("net", _("Сети")), ("display", _("Экран и звук")),
                           ("general", _("Общие"))):
            btn = Gtk.Button(label=label)
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_can_focus(False)
            btn.get_style_context().add_class("lg-tab")
            btn.connect("clicked", lambda _b, k=key: self._show_tab(k))
            tabs.pack_start(btn, False, False, 0)
            self.tab_buttons[key] = btn
        card.pack_start(tabs, False, False, 0)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.stack.set_transition_duration(160)
        card.pack_start(self.stack, True, True, 0)

        # плитки быстрых настроек
        self.tiles = {}
        tile_defs = [
            ("wifi", "Wi-Fi", "wifi"),
            ("bt", "Bluetooth", "bluetooth"),
            ("dark", _("Тёмная тема"), "contrast"),
            ("dnd", _("Не беспокоить"), "moon"),
        ]
        for key, label, icon in tile_defs:
            tile = self._make_tile(label, icon)
            tile.connect("button-press-event", self._on_tile, key)
            self.tiles[key] = tile

        # --- страница «Сети»
        page_net = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page_net.get_style_context().add_class("lg-page")
        net_grid = Gtk.Grid()
        net_grid.set_row_spacing(8)
        net_grid.set_column_spacing(8)
        net_grid.set_column_homogeneous(True)
        net_grid.attach(self.tiles["wifi"], 0, 0, 1, 1)
        net_grid.attach(self.tiles["bt"], 1, 0, 1, 1)
        page_net.pack_start(net_grid, False, False, 0)

        self.net_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        page_net.pack_start(self.net_box, False, False, 0)
        self.stack.add_named(page_net, "net")

        # --- страница «Экран»
        page_display = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page_display.get_style_context().add_class("lg-page")
        disp_grid = Gtk.Grid()
        disp_grid.set_row_spacing(8)
        disp_grid.set_column_spacing(8)
        disp_grid.set_column_homogeneous(True)
        disp_grid.attach(self.tiles["dark"], 0, 0, 1, 1)
        disp_grid.attach(self.tiles["dnd"], 1, 0, 1, 1)
        page_display.pack_start(disp_grid, False, False, 0)

        self.bright_box, self.bright_scale = self._make_scale("sun", _("Яркость"))
        self.bright_scale.connect("value-changed", self._on_bright)
        page_display.pack_start(self.bright_box, False, False, 0)

        self.vol_box, self.vol_scale = self._make_scale("volume", _("Громкость"))
        self.vol_scale.connect("value-changed", self._on_vol)
        page_display.pack_start(self.vol_box, False, False, 0)

        self.state_label = Gtk.Label()
        self.state_label.set_halign(Gtk.Align.START)
        self.state_label.get_style_context().add_class("lg-shade-sub")
        page_display.pack_start(self.state_label, False, False, 0)

        disp_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn_wall2 = self._make_action("sun", _("Обои LG"), self._set_wallpaper)
        btn_shot = self._make_action("grid", _("Скриншот"), self._screenshot)
        btn_disp = self._make_action("gear", _("Настройки экрана"),
                                     self._display_settings)
        disp_actions.pack_start(btn_wall2, True, True, 0)
        disp_actions.pack_start(btn_shot, True, True, 0)
        disp_actions.pack_start(btn_disp, True, True, 0)
        page_display.pack_start(disp_actions, False, False, 0)

        geo = widgets.workarea_geometry()
        self.display_info = Gtk.Label(
            label="%d×%d · LG G2/G3 · Xfce" % (geo.width, geo.height))
        self.display_info.set_halign(Gtk.Align.START)
        self.display_info.get_style_context().add_class("lg-shade-sub")
        page_display.pack_start(self.display_info, False, False, 0)
        self.stack.add_named(page_display, "display")

        # --- страница «Общие»
        page_general = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page_general.get_style_context().add_class("lg-page")
        page_general.get_style_context().add_class("lg-general")
        page_general.pack_start(self._make_language_box(), False, False, 0)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn_settings = self._make_action("gear", _("Настройки"), self._open_settings)
        btn_lock = self._make_action("lock", _("Заблокировать"),
                                     lambda *_: sysinfo.lock_screen())
        btn_power = self._make_action("power", _("Питание"), self._power_menu)
        self.btn_power = btn_power
        btn_wall = self._make_action("sun", _("Обои LG"), self._set_wallpaper)
        actions.pack_start(btn_settings, True, True, 0)
        actions.pack_start(btn_lock, True, True, 0)
        actions.pack_start(btn_power, True, True, 0)
        actions.pack_start(btn_wall, True, True, 0)
        page_general.pack_start(actions, False, False, 0)

        actions2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn_logout = self._make_action("power", _("Выход из сеанса"),
                                       lambda *_: sysinfo.logout())
        actions2.pack_start(btn_logout, True, True, 0)
        page_general.pack_start(actions2, False, False, 0)

        note = Gtk.Label(
            label=_("Личные обои не меняются автоматически. "
                    "Кнопка «Обои LG» применяет фирменный фон."))
        note.set_halign(Gtk.Align.START)
        note.set_line_wrap(True)
        note.get_style_context().add_class("lg-shade-sub")
        page_general.pack_start(note, False, False, 0)
        self.stack.add_named(page_general, "general")

        # ошибки/подсказки видны на любой вкладке
        self.hint_label = Gtk.Label()
        self.hint_label.set_halign(Gtk.Align.START)
        self.hint_label.set_line_wrap(True)
        self.hint_label.set_no_show_all(True)
        self.hint_label.get_style_context().add_class("lg-hint")
        card.pack_start(self.hint_label, False, False, 0)
        self._hint_seq = 0

        self._wifi_on = False
        self._bt_on = False
        self._wifi_loading = False
        self._bt_loading = False
        self._wifi_nets = []
        self._wifi_saved = set()
        self._wifi_msg = ""
        self._pw_ssid = None
        self._pw_error = ""
        self._bt_items = []
        self._bt_msg = ""
        self._net_busy = ""

        self.add(card)
        self.get_style_context().add_class("lg-cc")
        self.connect("button-press-event", self._on_bg_press)
        self.connect("key-press-event", self._on_key)

        self._suppress = False
        self.show_all()
        self._show_tab("net")
        self.hide()
        self._position()
        self._update_clock()
        GLib.timeout_add_seconds(30, self._tick_clock)

    # ---------------------------------------------------------------- тема

    def build_css(self):
        pal = dict(theme.palette())
        sr = pal["shade_rgba"]
        pal["shade_bg"] = "rgba(%d,%d,%d,%.3f)" % (
            round(sr[0] * 255), round(sr[1] * 255), round(sr[2] * 255), sr[3])
        pal["shade_line"] = theme.css_rgba("#FFFFFF", 0.14)
        pal["shade_text"] = theme.css_rgba("#FFFFFF", 0.94)
        pal["shade_sub"] = theme.css_rgba("#FFFFFF", 0.64)
        return """
            window.lg-cc, window.lg-cc.background {{
                background-color: transparent;
                background-image: none;
                box-shadow: none;
            }}
            .lg-card {{
                background-color: {shade_bg};
                border: none;
                border-radius: 0 0 20px 20px;
                padding: 14px 20px 16px;
                color: #FFFFFF;
                box-shadow: 0 14px 38px rgba(0,0,0,0.34);
            }}
            .lg-header {{
                font-size: 17px; font-weight: 700; color: #FFFFFF;
            }}
            .lg-shade-sub {{ color: {shade_sub}; font-size: 10.5px; }}
            .lg-sub {{ color: {sub}; font-size: 11px; }}
            .lg-general .lg-sub {{ color: {shade_sub}; }}
            .lg-section {{
                color: #FFFFFF; font-size: 12px; font-weight: 700;
                letter-spacing: 0.6px;
            }}
            .lg-cc-time {{
                color: #FFFFFF; font-size: 24px; font-weight: 300;
                letter-spacing: 0.4px;
            }}
            .lg-cc-date {{ color: {shade_sub}; font-size: 10.5px; }}
            .lg-value {{ color: {shade_sub}; font-size: 11px; font-weight: 700; }}
            .lg-hint {{ color: #FFB3B8; font-size: 11.5px; }}
            .lg-tabs {{
                border-bottom: 1px solid {shade_line};
                margin-bottom: 2px;
            }}
            .lg-tab {{
                background: transparent;
                border: none;
                border-bottom: 3px solid transparent;
                border-radius: 4px 4px 0 0;
                padding: 8px 18px;
                color: {shade_sub};
                font-size: 12.5px;
                font-weight: 600;
            }}
            .lg-tab:hover {{
                color: #FFFFFF;
                background-color: rgba(255,255,255,0.08);
            }}
            .lg-tab-active, .lg-tab-active:hover {{
                color: #FFFFFF;
                background-color: rgba(255,255,255,0.10);
                border-bottom-color: #FFFFFF;
            }}
            .lg-cc-close {{
                background-color: rgba(255,255,255,0.09);
                border-radius: 18px;
                padding: 6px;
            }}
            .lg-cc-close:hover {{ background-color: rgba(255,255,255,0.20); }}
            .lg-page {{ padding-top: 2px; }}
            .lg-tile {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 12px;
                padding: 10px 12px;
                min-height: 46px;
                color: {text};
            }}
            .lg-tile:hover {{ background-color: {surface2}; }}
            .lg-tile label {{ font-size: 12px; font-weight: 500; }}
            .lg-tile-state {{ color: {sub}; font-size: 10px; }}
            .lg-tile-active {{
                background-color: {accent};
                border-color: {accent};
                color: {accent_text};
            }}
            .lg-tile-active .lg-tile-state {{
                color: rgba(255,255,255,0.80);
            }}
            .lg-tile-active:hover {{
                background-color: {accent};
                border-color: rgba(255,255,255,0.60);
            }}
            .lg-action {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 12px;
                padding: 10px 6px;
                color: {text};
                font-size: 12px;
            }}
            .lg-action:hover {{ background-color: {surface2}; }}
            .lg-netrow {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 10px;
                padding: 7px 9px;
                color: {text};
                font-size: 12.5px;
                margin: 2px 0;
            }}
            .lg-netrow:hover {{ background-color: {surface2}; }}
            .lg-netrow-active {{ background-color: {surface2}; }}
            .lg-netrow label {{ color: {text}; }}
            .lg-netrow .lg-sub {{ color: {sub}; font-size: 11px; }}
            .lg-iconbtn {{
                background: transparent;
                border: none;
                padding: 2px 4px;
                border-radius: 8px;
            }}
            .lg-iconbtn:hover {{ background-color: {surface2}; }}
            .lg-pwbox {{
                background-color: {surface2};
                border-radius: 10px;
                padding: 6px;
            }}
            .lg-pwbox entry {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 4px 8px;
                color: {text};
                font-size: 12px;
            }}
            .lg-btn {{
                background-color: {accent};
                border: none;
                border-radius: 8px;
                padding: 5px 12px;
                color: {accent_text};
                font-size: 12px;
            }}
            .lg-language {{
                background-color: {surface2};
                border-radius: 10px;
                padding: 5px 4px;
                color: {text};
                font-size: 11.5px;
            }}
            .lg-language:hover {{ background-color: {border}; }}
            .lg-language.lg-language-active,
            .lg-language.lg-language-active:hover {{
                background-color: {accent};
                color: {accent_text};
                font-weight: bold;
            }}
            .lg-err {{ color: #FFB3B8; font-size: 11px; }}
            .lg-ok {{ color: {shade_sub}; font-size: 11px; }}
            scale trough {{
                background-color: rgba(255,255,255,0.18);
                border-radius: 4px;
                min-height: 8px;
            }}
            scale highlight {{
                background-color: {accent};
                border-radius: 4px;
            }}
            scale slider {{
                background-color: #FFFFFF;
                border: 2px solid {accent};
                border-radius: 16px;
                min-width: 18px; min-height: 18px;
            }}
            scrollbar {{
                min-width: 12px;
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar trough {{
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar slider {{
                background-color: rgba(255,255,255,0.30);
                border: none;
                border-radius: 6px;
                min-width: 8px;
                min-height: 36px;
            }}
            scrollbar slider:hover {{ background-color: rgba(255,255,255,0.48); }}
            scrollbar button {{
                min-width: 0; min-height: 0;
                padding: 0; margin: 0;
                border: none; background: none; box-shadow: none;
            }}
        """.format(**pal)

    def apply_theme(self):
        widgets.update_provider(self.css_prov, self.build_css())

    # -------------------------------------------------------------- элементы

    def _make_tile(self, label, icon):
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        area = widgets.IconArea(icon, (1, 1, 1), 22)
        area.set_halign(Gtk.Align.CENTER)
        area.set_valign(Gtk.Align.CENTER)
        hbox.pack_start(area, False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        lbl = Gtk.Label(label=label)
        lbl.set_halign(Gtk.Align.START)
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
        lbl.set_max_width_chars(15)
        text.pack_start(lbl, False, False, 0)
        state = Gtk.Label(label=_("выкл"))
        state.set_halign(Gtk.Align.START)
        state.get_style_context().add_class("lg-tile-state")
        text.pack_start(state, False, False, 0)
        hbox.pack_start(text, True, True, 0)
        btn.add(hbox)
        btn.get_style_context().add_class("lg-tile")
        btn.tile_icon = area
        btn.tile_label = lbl
        btn.tile_state = state
        return btn

    def _make_scale(self, icon, tooltip):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        area = widgets.IconArea(icon, theme.hex_rgba(theme.palette()["sub"])[:3], 20)
        box.pack_start(area, False, False, 0)
        scale = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
        scale.set_range(0, 100)
        scale.set_draw_value(False)
        scale.set_hexpand(True)
        scale.set_tooltip_text(tooltip)
        box.pack_start(scale, True, True, 0)
        value = Gtk.Label(label="--%")
        value.set_size_request(38, -1)
        value.set_halign(Gtk.Align.END)
        value.get_style_context().add_class("lg-value")
        box.pack_end(value, False, False, 0)
        scale.value_label = value
        scale.connect("value-changed",
                      lambda sc: value.set_text("%d%%" % int(sc.get_value())))
        box.get_style_context().add_class("lg-sliderbox")
        return box, scale

    def _make_action(self, icon, label, cb):
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        area = widgets.IconArea(icon, theme.hex_rgba(theme.palette()["text"])[:3], 20)
        area.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(area, False, False, 0)
        lbl = Gtk.Label(label=label)
        lbl.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(lbl, False, False, 0)
        btn.add(vbox)
        btn.get_style_context().add_class("lg-action")
        btn.connect("clicked", cb)
        return btn

    # ------------------------------------------------------------- язык

    def _make_language_box(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)

        lbl = Gtk.Label(label=_("Язык"), xalign=0)
        lbl.get_style_context().add_class("lg-sub")
        box.pack_start(lbl, False, False, 0)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        row.set_homogeneous(True)
        active = i18n.current()
        for code in i18n.LANGUAGES:
            btn = Gtk.Button(label=i18n.NAMES[code])
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_can_focus(False)
            ctx = btn.get_style_context()
            ctx.add_class("lg-language")
            if code == active:
                ctx.add_class("lg-language-active")
            btn.connect("clicked", lambda _b, c=code: self._pick_language(c))
            row.pack_start(btn, True, True, 0)
        box.pack_start(row, False, False, 0)

        self.auto_check = Gtk.CheckButton(label=_("Как в системе"))
        self.auto_check.get_style_context().add_class("lg-sub")
        self.auto_check.set_active(i18n.configured() == "auto")
        self.auto_check.connect("toggled", self._on_auto_language)
        box.pack_start(self.auto_check, False, False, 0)
        return box

    def _pick_language(self, code):
        if self._lang_busy:
            return
        self._lang_busy = True
        try:
            if self.auto_check.get_active():
                self.auto_check.set_active(False)
        finally:
            self._lang_busy = False
        config.set_option("general", "language", code)
        self._apply_language()

    def _on_auto_language(self, check):
        if self._lang_busy:
            return
        self._lang_busy = True
        try:
            if check.get_active():
                config.set_option("general", "language", "auto")
            else:
                config.set_option("general", "language", i18n.current())
        finally:
            self._lang_busy = False
        self._apply_language()

    def _apply_language(self):
        i18n.reload()
        self.app.rebuild()

    # ------------------------------------------------------------ сети
    # Wi-Fi: список сетей, ввод пароля, подключение/отключение.
    # Bluetooth: известные устройства, поиск, подключение.

    def _net_section(self, title, refresh_cb):
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        lbl = Gtk.Label(label=title, xalign=0)
        lbl.get_style_context().add_class("lg-shade-sub")
        head.pack_start(lbl, True, True, 0)
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        btn.get_style_context().add_class("lg-iconbtn")
        btn.add(widgets.IconArea("search", (1, 1, 1), 14))
        btn.set_tooltip_text(_("Обновить список"))
        btn.connect("clicked", lambda *_: refresh_cb())
        head.pack_end(btn, False, False, 0)
        return head

    def _net_scroll(self, body, rows, row_h=40, max_h=190):
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_overlay_scrolling(False)
        sw.get_style_context().add_class("lg-netscroll")
        try:
            sw.set_propagate_natural_height(True)
            sw.set_min_content_height(row_h)
            sw.set_max_content_height(min(row_h * max(rows, 1), max_h))
        except Exception:
            sw.set_size_request(-1, min(row_h * max(rows, 1), max_h))
        sw.add(body)
        return sw

    def _rebuild_nets(self):
        for child in list(self.net_box.get_children()):
            self.net_box.remove(child)

        if self._wifi_on:
            self.net_box.pack_start(
                self._net_section(_("Сети Wi-Fi"), self._reload_wifi),
                False, False, 0)
            self.net_box.pack_start(self._build_wifi_body(), False, False, 0)
        elif self._wifi_on is False:
            lbl = Gtk.Label(label=_("Wi-Fi выключен — нажмите плитку выше"),
                            xalign=0)
            lbl.get_style_context().add_class("lg-shade-sub")
            self.net_box.pack_start(lbl, False, False, 0)

        if self._bt_on:
            self.net_box.pack_start(
                self._net_section(_("Устройства Bluetooth"), self._bt_scan),
                False, False, 0)
            self.net_box.pack_start(self._build_bt_body(), False, False, 0)

        self.net_box.show_all()
        GLib.idle_add(self._position)

    # -------------------------------------------------------------- Wi-Fi

    def _reload_wifi(self, *_a):
        if not self._wifi_on or self._wifi_loading:
            return
        self._wifi_loading = True
        self._wifi_msg = _("Поиск сетей…")
        self._rebuild_nets()

        def work():
            nets = sysinfo.wifi_networks()
            saved = sysinfo.wifi_saved_names()
            GLib.idle_add(self._fill_wifi, nets, saved)

        threading.Thread(target=work, daemon=True).start()

    def _fill_wifi(self, nets, saved):
        self._wifi_loading = False
        self._wifi_nets = nets
        self._wifi_saved = saved
        self._wifi_msg = "" if nets else _("Сети не найдены")
        if self._pw_ssid and self._pw_ssid not in [n[0] for n in nets]:
            self._pw_ssid = None
        self._rebuild_nets()

    def _build_wifi_body(self):
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        if self._wifi_msg:
            lbl = Gtk.Label(label=self._wifi_msg, xalign=0)
            lbl.set_line_wrap(True)
            lbl.get_style_context().add_class("lg-ok")
            body.pack_start(lbl, False, False, 0)
        if not self._wifi_nets:
            if not self._wifi_msg:
                lbl = Gtk.Label(label=_("Поиск сетей…"), xalign=0)
                lbl.get_style_context().add_class("lg-shade-sub")
                body.pack_start(lbl, False, False, 0)
            return self._net_scroll(body, 1)
        for ssid, sig, sec, used in self._wifi_nets:
            body.pack_start(self._wifi_row(ssid, sig, sec, used), False, False, 0)
            if ssid == self._pw_ssid:
                body.pack_start(self._password_box(ssid), False, False, 0)
        return self._net_scroll(body, len(self._wifi_nets))

    def _wifi_row(self, ssid, signal, security, used):
        pal = theme.palette()
        sub = theme.hex_rgba(pal["sub"])[:3]
        accent = theme.hex_rgba(pal["accent"])[:3]

        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        ctx = btn.get_style_context()
        ctx.add_class("lg-netrow")
        if used:
            ctx.add_class("lg-netrow-active")

        hb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hb.pack_start(widgets.IconArea("wifi", accent if used else sub, 16),
                      False, False, 0)
        name = Gtk.Label(label=ssid, xalign=0)
        name.set_ellipsize(Pango.EllipsizeMode.END)
        hb.pack_start(name, True, True, 0)
        if used:
            lbl = Gtk.Label(label=_("подключено"))
            lbl.get_style_context().add_class("lg-sub")
            hb.pack_end(lbl, False, False, 0)
        elif security:
            hb.pack_end(widgets.IconArea("lock", sub, 13), False, False, 0)
        btn.add(hb)

        if used:
            btn.set_tooltip_text(_("Отключиться от сети"))
            btn.connect("clicked", lambda *_: self._wifi_disconnect())
        elif security and ssid not in self._wifi_saved:
            btn.set_tooltip_text(_("Ввести пароль"))
            btn.connect("clicked", lambda *_: self._ask_password(ssid))
        else:
            btn.connect("clicked", lambda *_: self._connect_wifi(ssid))
        return btn

    def _ask_password(self, ssid):
        self._pw_ssid = ssid
        self._pw_error = ""
        self._rebuild_nets()

    def _password_box(self, ssid):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.get_style_context().add_class("lg-pwbox")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        entry = Gtk.Entry()
        entry.set_visibility(False)
        entry.set_placeholder_text(_("Пароль сети «%s»") % ssid)
        entry.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        entry.set_hexpand(True)
        ok = Gtk.Button(label=_("Подключиться"))
        ok.set_relief(Gtk.ReliefStyle.NONE)
        ok.set_can_focus(False)
        ok.get_style_context().add_class("lg-btn")
        show = Gtk.CheckButton(label=_("Показать пароль"))
        show.get_style_context().add_class("lg-sub")
        show.connect("toggled", lambda c: entry.set_visibility(c.get_active()))
        err = Gtk.Label(label=self._pw_error, xalign=0)
        err.set_line_wrap(True)
        err.get_style_context().add_class("lg-err" if self._pw_error
                                         else "lg-ok")

        def submit(*_a):
            pwd = entry.get_text()
            ok.set_sensitive(False)
            err.get_style_context().remove_class("lg-ok")
            err.get_style_context().add_class("lg-err")
            err.set_text(_("Подключение…"))
            entry.set_sensitive(False)

            def work():
                good, msg = sysinfo.wifi_connect(ssid, pwd or None)
                GLib.idle_add(self._after_connect, good, msg, ssid)

            threading.Thread(target=work, daemon=True).start()

        ok.connect("clicked", submit)
        entry.connect("activate", submit)
        row.pack_start(entry, True, True, 0)
        row.pack_start(ok, False, False, 0)
        box.pack_start(row, False, False, 0)
        box.pack_start(show, False, False, 0)
        if self._pw_error:
            box.pack_start(err, False, False, 0)
        GLib.idle_add(lambda: (entry.grab_focus(), False)[1])
        return box

    def _connect_wifi(self, ssid):
        self._wifi_loading = True
        self._wifi_msg = _("Подключение к «%s»…") % ssid
        self._rebuild_nets()

        def work():
            good, msg = sysinfo.wifi_connect(ssid, None)
            GLib.idle_add(self._after_connect, good, msg, ssid)

        threading.Thread(target=work, daemon=True).start()

    def _after_connect(self, good, msg, ssid):
        self._wifi_loading = False
        if good:
            self._pw_ssid = None
            self._pw_error = ""
            self._wifi_msg = ""
            GLib.timeout_add(600, self._refresh)
            self._reload_wifi()
            return
        error = self._friendly_error(msg)
        self._wifi_msg = _("Не удалось: %s") % error
        self._pw_error = error if self._pw_ssid else ""
        self._rebuild_nets()

    @staticmethod
    def _friendly_error(msg):
        low = (msg or "").lower()
        if "secret" in low or "password" in low or "psk" in low:
            return _("Неверный пароль")
        if "no network with ssid" in low or "not found" in low:
            return _("Сеть не найдена")
        if "timeout" in low or "timed out" in low:
            return _("Истекло время ожидания")
        text = (msg or "").strip().splitlines()
        text = text[-1] if text else _("Не удалось подключиться")
        return text[:120]

    def _wifi_disconnect(self):
        self._wifi_loading = True
        self._wifi_msg = _("Отключение…")
        self._rebuild_nets()
        threading.Thread(target=self._disconnect_work, daemon=True).start()

    def _disconnect_work(self):
        sysinfo.wifi_disconnect()
        nets = sysinfo.wifi_networks()
        saved = sysinfo.wifi_saved_names()
        GLib.idle_add(self._fill_wifi, nets, saved)

    # ------------------------------------------------------------ Bluetooth

    def _load_bt(self):
        if not self._bt_on or self._bt_loading:
            return
        self._bt_loading = True
        self._bt_msg = _("Поиск устройств…")

        def work():
            devs = sysinfo.bt_devices()
            GLib.idle_add(self._fill_bt, devs)

        threading.Thread(target=work, daemon=True).start()

    def _bt_scan(self, *_a):
        if not self._bt_on or self._bt_loading:
            return
        self._bt_loading = True
        self._bt_msg = _("Поиск устройств… (10 секунд)")
        self._rebuild_nets()

        def work():
            sysinfo.bt_scan(10)
            devs = sysinfo.bt_devices()
            GLib.idle_add(self._fill_bt, devs)

        threading.Thread(target=work, daemon=True).start()

    def _fill_bt(self, devs):
        self._bt_loading = False
        self._bt_items = devs
        self._bt_msg = "" if devs else _("Устройства не найдены — нажмите поиск")
        self._rebuild_nets()

    def _build_bt_body(self):
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        if self._bt_msg:
            lbl = Gtk.Label(label=self._bt_msg, xalign=0)
            lbl.set_line_wrap(True)
            lbl.get_style_context().add_class("lg-ok")
            body.pack_start(lbl, False, False, 0)
        if not self._bt_items:
            if not self._bt_msg:
                lbl = Gtk.Label(label=_("Поиск устройств…"), xalign=0)
                lbl.get_style_context().add_class("lg-shade-sub")
                body.pack_start(lbl, False, False, 0)
            return self._net_scroll(body, 1)
        for mac, name, connected, paired in self._bt_items:
            body.pack_start(self._bt_row(mac, name, connected, paired),
                            False, False, 0)
        return self._net_scroll(body, len(self._bt_items))

    def _bt_row(self, mac, name, connected, paired):
        pal = theme.palette()
        sub = theme.hex_rgba(pal["sub"])[:3]
        accent = theme.hex_rgba(pal["accent"])[:3]

        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        ctx = btn.get_style_context()
        ctx.add_class("lg-netrow")
        if connected:
            ctx.add_class("lg-netrow-active")
        hb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hb.pack_start(widgets.IconArea("bluetooth",
                                       accent if connected else sub, 16),
                      False, False, 0)
        lbl = Gtk.Label(label=name or mac, xalign=0)
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
        hb.pack_start(lbl, True, True, 0)
        if connected:
            st = Gtk.Label(label=_("подключено"))
            st.get_style_context().add_class("lg-sub")
            hb.pack_end(st, False, False, 0)
        btn.add(hb)
        if connected:
            btn.connect("clicked", lambda *_: self._bt_do(mac, False))
        else:
            btn.connect("clicked", lambda *_: self._bt_do(mac, True))
        return btn

    def _bt_do(self, mac, connect):
        self._bt_msg = _("Подключение…") if connect else _("Отключение…")
        self._rebuild_nets()

        def work():
            if connect:
                good, msg = sysinfo.bt_connect(mac)
            else:
                sysinfo.bt_disconnect(mac)
                good, msg = True, ""
            devs = sysinfo.bt_devices()
            GLib.idle_add(self._after_bt, devs, good, msg)

        threading.Thread(target=work, daemon=True).start()

    def _after_bt(self, devs, good, msg):
        self._bt_items = devs
        self._bt_msg = "" if good else (_("Не удалось: %s") % (msg or _("ошибка")))
        self._rebuild_nets()

    # -------------------------------------------------------------- позиция

    def _position(self):
        geo = widgets.workarea_geometry()
        req = self.get_preferred_width()
        width = max(WIDTH, req[1])
        height = max(MIN_HEIGHT, self.get_preferred_height()[1])
        height = min(height, geo.height - 16)
        # шторка G2 прижата к верху рабочей области (сразу под панелью)
        x = geo.x + max(0, (geo.width - width) // 2)
        y = geo.y
        self.resize(width, height)
        self.move(x, y)

    def _update_clock(self):
        now = datetime.datetime.now()
        self.clock_label.set_text(now.strftime("%H:%M"))
        self.date_label.set_text("%s, %s" % (widgets.ru_weekday(now),
                                             now.strftime("%d.%m")))

    def _tick_clock(self):
        if self.get_visible():
            self._update_clock()
        return True

    # ------------------------------------------------------------ обновление

    def _refresh(self):
        pal = theme.palette()

        wifi = sysinfo.wifi_enabled()
        self._set_tile("wifi", wifi, "wifi" if wifi else "wifi-off")
        bt = sysinfo.bt_powered()
        self._set_tile("bt", bt, "bluetooth")

        changed = False
        wifi_on = bool(wifi)
        if wifi_on != self._wifi_on:
            self._wifi_on = wifi_on
            changed = True
            if not wifi_on:
                self._wifi_nets = []
                self._wifi_saved = set()
                self._pw_ssid = None
        bt_on = bool(bt)
        if bt_on != self._bt_on:
            self._bt_on = bt_on
            changed = True
            if not bt_on:
                self._bt_items = []
        if changed:
            self._rebuild_nets()
            # включили Wi-Fi/Bluetooth плиткой — сразу показываем список
            if wifi_on:
                self._reload_wifi()
            if bt_on:
                self._load_bt()
        self._set_tile("dark", config.is_dark(), "contrast")
        self._set_tile("dnd", config.load().getboolean(
            "general", "dnd", fallback=False), "moon")

        # ползунки без ложных срабатываний
        self._suppress = True
        b = sysinfo.get_brightness()
        if b is not None:
            self.bright_scale.set_value(b)
        v = sysinfo.get_volume()
        if v is not None:
            self.vol_scale.set_value(v)
        self._suppress = False
        for sc in (self.bright_scale, self.vol_scale):
            sc.value_label.set_text("%d%%" % int(sc.get_value()))

        parts = []
        if wifi is not None:
            parts.append("Wi-Fi %s" % (_("вкл") if wifi else _("выкл")))
        if bt is not None:
            parts.append("Bluetooth %s" % (_("вкл") if bt else _("выкл")))
        if b is not None:
            parts.append(_("яркость %d%%") % b)
        if v is not None:
            parts.append(_("громкость %d%%") % v)
        self.state_label.set_text(" · ".join(parts) if parts else "")

    def _set_tile(self, key, active, icon):
        tile = self.tiles[key]
        pal = theme.palette()
        ctx = tile.get_style_context()
        if active:
            ctx.add_class("lg-tile-active")
            color = (1, 1, 1)
        else:
            ctx.remove_class("lg-tile-active")
            color = theme.hex_rgba(pal["text"])[:3]
        tile.tile_icon.set_icon(color=color, name=icon)
        tile.tile_state.set_text(_("вкл") if active else _("выкл"))

    # ------------------------------------------------------------- вкладки

    def _show_tab(self, key):
        if getattr(self, "stack", None) is None:
            return
        self.stack.set_visible_child_name(key)
        self._sync_tabs()
        GLib.idle_add(lambda: (self._position(), False)[1])

    def _sync_tabs(self):
        if getattr(self, "stack", None) is None:
            return
        key = self.stack.get_visible_child_name() or "net"
        for name, btn in self.tab_buttons.items():
            ctx = btn.get_style_context()
            if name == key:
                ctx.add_class("lg-tab-active")
            else:
                ctx.remove_class("lg-tab-active")

    def _set_wallpaper(self, *_a):
        _spawn(["lg-wallpaper"])
        self.hide()

    def _screenshot(self, *_a):
        _spawn(["xfce4-screenshooter", "-f"])
        self.hide()

    def _display_settings(self, *_a):
        _spawn(["xfce4-display-settings"])
        self.hide()

    # ------------------------------------------------------------- события

    def _on_tile(self, _w, _ev, key):
        if key == "wifi":
            cur = sysinfo.wifi_enabled()
            if cur is None:
                self._show_hint(_("Wi-Fi недоступен: не найден nmcli"))
            elif not sysinfo.set_wifi(not cur):
                self._show_hint(_("Не удалось переключить Wi-Fi"))
            else:
                self._hide_hint()
        elif key == "bt":
            cur = sysinfo.bt_powered()
            # клик всегда пытается переключить: если состояние неизвестно
            # (нет адаптера/заблокирован), пробуем включить и рассказываем,
            # что пошло не так — раньше кнопка просто «не нажималась»
            want = not cur if cur is not None else True
            ok, msg = sysinfo.set_bt(want)
            if ok:
                self._bt_msg = ""
                self._hide_hint()
            elif want:
                self._show_hint(_("Bluetooth не включился: %s")
                                % (msg or _("неизвестная ошибка")))
            else:
                self._show_hint(_("Не удалось выключить Bluetooth: %s")
                                % (msg or _("неизвестная ошибка")))
        elif key == "dark":
            self._toggle_theme()
        elif key == "dnd":
            cfg = config.load()
            cur = cfg.getboolean("general", "dnd", fallback=False)
            config.set_option("general", "dnd", "true" if not cur else "false")
        GLib.timeout_add(400, self._refresh)
        return True

    def _show_hint(self, text, seconds=8):
        """Показать сообщение об ошибке под плитками на несколько секунд."""
        self._hint_seq += 1
        seq = self._hint_seq
        self.hint_label.set_text(text)
        self.hint_label.show()

        def _clear():
            if seq == self._hint_seq:
                self.hint_label.set_text("")
                self.hint_label.hide()
            return False

        GLib.timeout_add_seconds(seconds, _clear)

    def _hide_hint(self):
        self._hint_seq += 1
        self.hint_label.set_text("")
        self.hint_label.hide()

    def _toggle_theme(self):
        new = "dark" if not config.is_dark() else "light"
        config.set_option("general", "theme", new)
        # применяем к GTK-приложениям сеанса сразу
        gtk_theme = "lg-gtk-dark" if new == "dark" else "lg-gtk"
        wm_theme = "lg-dark" if new == "dark" else "lg-light"
        for channel, prop, value in (
            ("xsettings", "/Net/ThemeName", gtk_theme),
            ("xfwm4", "/general/theme", wm_theme),
        ):
            _spawn(["xfconf-query", "-c", channel, "-p", prop, "-s", value])
        # Chrome/Chromium на Linux смотрит на GNOME color-scheme и gtk-theme,
        # а не только на XSettings Xfce. Без этого браузер мог оставаться в
        # противоположной теме после переключения.
        if sysinfo.which("gsettings"):
            scheme = "prefer-dark" if new == "dark" else "prefer-light"
            _spawn(["gsettings", "set", "org.gnome.desktop.interface",
                    "color-scheme", scheme])
            _spawn(["gsettings", "set", "org.gnome.desktop.interface",
                    "gtk-theme", gtk_theme])
        GLib.timeout_add(400, self._refresh)

    def _on_bright(self, scale):
        if self._suppress:
            return
        sysinfo.set_brightness(scale.get_value())

    def _on_vol(self, scale):
        if self._suppress:
            return
        sysinfo.set_volume(scale.get_value())

    def _open_settings(self, *_a):
        for cmd in (["xfce4-settings-manager"], ["systemsettings"],
                    ["gnome-control-center"]):
            import shutil  # noqa: PLC0415
            if shutil.which(cmd[0]):
                _spawn(cmd)
                return
        _spawn(["xfce4-settings-manager"])

    def _power_menu(self, _btn):
        menu = Gtk.Menu()
        for label, action in (
            (_("Завершение работы"), sysinfo.poweroff),
            (_("Перезагрузка"), sysinfo.reboot),
            (_("Выход из сеанса"), sysinfo.logout),
        ):
            mi = Gtk.MenuItem(label=label)
            mi.connect("activate", lambda *_a, cb=action: cb())
            menu.append(mi)
        menu.show_all()
        menu.connect("selection-done", lambda m: GLib.idle_add(m.destroy))
        menu.popup_at_widget(getattr(self, "btn_power", self.tiles["wifi"]),
                             Gdk.Gravity.SOUTH_WEST,
                             Gdk.Gravity.NORTH_WEST, None)

    def _on_bg_press(self, _w, ev):
        if ev.button == 1:
            self.hide()
            return True
        return False

    def _on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.hide()
            return True
        return False

    def toggle(self):
        if self.get_visible():
            self.hide()
        else:
            self._pw_ssid = None
            self._pw_error = ""
            self._position()
            self._refresh()
            if self._wifi_on:
                self._reload_wifi()
            if self._bt_on:
                self._load_bt()
            self.show_all()
            self._sync_tabs()
            self.present()


def main():
    ControlCenterApp().run([])


if __name__ == "__main__":
    main()

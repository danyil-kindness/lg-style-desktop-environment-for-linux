#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# LG G2/G3 Shell installer for Linux (X11 + Xfce).
#
# Usage:
#   ./install.sh              install components (asks for sudo)
#   ./install.sh --default    also make LG UX the default LightDM session
#   ./install.sh --boot       install and select the LG Plymouth boot theme
#   ./install.sh --no-deps    do not check/install dependency packages
#
# The existing Xfce desktop is NOT removed: LG UX is an additional login
# session. The login splash is shown by the session; with --boot the Plymouth
# boot theme is installed as well.

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SHARE_DST="/usr/share/lg-shell"
BIN_DST="/usr/local/bin"
THEMES_DST="/usr/share/themes"
BG_DST="/usr/share/backgrounds/lg"
SESSION_DST="/usr/share/xsessions"

WITH_DEPS=1
SET_DEFAULT=0
INSTALL_BOOT=0
for arg in "$@"; do
    case "$arg" in
        --default) SET_DEFAULT=1 ;;
        --boot) INSTALL_BOOT=1 ;;
        --no-deps) WITH_DEPS=0 ;;
        -h|--help) awk 'NR>2 && /^#/ {sub(/^# ?/, ""); print; next} NR>2 {exit}' "$0"; exit 0 ;;
        *) echo "Неизвестный параметр: $arg" >&2; exit 1 ;;
    esac
done

if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
        echo "Для установки в систему нужны права sudo."
        exec sudo bash "$0" "$@"
    fi
    echo "Запустите от root или установите sudo." >&2
    exit 1
fi

# пользователь, запустивший sudo (для настройки его xfconf-ключей)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)

echo "== Проверка зависимостей =="

# Проверяем по фактическим командам/модулям, ставим по именам пакетов apt
MISSING_REQ=()
py_ok() { python3 -c "$1" >/dev/null 2>&1; }
add_if_missing() {           # команда пакет
    command -v "$1" >/dev/null 2>&1 || MISSING_REQ+=("$2")
}

command -v python3 >/dev/null 2>&1 || MISSING_REQ+=("python3")
py_ok "import gi" || MISSING_REQ+=("python3-gi")
py_ok "import cairo" || MISSING_REQ+=("python3-cairo")
py_ok "import dbus" || MISSING_REQ+=("python3-dbus")
py_ok "import gi; gi.require_version('Gtk','3.0'); from gi.repository import Gtk" \
    || MISSING_REQ+=("gir1.2-gtk-3.0")
py_ok "import gi; gi.require_version('Wnck','3.0'); from gi.repository import Wnck" \
    || MISSING_REQ+=("gir1.2-wnck-3.0")
add_if_missing xfwm4 xfwm4
add_if_missing xfsettingsd xfce4-settings
add_if_missing xfconf-query xfconf

if [ "${#MISSING_REQ[@]}" -gt 0 ]; then
    echo "Missing required packages: ${MISSING_REQ[*]}"
    if [ "$WITH_DEPS" -eq 1 ]; then
        if command -v apt-get >/dev/null 2>&1; then
            read -r -p "Install them with apt-get? [Y/n] " ans
            if [[ -z "$ans" || "$ans" =~ ^[ДдDdYy] ]]; then
                apt-get update -qq || true
                if ! DEBIAN_FRONTEND=noninteractive apt-get install -y "${MISSING_REQ[@]}"; then
                    echo "Could not install: ${MISSING_REQ[*]}" >&2
                    echo "Install them manually and run the installer again." >&2
                    exit 1
                fi
            else
                echo "Continuing without them; the shell may not work." >&2
            fi
        else
            echo "Automatic dependency installation is only implemented for apt-based distributions." >&2
            echo "Install the packages listed in INSTALL.md, then run:" >&2
            echo "  ./install.sh --no-deps" >&2
            exit 1
        fi
    else
        echo "Continuing without them (--no-deps); install missing packages if needed." >&2
    fi
fi

MISSING_OPT=()
add_opt() {                  # команда пакет
    command -v "$1" >/dev/null 2>&1 || MISSING_OPT+=("$2")
}
add_opt xfdesktop xfdesktop4
add_opt xfce4-session xfce4-session
add_opt nmcli network-manager
add_opt bluetoothctl bluez
add_opt brightnessctl brightnessctl
[ -d /usr/share/icons/Papirus ] || MISSING_OPT+=("papirus-icon-theme")
add_opt light-locker light-locker
add_opt xfce4-power-manager xfce4-power-manager
add_opt plymouth plymouth
add_opt plymouth-set-default-theme plymouth
if [ "${#MISSING_OPT[@]}" -gt 0 ]; then
    echo "Рекомендуемые пакеты отсутствуют (работать будет, но лучше поставить):"
    echo "  ${MISSING_OPT[*]}"
fi

echo "== Установка файлов =="

install -d "$SHARE_DST" "$BIN_DST" "$THEMES_DST" "$BG_DST" "$SESSION_DST"

# 1. Python-пакет оболочки
rm -rf "${SHARE_DST}/lg_shell"
cp -r "$ROOT_DIR/share/lg_shell" "$SHARE_DST/lg_shell"
# не тащим в установку кэш байткода из дерева исходников
find "${SHARE_DST}/lg_shell" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find "${SHARE_DST}/lg_shell" -type f \( -name '*.pyc' -o -name '*.pyo' \) -delete 2>/dev/null || true
chmod -R a+rX "$SHARE_DST"

# 2. Команды
for f in "$ROOT_DIR"/bin/lg-*; do
    install -m 0755 "$f" "$BIN_DST/$(basename "$f")"
done

# 3. Скрипт сеанса (с бэкапом прошлой версии)
if [ -f "$BIN_DST/lg-session" ] && ! grep -q "Сеанс «LG UX»" "$BIN_DST/lg-session" 2>/dev/null; then
    cp -a "$BIN_DST/lg-session" "$BIN_DST/lg-session.bak.$(date +%Y%m%d%H%M%S)"
    echo "  прежний lg-session сохранён как *.bak"
fi
install -m 0755 "$ROOT_DIR/session/lg-session" "$BIN_DST/lg-session"

# 4. Сеанс входа
install -m 0644 "$ROOT_DIR/session/lg.desktop" "$SESSION_DST/lg-ux.desktop"

# 5. Темы GTK
python3 "$ROOT_DIR/tools/gen_gtk_theme.py" --dest "$THEMES_DST"

# 6. Темы окон xfwm4 (с откатом на Mint-Y при сбое генерации)
for variant in light dark; do
    tdir="${THEMES_DST}/lg-${variant}"
    if ! python3 "$ROOT_DIR/tools/gen_xfwm4.py" --variant "$variant" --dest "$tdir"; then
        echo "  генерация xfwm4 (${variant}) не удалась — копирую Mint-Y как основу"
        base="Mint-Y"
        [ "$variant" = dark ] && base="Mint-Y-Dark"
        rm -rf "${tdir}/xfwm4"
        cp -r "/usr/share/themes/${base}/xfwm4" "${tdir}/xfwm4"
        [ -f "${THEMES_DST}/lg-gtk/index.theme" ] || true
    fi
    chmod -R a+rX "$tdir"
done

# 7. Заставки
python3 "$ROOT_DIR/tools/gen_wallpaper.py" --dest "$BG_DST"

# 8. Анимация включения LG: Plymouth-тема (нужен флаг --boot)
if [ "$INSTALL_BOOT" -eq 1 ]; then
    echo "== Plymouth-тема LG UX =="
    BOOT_DST="/usr/share/plymouth/themes/lg-ux"
    install -d "$BOOT_DST"
    USER_LANG=$(echo "${LANG:-ru}" | cut -c1-2)
    case "$USER_LANG" in
        ru|en|pl|uk) BOOT_LANG="$USER_LANG" ;;
        *) BOOT_LANG="en" ;;
    esac
    python3 "$ROOT_DIR/tools/gen_boot_animation.py" \
        --dest "$BOOT_DST" --lang "$BOOT_LANG" --image-dir "$BOOT_DST"
    chmod -R a+rX "$BOOT_DST"

    # Plymouth нужно не только положить в /usr/share, но и выбрать тему,
    # а затем пересобрать initramfs. В Ubuntu/Mint plymouth-set-default-theme
    # может отсутствовать, а initramfs-hook выбирает тему не из
    # /etc/plymouth/plymouthd.conf, а из update-alternatives default.plymouth.
    # Поэтому сначала регистрируем и выбираем lg-ux как alternative — иначе
    # в initramfs попадёт старая тема (например, meizu-flyme), хотя в
    # plymouthd.conf уже стоит Theme=lg-ux.
    PLYMOUTH_ALT="/usr/share/plymouth/themes/default.plymouth"
    PLYMOUTH_THEME="$BOOT_DST/lg-ux.plymouth"
    if command -v update-alternatives >/dev/null 2>&1; then
        update-alternatives --install "$PLYMOUTH_ALT" default.plymouth \
            "$PLYMOUTH_THEME" 400 >/dev/null 2>&1 || true
        if update-alternatives --set default.plymouth "$PLYMOUTH_THEME" \
                >/dev/null 2>&1; then
            echo "  Plymouth: alternative default.plymouth → lg-ux."
        else
            echo "  Не удалось выбрать default.plymouth через update-alternatives."
        fi
    fi

    PLYMOUTH_SET=0
    if command -v plymouth-set-default-theme >/dev/null 2>&1; then
        if plymouth-set-default-theme lg-ux -R; then
            PLYMOUTH_SET=1
            echo "  Plymouth: тема lg-ux включена по умолчанию."
        else
            echo "  plymouth-set-default-theme не сработал — правлю конфиг вручную."
        fi
    fi

    if [ "$PLYMOUTH_SET" -eq 0 ]; then
        PLYMOUTH_CONF="/etc/plymouth/plymouthd.conf"
        install -d /etc/plymouth
        if [ -f "$PLYMOUTH_CONF" ]; then
            cp -a "$PLYMOUTH_CONF" \
                "${PLYMOUTH_CONF}.bak.$(date +%Y%m%d%H%M%S)"
        fi
        python3 - "$PLYMOUTH_CONF" <<'PY'
import sys
from pathlib import Path

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8") if path.exists() else ""
out = []
in_daemon = False
daemon_found = False
theme_set = False
for line in text.splitlines():
    stripped = line.strip()
    if stripped.startswith("[") and stripped.endswith("]"):
        if in_daemon and not theme_set:
            out.append("Theme=lg-ux")
            theme_set = True
        in_daemon = stripped.lower() == "[daemon]"
        daemon_found = daemon_found or in_daemon
        out.append(line)
        continue
    if in_daemon and stripped.startswith("Theme="):
        out.append("Theme=lg-ux")
        theme_set = True
    else:
        out.append(line)
if in_daemon and not theme_set:
    out.append("Theme=lg-ux")
    theme_set = True
if not daemon_found:
    if out and out[-1].strip():
        out.append("")
    out.extend(["[Daemon]", "Theme=lg-ux"])
path.write_text("\n".join(out) + "\n", encoding="utf-8")
PY
        if command -v update-initramfs >/dev/null 2>&1; then
            if update-initramfs -u; then
                echo "  Plymouth: тема lg-ux выбрана, initramfs пересобран."
            else
                echo "  Не удалось пересобрать initramfs. Выполните: sudo update-initramfs -u"
            fi
        elif command -v dracut >/dev/null 2>&1; then
            if dracut -f; then
                echo "  Plymouth: тема lg-ux выбрана, initramfs пересобран (dracut)."
            else
                echo "  Не удалось пересобрать initramfs. Выполните: sudo dracut -f"
            fi
        elif command -v mkinitcpio >/dev/null 2>&1; then
            if mkinitcpio -P; then
                echo "  Plymouth: тема lg-ux выбрана, initramfs пересобран (mkinitcpio)."
            else
                echo "  Не удалось пересобрать initramfs. Выполните: sudo mkinitcpio -P"
            fi
        else
            echo "  Пересоберите initramfs вручную (update-initramfs, dracut или mkinitcpio)."
        fi
    fi

    if command -v lsinitramfs >/dev/null 2>&1 \
            && ! lsinitramfs "/boot/initrd.img-$(uname -r)" 2>/dev/null \
                | grep -q "themes/lg-ux/"; then
        echo "  Внимание: темы lg-ux пока нет в текущем initramfs."
        echo "  Проверьте: readlink -f /usr/share/plymouth/themes/default.plymouth"
        echo "  и пересоберите initramfs для вашего дистрибутива."
    fi
    if command -v update-alternatives >/dev/null 2>&1; then
        current_plymouth=$(readlink -f "$PLYMOUTH_ALT" 2>/dev/null || true)
        if [ "$current_plymouth" != "$PLYMOUTH_THEME" ]; then
            echo "  Внимание: default.plymouth указывает на ${current_plymouth:-неизвестно}."
            echo "  Выполните: sudo update-alternatives --set default.plymouth $PLYMOUTH_THEME"
        fi
    fi
fi

# 9. Горячие клавиши (глобальные — работают и в Xfce, команды только наши)
echo "== Горячие клавиши =="
as_user() {
    local u="$1"; shift
    local uid
    uid=$(id -u "$u")
    if [ "$(id -u)" -eq 0 ] && [ "$u" != root ]; then
        # sudo сбрасывает окружение — восстанавливаем D-Bus и X сессии пользователя
        sudo -u "$u" env HOME="$REAL_HOME" \
            DISPLAY="${DISPLAY:-:0}" \
            XDG_RUNTIME_DIR="/run/user/${uid}" \
            DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${uid}/bus" \
            "$@"
    else
        "$@"
    fi
}

set_shortcut() {   # имя клавиша команда подпись
    local name="$1" key="$2" cmd="$3" label="$4"
    if ! command -v xfconf-query >/dev/null 2>&1; then return 0; fi
    as_user "$REAL_USER" xfconf-query -c xfce4-keyboard-shortcuts \
        -p "/global/custom/${name}/name" -n -t string -s "$label" >/dev/null 2>&1 || true
    as_user "$REAL_USER" xfconf-query -c xfce4-keyboard-shortcuts \
        -p "/global/custom/${name}/binding" -n -t string -s "$key" >/dev/null 2>&1 || true
    as_user "$REAL_USER" xfconf-query -c xfce4-keyboard-shortcuts \
        -p "/commands/custom/${name}" -n -t string -s "$cmd" >/dev/null 2>&1 || true
    echo "  ${key} → ${cmd}"
}

set_shortcut "lg-launcher"    "<Super>space" "lg-launcher"    "LG: лаунчер"
set_shortcut "lg-control"     "<Super>a"     "lg-control-center" "LG: центр управления"
set_shortcut "lg-lock"        "<Super>l"     "lg-lock"        "LG: блокировка"

# мультимедийные клавиши ноутбука
set_shortcut "lg-vol-up"   "<XF86AudioRaiseVolume>" \
    "pactl set-sink-volume @DEFAULT_SINK@ +5%" "Громкость +"
set_shortcut "lg-vol-down" "<XF86AudioLowerVolume>" \
    "pactl set-sink-volume @DEFAULT_SINK@ -5%" "Громкость −"
set_shortcut "lg-mute"     "<XF86AudioMute>" \
    "pactl set-sink-mute @DEFAULT_SINK@ toggle" "Выключить звук"

# 10. Сеанс по умолчанию (по желанию)
if [ "$SET_DEFAULT" -eq 1 ]; then
    echo "== Сеанс LG UX по умолчанию =="
    LM_CONF="/etc/lightdm/lightdm.conf"
    if [ -f "$LM_CONF" ]; then
        cp -a "$LM_CONF" "${LM_CONF}.bak.$(date +%Y%m%d%H%M%S)"
        if grep -qE '^\s*user-session=' "$LM_CONF"; then
            sed -i -E "s|^\s*user-session=.*|user-session=lg-ux|" "$LM_CONF"
        else
            printf '\n[Seat:*]\nuser-session=lg-ux\n' >> "$LM_CONF"
        fi
        echo "  LightDM: user-session=lg-ux"
    else
        echo "  $LM_CONF не найден — пропущено."
    fi
fi

echo
echo "== Установка завершена =="
echo "1. Выйдите из текущего сеанса (или перезагрузитесь)."
echo "2. На экране входа выберите сеанс «LG UX»."
echo "3. XFCE осталось нетронутым — переключайтесь между сеансами как обычно."
echo
echo "Горячие клавиши: Super+Пробел — лаунчер, Super+A — центр управления,"
echo "Super+L — блокировка. Настройки: ~/.config/lg-shell/config.ini"
echo "Просмотр анимации включения: lg-splash --preview"
[ "$INSTALL_BOOT" -eq 1 ] || echo "Plymouth-тема не включена: запустите ./install.sh --boot"

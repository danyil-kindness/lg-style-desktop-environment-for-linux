# Installation guide

This guide explains how to install **LG G2/G3 Shell** on a Linux system. The
project is a GTK3/X11 shell that runs as its own login session and uses Xfce
components. It is not a complete Linux distribution and it does not replace
your existing desktop.

## 1. What you need

- A Linux distribution with **X11**.
- A display manager: **LightDM** is recommended; SDDM and GDM also work when
  you select the X11 session.
- Xfce runtime components: `xfwm4`, `xfce4-settings`, `xfconf`, `xfdesktop`,
  `xfce4-session`.
- Python 3 with PyGObject, GTK3, Cairo and D-Bus.
- `libwnck-3` GObject bindings.

> **Wayland is not supported.** The panel uses XEmbed and X11 window APIs, and
> the session starts `xfwm4` as the window manager.

## 2. Install dependencies

Choose the section for your distribution. Package names can change between
releases; if a package is unavailable, search for the equivalent package.

### Debian, Ubuntu, Linux Mint

```bash
sudo apt update
sudo apt install \
  python3 python3-gi python3-cairo python3-dbus \
  gir1.2-gtk-3.0 gir1.2-wnck-3.0 \
  xfwm4 xfce4-settings xfconf xfdesktop4 xfce4-session \
  network-manager bluez brightnessctl pulseaudio-utils \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

### Fedora

```bash
sudo dnf install \
  python3 python3-gobject python3-cairo python3-dbus \
  gtk3 libwnck3 \
  xfwm4 xfce4-settings xfconf xfdesktop xfce4-session \
  NetworkManager bluez brightnessctl pulseaudio-utils \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

### Arch Linux

```bash
sudo pacman -S --needed \
  python python-gobject python-cairo python-dbus \
  gtk3 libwnck3 \
  xfwm4 xfce4-settings xfconf xfdesktop xfce4-session \
  networkmanager bluez bluez-utils brightnessctl libpulse \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

### openSUSE

```bash
sudo zypper install \
  python3 python3-gobject python3-cairo python3-dbus \
  typelib-1_0-Gtk-3_0 typelib-1_0-Wnck-3_0 \
  xfwm4 xfce4-settings xfconf xfdesktop xfce4-session \
  NetworkManager bluez brightnessctl pulseaudio-utils \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

`light-locker`, `plymouth` and `lightdm` are optional, but recommended. If you
already have a display manager, keep it and select the LG UX session there.

## 3. Download and install

Download the release archive or clone the repository, then enter the project
directory:

```bash
tar -xzf lg-shell-g2g3-1.0.0.tar.gz
cd lg-shell
```

Install the shell:

```bash
chmod +x install.sh uninstall.sh bin/lg-*
./install.sh
```

The installer asks for `sudo` and installs the files into system locations.
It does not remove Xfce.

### Non-apt distributions

The installer can automatically install dependencies only on **apt-based**
systems. On Fedora, Arch, openSUSE and others, install the packages from
section 2 first, then run:

```bash
./install.sh --no-deps
```

### Optional flags

```bash
./install.sh --default        # make LG UX the default LightDM session
./install.sh --boot           # install the LG Plymouth boot theme
./install.sh --no-deps        # do not check/install dependencies
```

Flags can be combined:

```bash
./install.sh --default --boot
```

The installer creates:

- `/usr/share/lg-shell/` — Python application files;
- `/usr/local/bin/lg-*` — commands and session helper;
- `/usr/share/themes/lg-*` — GTK and xfwm4 themes;
- `/usr/share/backgrounds/lg/` — LG wallpapers;
- `/usr/share/xsessions/lg-ux.desktop` — login session entry;
- `/usr/share/plymouth/themes/lg-ux/` — boot theme, only with `--boot`.

## 4. Start the LG session

1. Log out completely.
2. On the login screen, open the session menu (gear icon or session selector).
3. Choose **LG UX**.
4. Log in.

If the session is not listed, check that the file exists:

```bash
cat /usr/share/xsessions/lg-ux.desktop
```

and that `/usr/local/bin/lg-session` is executable.

To make LG UX the default with LightDM:

```bash
sudo ./install.sh --default
```

For SDDM or GDM, select the session in the display manager’s session menu; the
installer’s `--default` option only edits LightDM configuration.

## 5. Boot animation (optional)

The session splash is installed automatically. The **system boot** Plymouth
theme is installed with `--boot`.

On Debian, Ubuntu and Linux Mint:

```bash
sudo ./install.sh --boot
```

The script selects the theme through `update-alternatives` and runs
`update-initramfs -u`.

On other distributions, after `--boot`:

```bash
sudo plymouth-set-default-theme -R lg-ux
# Fedora: sudo dracut -f
# Arch:   sudo mkinitcpio -P
```

Make sure `splash` is present in your kernel command line. On GRUB systems it
is usually in `GRUB_CMDLINE_LINUX_DEFAULT`; after editing, run
`sudo update-grub`.

## 6. Verify the installation

Log in to LG UX and check:

- `Super+Space` opens the launcher;
- `Super+A` opens the control center;
- the panel is at the top and the dock is at the bottom;
- the control center shows Network, Display & sound, and General tabs;
- the weather card opens the city dialog when clicked.

Logs are written to `~/.config/lg-shell/logs/`.

## 7. Uninstall

```bash
cd lg-shell
./uninstall.sh
```

To remove the user configuration as well:

```bash
./uninstall.sh --purge
```

Xfce and your personal files are not removed.

## 8. Common installation problems

### `xfconf-query: command not found`

Install the `xfconf` package for your distribution.

### `No module named gi` or `No module named cairo`

Install the Python GObject/GTK3/Cairo packages listed in section 2. The package
names are `python3-gi` and `python3-cairo` on Debian-family systems,
`python3-gobject` and `python3-cairo` on Fedora, and `python-gobject` and
`python-cairo` on Arch.

### The session appears but the screen is empty

Check `~/.config/lg-shell/logs/lg-session.log` and the component logs. Make sure
`xfwm4` is installed and that you are using an X11 session, not Wayland.

### The panel has no tray icons

Close any other system tray host, such as `xfce4-panel` or `stalonetray`, then
restart the application. The LG panel provides its own XEmbed tray.

### The boot theme is still the old one

Reinstall with `--boot`, then verify:

```bash
readlink -f /usr/share/plymouth/themes/default.plymouth
lsinitramfs /boot/initrd.img-$(uname -r) | grep themes/lg-ux
```

If the theme is not in initramfs, rebuild it using the command for your
distribution (`update-initramfs -u`, `dracut -f` or `mkinitcpio -P`).

### Plymouth is not installed

You can skip `--boot`. The session splash (`lg-splash`) still works.

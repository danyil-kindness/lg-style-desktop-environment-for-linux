# LG G2/G3 Shell for Linux

A native GTK3 desktop shell inspired by **LG G2/G3 (2013–2014)**. It runs as a
separate **LG UX** session on top of Xfce components, so you can keep your normal
Xfce desktop and choose the LG session at the login screen.

The shell replaces the Xfce panel, dock, desktop overlays and notifications with
its own components. It does **not** remove or modify your Xfce installation.

> This is an independent style project. “LG”, “LG UX” and “Life’s Good” are
> trademarks of their respective owners. All artwork in this repository is
> drawn from scratch; no official LG assets are included.

![LG G2/G3 home screen](docs/screenshot-home.png)

## Features

| Component | What it does |
|---|---|
| **Boot animation** | LG-style splash at session login and, with `--boot`, a Plymouth theme for system boot/shutdown. |
| **Panel** | Dark translucent top bar with LG mark, clock, open-window list, system tray, battery, Wi-Fi, volume, Do Not Disturb and control center. |
| **System tray** | Built-in XEmbed host (`_NET_SYSTEM_TRAY_S0`); no external tray daemon required. |
| **Home screen** | Full-screen launcher (`Super+Space`) with weather/clock card, search, category tabs, app grid and dock. Click the weather card to choose a city. |
| **Control center** | Quick settings with **Network**, **Display & sound**, and **General** tabs (`Super+A`): Wi-Fi, Bluetooth, dark theme, brightness, volume, language, wallpaper, screenshot, lock, logout and power. |
| **Dock** | Rounded dark dock with pinned/running apps, labels, running indicator and auto-hide behavior. |
| **Notifications** | Built-in `org.freedesktop.Notifications` daemon with LG-style white cards. |
| **Lock screen** | LG wallpaper, large clock, date and unlock button (`Super+L`). This is a visual lock screen, not a security boundary; use `light-locker` for real locking. |
| **Themes** | `lg-gtk` / `lg-gtk-dark`, xfwm4 `lg-light` / `lg-dark`, and `lg-light` / `lg-dark` wallpapers. |

The older **LG UX 10** look is preserved in
[`legacy/lg-shell-ux10/`](legacy/lg-shell-ux10/). It has its own installer and
README. Both versions install to the same paths and use the same session name,
so installing one replaces the other.

## Requirements

The shell is **X11-only**. It uses `xfwm4`, `xfsettingsd`, `xfdesktop`, XEmbed
and X11 window APIs. It does **not** work under a Wayland-only session.

Minimum runtime:

- Linux with X11 and a display manager (LightDM recommended).
- Python 3 with PyGObject, GTK3, Cairo and D-Bus bindings.
- Xfce components: `xfwm4`, `xfce4-settings` (`xfsettingsd`), `xfconf`,
  `xfdesktop`, `xfce4-session`.
- `libwnck-3` GObject bindings (window list and fullscreen detection).
- Recommended: `pactl` (audio), `brightnessctl`, `nmcli` (NetworkManager),
  `bluetoothctl` (BlueZ), Papirus icons, `light-locker`, Plymouth.

Tested on **Linux Mint 22.3 (Xfce)**. Other distributions work when the packages
below are installed.

### Debian / Ubuntu / Linux Mint

```bash
sudo apt update
sudo apt install \
  python3 python3-gi python3-cairo python3-dbus \
  gir1.2-gtk-3.0 gir1.2-wnck-3.0 \
  xfwm4 xfce4-settings xfconf xfdesktop4 xfce4-session \
  network-manager bluez brightnessctl pulseaudio-utils \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

### Fedora

```bash
sudo dnf install \
  python3 python3-gobject python3-cairo python3-dbus \
  gtk3 libwnck3 \
  xfwm4 xfce4-settings xfconf xfdesktop xfce4-session \
  NetworkManager bluez brightnessctl pulseaudio-utils \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

### Arch Linux

```bash
sudo pacman -S --needed \
  python python-gobject python-cairo python-dbus \
  gtk3 libwnck3 \
  xfwm4 xfce4-settings xfconf xfdesktop xfce4-session \
  networkmanager bluez bluez-utils brightnessctl libpulse \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

### openSUSE

```bash
sudo zypper install \
  python3 python3-gobject python3-cairo python3-dbus \
  typelib-1_0-Gtk-3_0 typelib-1_0-Wnck-3_0 \
  xfwm4 xfce4-settings xfconf xfdesktop xfce4-session \
  NetworkManager bluez brightnessctl pulseaudio-utils \
  papirus-icon-theme light-locker plymouth \
  lightdm lightdm-gtk-greeter
```

Package names differ between releases. If a package is missing, search your
distribution for the equivalent GTK3/PyGObject/Xfce package. The installer’s
automatic dependency installation is implemented for **apt**; on other
distributions install the packages first and use `--no-deps`.

## Install

A detailed, distro-neutral walkthrough is in **[INSTALL.md](INSTALL.md)**.

From the folder containing `install.sh`:

```bash
chmod +x install.sh uninstall.sh bin/lg-*
./install.sh
```

If you downloaded a GitHub ZIP, the folder may be named `lg-shell-main`;
enter it first (`cd lg-shell-main`).

The installer asks for `sudo` and installs:

- `/usr/share/lg-shell/`
- `/usr/local/bin/lg-*`
- `/usr/share/themes/lg-*`
- `/usr/share/backgrounds/lg/`
- `/usr/share/xsessions/lg-ux.desktop`
- Plymouth theme (only with `--boot`)

### Installer flags

| Flag | Effect |
|---|---|
| `--default` | Make `lg-ux` the default LightDM session. |
| `--boot` | Install and select the LG Plymouth boot theme, then rebuild initramfs. |
| `--no-deps` | Do not check or install dependencies. |

Flags can be combined:

```bash
./install.sh --default --boot
```

On non-apt distributions:

```bash
./install.sh --no-deps
```

### After installation

1. Log out.
2. At the login screen, choose the **LG UX** session (session menu/gear icon).
3. Log in. Your normal Xfce session remains available.

With **LightDM**, `--default` sets `user-session=lg-ux`. With **SDDM**, **GDM**
or another display manager, choose the X11 “LG UX” session in its session menu.
Do not choose a Wayland session for this shell.

### If you use `startx`

The shell expects Xfce helper services, but you can start it from a custom
`~/.xinitrc`:

```sh
exec /usr/local/bin/lg-session
```

A display manager is recommended because it gives you a clean way to switch
between LG UX and your normal desktop.

## Configuration

The configuration file is created at `~/.config/lg-shell/config.ini`:

```ini
[general]
design = g3          # g3: current G2/G3 look
theme = light        # light | dark
accent = #00A6C0     # accent colour; the LG red mark stays in the logo
language = auto      # auto | ru | en | pl | uk

[weather]
city = auto          # auto: IP geolocation; or e.g. Moscow, Warsaw, Berlin

[panel]
height = 36
show_date = true
tray = true

[dock]
icon_size = 48
autohide = false
pinned = firefox,thunar,xfce4-terminal

[splash]
enabled = true
duration = 3.0

[lock]
command = lg-lock    # for real locking: light-locker-command -l
```

Theme changes apply immediately to the shell components. Existing GTK
applications may need to be restarted.

### Language

The interface supports **English, Russian, Polish and Ukrainian**. With
`language = auto`, the shell uses the system locale when it is one of those four
languages, otherwise English. You can also switch language in the control center
(**General → Language**).

### Weather city

The weather widget uses `wttr.in` in a background thread and caches the result
for 30 minutes.

1. Open the home screen (`Super+Space`).
2. Click the weather card.
3. Enter a city and press **Save**, or press **Detect automatically** to use
   IP-based geolocation.

Changing the city clears the weather cache immediately. The cache is stored in
`~/.cache/lg-shell/weather.json`.

### Theme and browsers

When you switch between light and dark themes, the shell updates:

- Xfce `Net/ThemeName` and the xfwm4 theme;
- GNOME `color-scheme` and `gtk-theme` (used by Chrome, Chromium and some GTK
  applications);
- the `GTK_THEME` environment for browsers launched from the LG home screen or
  dock.

The original GNOME settings are backed up and restored when the LG session
ends. If a browser was already running, restart it once after changing the
theme. If the browser uses its own non-GTK theme, select its system/GTK theme.

## Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Super+Space` | Application launcher |
| `Super+A` | Control center |
| `Super+L` | Lock screen |
| `XF86AudioRaiseVolume` / `LowerVolume` / `Mute` | Volume |

The shortcuts are installed as Xfce global shortcuts. The old `Super+L` binding
is temporarily disabled during the LG session and restored on logout.

## Boot animation

The project has two independent animations:

1. **Session login splash** — `lg-splash`, controlled by `[splash]` in
   `config.ini`. Preview it without logging out:

   ```bash
   lg-splash --preview
   lg-splash --once
   ```

2. **System boot/shutdown** — the `lg-ux` Plymouth theme, installed with:

   ```bash
   sudo ./install.sh --boot
   ```

   On Debian/Ubuntu/Mint the installer registers `default.plymouth` via
   `update-alternatives` and rebuilds initramfs with `update-initramfs -u`.

   On other distributions, after installing the theme, select it and rebuild
   your initramfs:

   ```bash
   sudo plymouth-set-default-theme -R lg-ux
   # Fedora: sudo dracut -f
   # Arch:   sudo mkinitcpio -P
   ```

   The kernel command line must include `splash` (usually in
   `GRUB_CMDLINE_LINUX_DEFAULT`; run `sudo update-grub` after changing it).

   Verify on Debian-family systems:

   ```bash
   readlink -f /usr/share/plymouth/themes/default.plymouth
   lsinitramfs /boot/initrd.img-$(uname -r) | grep themes/lg-ux
   ```

## Troubleshooting

- **No rounded corners or transparency** — make sure the xfwm4 compositor is
  enabled: `xfconf-query -c xfwm4 -p /general/use_compositing` should be `true`.
- **No splash at login** — check `[splash] enabled = true`, and read
  `~/.config/lg-shell/logs/lg-splash.log`.
- **Wrong boot theme** — reinstall with `--boot`, then check the Plymouth
  alternative and initramfs as shown above.
- **No audio or brightness controls** — install `pulseaudio-utils` and
  `brightnessctl`; check `pactl info` and `brightnessctl -m`.
- **Bluetooth does not toggle** — start/enable the service:
  `sudo systemctl enable --now bluetooth`. If rfkill blocks it:
  `sudo rfkill unblock bluetooth`.
- **Some icons are missing** — install `papirus-icon-theme`.
- **A GTK app still uses the old theme** — restart that application.
- **Panel or dock disappeared** — run `lg-panel` or `lg-dock`; logs are in
  `~/.config/lg-shell/logs/`.
- **Tray icons are missing** — the application must support XEmbed. Close any
  other tray host (for example `xfce4-panel` or `stalonetray`), then restart
  the application.
- **Wallpaper changed** — the session never overwrites personal wallpapers.
  Apply the LG wallpaper explicitly with `lg-wallpaper` or
  `lg-wallpaper --dark`, or use **LG wallpaper** in the control center.

## Uninstall

```bash
./uninstall.sh            # components, themes, session and Plymouth theme
./uninstall.sh --purge    # also remove ~/.config/lg-shell
```

Xfce and its settings are not removed.

## Publishing this repository to GitHub

The repository is already structured as a standalone project. From the
`lg-shell/` directory:

```bash
git init
git add .
git commit -m "LG G2/G3 shell for Linux"
git branch -M main
git remote add origin https://github.com/USER/REPOSITORY.git
git push -u origin main
```

The `.gitignore` excludes Python caches, logs and release archives. For a
release, upload `lg-shell-g2g3-1.0.0.tar.gz` and `.zip` as GitHub Release
assets (do not commit them to the repository).

## Project layout

```
lg-shell/
├── bin/                  # lg-panel, lg-dock, lg-launcher, ...
├── boot/theme/           # Plymouth theme source
├── docs/                 # screenshots
├── legacy/lg-shell-ux10/ # preserved previous LG UX 10 version
├── session/              # X11 session script and .desktop file
├── share/lg_shell/       # GTK3 Python package
├── themes/               # GTK theme template
├── tools/                # theme/wallpaper/Plymouth generators
├── install.sh
├── uninstall.sh
└── README.md
```

## License and disclaimer

The code is released under the MIT License; see [LICENSE](LICENSE).

This project is not affiliated with LG. “LG”, “LG UX” and “Life’s Good” are
trademarks of their owners. The interface and artwork are an independent
stylization.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация GTK-тем lg-gtk (светлая) и lg-gtk-dark из шаблона.

Использование: gen_gtk_theme.py [--dest /usr/share/themes]
"""

import argparse
import os
import sys

PALETTES = {
    "light": dict(
        BG="#EAF8FA", SURFACE="#FFFFFF", SURFACE2="#E3F4F7",
        TEXT="#17272D", SUB="#647A82", ACCENT="#00A6C0", ACCENT_TEXT="#FFFFFF",
        BORDER="#D4E8EC", DANGER="#D93838", SUCCESS="#2E9E5B",
    ),
    "dark": dict(
        BG="#071417", SURFACE="#102328", SURFACE2="#17313A",
        TEXT="#F1FBFD", SUB="#9BB3BA", ACCENT="#45D9EB", ACCENT_TEXT="#06262B",
        BORDER="#234149", DANGER="#F06A6A", SUCCESS="#6FD08C",
    ),
}

INDEX_TMPL = """[Desktop Entry]
Type=X-GNOME-Metatheme
Name={name}
Comment=LG UX inspired theme
GtkTheme={gtk}
IconTheme={icons}
CursorTheme=Bibata-Modern-Ice
ButtonLayout=close,minimize,maximize
"""


def build(tpl, mode):
    css = tpl
    for key, val in PALETTES[mode].items():
        css = css.replace("{{%s}}" % key, val)
    return css


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default="/usr/share/themes")
    ap.add_argument("--template", default=None,
                    help="путь к gtk.css.tpl (автоопределение)")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    repo_themes = os.path.join(os.path.dirname(here), "themes")
    tpl_path = args.template or os.path.join(repo_themes, "gtk.css.tpl")
    if not os.path.isfile(tpl_path):
        sys.stderr.write("Не найден шаблон: %s\n" % tpl_path)
        return 1
    with open(tpl_path, encoding="utf-8") as fh:
        tpl = fh.read()

    for mode, (theme_name, gtk_name, icons) in {
        "light": ("lg-gtk", "lg-gtk", "Papirus"),
        "dark": ("lg-gtk-dark", "lg-gtk-dark", "Papirus-Dark"),
    }.items():
        css = build(tpl, mode)
        base = os.path.join(args.dest, theme_name)
        for sub in ("gtk-3.0", "gtk-4.0"):
            d = os.path.join(base, sub)
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "gtk.css"), "w", encoding="utf-8") as fh:
                fh.write(css)
        with open(os.path.join(base, "index.theme"), "w", encoding="utf-8") as fh:
            fh.write(INDEX_TMPL.format(
                name="LG UX (%s)" % ("тёмная" if mode == "dark" else "светлая"),
                gtk=gtk_name, icons=icons,
            ))
        print("GTK-тема создана: %s" % base)
    return 0


if __name__ == "__main__":
    sys.exit(main())

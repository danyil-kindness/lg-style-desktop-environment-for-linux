#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация обоев LG G2/G3 (оригинальная абстрактная графика).

Стиль 2013–2014: яркое бирюзовое небо, диагональные лучи света и
розово-пурпурная волна внизу. Никаких логотипов и текста — только фон,
поверх которого домашний экран рисует виджет и иконки.

Использование: gen_wallpaper.py [--dest /usr/share/backgrounds/lg]
                               [--size 1920x1080]
"""

import argparse
import math
import os
import sys

import cairo

CYAN_TOP = (0.035, 0.690, 0.820)
CYAN_MID = (0.310, 0.850, 0.900)
PINK = (0.925, 0.180, 0.550)
MAGENTA = (0.690, 0.090, 0.470)
PURPLE = (0.330, 0.060, 0.360)
WHITE = (1.0, 1.0, 1.0)


def _wave(cr, w, h, y0, amp, color, alpha=1.0, phase=0.0, fill_to_bottom=True):
    """Плавная волна через безье-кривые."""
    cr.new_path()
    cr.move_to(0, h)
    cr.line_to(0, y0)
    steps = 8
    for i in range(steps + 1):
        t = i / steps
        x = t * w
        y = y0 + math.sin((t * 2.4 + phase) * math.pi) * amp
        if i == 0:
            cr.line_to(x, y)
        else:
            px = (i - 0.5) / steps * w
            cr.curve_to(px, y - amp * 0.15, px, y + amp * 0.15, x, y)
    if fill_to_bottom:
        cr.line_to(w, h)
    cr.close_path()
    cr.set_source_rgba(color[0], color[1], color[2], alpha)
    cr.fill()


def _beam(cr, x1, y1, x2, y2, width, color, alpha):
    """Широкий мягкий луч света (рисуем несколькими слоями)."""
    dx, dy = x2 - x1, y2 - y1
    length = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / length, dx / length
    for k, a in ((2.4, 0.10), (1.7, 0.12), (1.15, 0.16), (0.55, 0.24)):
        w2 = width * k
        cr.new_path()
        cr.move_to(x1 + nx * w2, y1 + ny * w2)
        cr.line_to(x2 + nx * w2, y2 + ny * w2)
        cr.line_to(x2 - nx * w2, y2 - ny * w2)
        cr.line_to(x1 - nx * w2, y1 - ny * w2)
        cr.close_path()
        cr.set_source_rgba(color[0], color[1], color[2], alpha * a)
        cr.fill()


def _bokeh(cr, w, h, seed=7, count=18, color=WHITE, alpha=0.08):
    """Мягкие расфокусированные круги — глубина сцены."""
    state = seed
    for _ in range(count):
        state = (state * 1103515245 + 12345) % 2147483648
        x = (state / 2147483648.0) * w
        state = (state * 1103515245 + 12345) % 2147483648
        y = (state / 2147483648.0) * h * 0.72
        state = (state * 1103515245 + 12345) % 2147483648
        r = (0.008 + (state / 2147483648.0) * 0.030) * w
        rg = cairo.RadialGradient(x, y, 0, x, y, r)
        rg.add_color_stop_rgba(0.0, color[0], color[1], color[2], alpha)
        rg.add_color_stop_rgba(1.0, color[0], color[1], color[2], 0.0)
        cr.set_source(rg)
        cr.arc(x, y, r, 0, 2 * math.pi)
        cr.fill()


def light_wallpaper(w, h):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(surf)

    # небо: насыщенный бирюзовый сверху к светлому горизонту
    grad = cairo.LinearGradient(0, 0, 0, h)
    grad.add_color_stop_rgb(0.00, *CYAN_TOP)
    grad.add_color_stop_rgb(0.42, *CYAN_MID)
    grad.add_color_stop_rgb(0.76, 0.72, 0.94, 0.97)
    grad.add_color_stop_rgb(1.00, 0.88, 0.98, 1.00)
    cr.set_source(grad)
    cr.paint()

    # солнце в правом верхнем углу
    cx, cy = w * 0.80, h * 0.20
    rg = cairo.RadialGradient(cx, cy, 0, cx, cy, w * 0.38)
    rg.add_color_stop_rgba(0.0, 1, 1, 1, 0.42)
    rg.add_color_stop_rgba(0.25, 0.92, 1, 1, 0.18)
    rg.add_color_stop_rgba(1.0, 0.92, 1, 1, 0.0)
    cr.set_source(rg)
    cr.arc(cx, cy, w * 0.38, 0, 2 * math.pi)
    cr.fill()

    # диагональные лучи, как в обоях G2/G3
    _beam(cr, w * 0.02, h * 0.62, w * 0.92, h * 0.02, w * 0.045, WHITE, 0.55)
    _beam(cr, w * 0.22, h * 0.78, w * 1.02, h * 0.12, w * 0.030, WHITE, 0.42)
    _beam(cr, w * 0.46, h * 0.92, w * 1.05, h * 0.30, w * 0.022, WHITE, 0.30)
    _beam(cr, -w * 0.08, h * 0.44, w * 0.72, -h * 0.04, w * 0.018, WHITE, 0.24)

    _bokeh(cr, w, h, seed=11, count=22, alpha=0.055)

    # нижняя розово-пурпурная волна
    _wave(cr, w, h, h * 0.855, h * 0.055, PINK, 0.92, phase=0.10)
    _wave(cr, w, h, h * 0.895, h * 0.045, MAGENTA, 0.96, phase=0.55)
    _wave(cr, w, h, h * 0.955, h * 0.025, PURPLE, 1.0, phase=0.95)

    # тонкая светлая кромка волны
    cr.new_path()
    cr.move_to(0, h * 0.855)
    for i in range(1, 33):
        t = i / 32.0
        x = t * w
        y = h * 0.855 + math.sin((t * 2.4 + 0.10) * math.pi) * h * 0.055
        cr.line_to(x, y)
    cr.set_line_width(max(1.2, w * 0.0015))
    cr.set_source_rgba(1, 1, 1, 0.28)
    cr.stroke()

    return surf


def dark_wallpaper(w, h):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(surf)

    grad = cairo.LinearGradient(0, 0, 0, h)
    grad.add_color_stop_rgb(0.00, 0.012, 0.090, 0.120)
    grad.add_color_stop_rgb(0.42, 0.020, 0.220, 0.280)
    grad.add_color_stop_rgb(0.78, 0.035, 0.300, 0.350)
    grad.add_color_stop_rgb(1.00, 0.020, 0.080, 0.110)
    cr.set_source(grad)
    cr.paint()

    # холодное свечение
    cx, cy = w * 0.78, h * 0.22
    rg = cairo.RadialGradient(cx, cy, 0, cx, cy, w * 0.42)
    rg.add_color_stop_rgba(0.0, 0.35, 0.95, 1.0, 0.22)
    rg.add_color_stop_rgba(0.35, 0.20, 0.80, 0.92, 0.08)
    rg.add_color_stop_rgba(1.0, 0.10, 0.50, 0.60, 0.0)
    cr.set_source(rg)
    cr.arc(cx, cy, w * 0.42, 0, 2 * math.pi)
    cr.fill()

    _beam(cr, w * 0.00, h * 0.70, w * 0.95, h * 0.04, w * 0.040, WHITE, 0.30)
    _beam(cr, w * 0.26, h * 0.88, w * 1.02, h * 0.18, w * 0.026, WHITE, 0.22)
    _beam(cr, -w * 0.06, h * 0.48, w * 0.70, -h * 0.04, w * 0.016, WHITE, 0.14)

    _bokeh(cr, w, h, seed=23, count=28, color=(0.55, 0.95, 1.0), alpha=0.05)

    _wave(cr, w, h, h * 0.86, h * 0.050, (0.55, 0.08, 0.36), 0.82, phase=0.15)
    _wave(cr, w, h, h * 0.91, h * 0.040, (0.36, 0.04, 0.30), 0.92, phase=0.60)
    _wave(cr, w, h, h * 0.96, h * 0.022, (0.10, 0.03, 0.16), 1.0, phase=1.0)

    return surf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default="/usr/share/backgrounds/lg")
    ap.add_argument("--size", default="1920x1080")
    args = ap.parse_args()

    try:
        w, h = (int(v) for v in args.size.lower().split("x"))
    except Exception:
        sys.stderr.write("Неверный размер: %s\n" % args.size)
        return 1

    os.makedirs(args.dest, exist_ok=True)
    for name, fn in (("lg-dark.png", dark_wallpaper),
                     ("lg-light.png", light_wallpaper)):
        path = os.path.join(args.dest, name)
        fn(w, h).write_to_png(path)
        print("Заставка: %s" % path)
    return 0


if __name__ == "__main__":
    sys.exit(main())

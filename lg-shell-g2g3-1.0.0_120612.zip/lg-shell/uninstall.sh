#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# Remove LG UX Shell. Xfce itself is not modified.
#
# Usage:
#   ./uninstall.sh            remove components, themes and the session
#   ./uninstall.sh --purge    also remove ~/.config/lg-shell

set -euo pipefail

PURGE=0
[ "${1:-}" = "--purge" ] && PURGE=1

if [ "$(id -u)" -ne 0 ]; then
    exec sudo bash "$0" "$@"
fi

BIN_DST="/usr/local/bin"
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)
REAL_UID=$(id -u "$REAL_USER")

echo "== Удаление LG UX Shell =="

# горячие клавиши пользователя
if command -v xfconf-query >/dev/null 2>&1 && [ "$REAL_USER" != root ]; then
    run_as_user() {
        sudo -u "$REAL_USER" env HOME="$REAL_HOME" \
            XDG_RUNTIME_DIR="/run/user/${REAL_UID}" \
            DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${REAL_UID}/bus" \
            "$@" >/dev/null 2>&1 || true
    }
    for n in lg-launcher lg-control lg-lock \
             lg-vol-up lg-vol-down lg-mute; do
        run_as_user xfconf-query -c xfce4-keyboard-shortcuts -r -p "/global/custom/${n}/name"
        run_as_user xfconf-query -c xfce4-keyboard-shortcuts -r -p "/global/custom/${n}/binding"
        run_as_user xfconf-query -c xfce4-keyboard-shortcuts -r -p "/commands/custom/${n}"
    done
    rm -f "/run/user/${REAL_UID}/lg-shell.lock"
fi

# остановить компоненты, если сеанс ещё запущен
pkill -f '/usr/local/bin/lg-(panel|dock|notifications|launcher|control-center|lock|splash)$' \
    2>/dev/null || true

rm -rf /usr/share/lg-shell
rm -rf /usr/share/themes/lg-gtk /usr/share/themes/lg-gtk-dark
rm -rf /usr/share/themes/lg-light /usr/share/themes/lg-dark
rm -rf /usr/share/backgrounds/lg
rm -f /usr/share/xsessions/lg-ux.desktop

# Plymouth-тема: если она была выбрана, вернуть стандартную.
# Недостаточно удалить файлы: initramfs-hook берёт тему из
# update-alternatives default.plymouth, поэтому альтернативу надо снять,
# иначе останется битая ссылка и тема lg-ux останется в initrd.
PLY_CONF="/etc/plymouth/plymouthd.conf"
PLY_ALT="/usr/share/plymouth/themes/default.plymouth"
PLY_THEME="/usr/share/plymouth/themes/lg-ux/lg-ux.plymouth"
PLY_REMOVED=0
if command -v update-alternatives >/dev/null 2>&1; then
    current_plymouth=$(readlink -f "$PLY_ALT" 2>/dev/null || true)
    if [ "$current_plymouth" = "$PLY_THEME" ]; then
        update-alternatives --remove default.plymouth "$PLY_THEME" \
            >/dev/null 2>&1 || true
        PLY_REMOVED=1
    fi
fi
if [ -f "$PLY_CONF" ] && grep -qE '^\s*Theme\s*=\s*lg-ux\s*$' "$PLY_CONF"; then
    if command -v plymouth-set-default-theme >/dev/null 2>&1; then
        plymouth-set-default-theme -R spinner >/dev/null 2>&1 \
            || plymouth-set-default-theme -R mint-logo >/dev/null 2>&1 \
            || true
    else
        chosen=$(update-alternatives --query default.plymouth 2>/dev/null \
            | sed -n 's/^Value: //p' | head -1 || true)
        if [ -n "$chosen" ]; then
            chosen_name=$(basename "$chosen" .plymouth)
            sed -i "s/^Theme=.*/Theme=$chosen_name/" "$PLY_CONF" || true
        fi
    fi
fi
rm -rf /usr/share/plymouth/themes/lg-ux
if [ "$PLY_REMOVED" -eq 1 ]; then
    if command -v update-initramfs >/dev/null 2>&1; then
        update-initramfs -u >/dev/null 2>&1 || true
    elif command -v dracut >/dev/null 2>&1; then
        dracut -f >/dev/null 2>&1 || true
    elif command -v mkinitcpio >/dev/null 2>&1; then
        mkinitcpio -P >/dev/null 2>&1 || true
    fi
fi

for n in panel dock launcher control-center lock notifications splash wallpaper; do
    rm -f "${BIN_DST}/lg-${n}"
done

# восстановляем прошлый lg-session, если он был сохранён
latest_bak=$(ls -1t "${BIN_DST}"/lg-session.bak.* 2>/dev/null | head -1 || true)
if [ -n "$latest_bak" ]; then
    mv "$latest_bak" "${BIN_DST}/lg-session"
    echo "Восстановлен прежний lg-session: $latest_bak"
else
    rm -f "${BIN_DST}/lg-session"
fi

if [ "$PURGE" -eq 1 ]; then
    rm -rf "${REAL_HOME}/.config/lg-shell"
    echo "Удалена конфигурация ${REAL_HOME}/.config/lg-shell"
fi

echo "Готово. Пакеты Xfce не тронуты."

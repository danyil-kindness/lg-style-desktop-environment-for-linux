#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация Plymouth-темы «LG UX»: заставка включения ноутбука.

Стиль как у прошивки ноутбука: чёрный экран, по центру проявляется знак LG
со слоганом, ниже — тонкая красная линия загрузки. Никаких точек, кружков
и подписей «загрузка оболочки»: это именно экран включения устройства.

Создаёт в --dest готовый набор: фон, логотип, слоган, дорожку и кадры
прогресса, подписи выключения/перезагрузки, скрипт анимации и .plymouth-файл.

Использование:
    gen_boot_animation.py [--dest boot/theme] [--size 1920x1080] [--lang ru]

Установка темы выполняется install.sh (флаг --boot).
"""

import argparse
import math
import os
import sys

import cairo

HERE = os.path.dirname(os.path.abspath(__file__))
SHARE = os.path.join(os.path.dirname(HERE), "share")
if os.path.isdir(os.path.join(SHARE, "lg_shell")):
    sys.path.insert(0, SHARE)

from lg_shell import theme  # noqa: E402

# Сцена включения: почти чёрный, чтобы сливаться с корпусом ноутбука.
BG_TOP = (0.020, 0.014, 0.018)
BG_BOTTOM = (0.004, 0.003, 0.005)
ACCENT = (0.914, 0.208, 0.361)   # #E9355C — красный LG на тёмном
ACCENT_DEEP = (0.647, 0.000, 0.204)
WORD = (0.980, 0.965, 0.973)
SUB = (0.66, 0.61, 0.65)

PROGRESS_STEPS = 48
BAR_W = 320
BAR_H = 4

CAPTIONS = {
    "ru": ("Завершение работы", "Перезагрузка"),
    "en": ("Shutting down", "Restarting"),
    "uk": ("Завершення роботи", "Перезавантаження"),
    "pl": ("Wyłączanie", "Restartowanie"),
}


def surface(w, h):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(w), int(h))
    return surf, cairo.Context(surf)


def text(cr, value, cx, cy, size, color, alpha=1.0, italic=False,
         bold=False, spacing=0.0):
    cr.save()
    cr.set_source_rgba(color[0], color[1], color[2], alpha)
    cr.select_font_face(
        "DejaVu Sans",
        cairo.FONT_SLANT_ITALIC if italic else cairo.FONT_SLANT_NORMAL,
        cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL,
    )
    cr.set_font_size(size)
    if spacing:
        width = sum(cr.text_extents(ch).x_advance for ch in value)
        width += spacing * max(0, len(value) - 1)
        x = cx - width / 2.0
        for ch in value:
            ext = cr.text_extents(ch)
            cr.move_to(x, cy - ext.height / 2.0 - ext.y_bearing)
            cr.show_text(ch)
            x += ext.x_advance + spacing
    else:
        ext = cr.text_extents(value)
        cr.move_to(cx - ext.width / 2.0 - ext.x_bearing,
                   cy - ext.height / 2.0 - ext.y_bearing)
        cr.show_text(value)
    cr.restore()


def make_bg(w, h, path):
    """Почти чёрный фон с очень мягким красным дыханием за логотипом."""
    surf, cr = surface(w, h)
    grad = cairo.LinearGradient(0, 0, 0, h)
    grad.add_color_stop_rgb(0.0, *BG_TOP)
    grad.add_color_stop_rgb(0.62, 0.010, 0.007, 0.010)
    grad.add_color_stop_rgb(1.0, *BG_BOTTOM)
    cr.set_source(grad)
    cr.paint()

    # едва заметное свечение по центру — экран не выглядит «мёртвым»
    cx, cy = w / 2.0, h * 0.46
    rg = cairo.RadialGradient(cx, cy, 0, cx, cy, min(w, h) * 0.55)
    rg.add_color_stop_rgba(0.0, ACCENT_DEEP[0], ACCENT_DEEP[1], ACCENT_DEEP[2], 0.13)
    rg.add_color_stop_rgba(0.50, ACCENT_DEEP[0], ACCENT_DEEP[1], ACCENT_DEEP[2], 0.035)
    rg.add_color_stop_rgba(1.0, ACCENT_DEEP[0], ACCENT_DEEP[1], ACCENT_DEEP[2], 0.0)
    cr.set_source(rg)
    cr.paint()

    # виньетка по краям
    rg = cairo.RadialGradient(w / 2, h / 2, min(w, h) * 0.30,
                              w / 2, h / 2, max(w, h) * 0.78)
    rg.add_color_stop_rgba(0.0, 0, 0, 0, 0.0)
    rg.add_color_stop_rgba(1.0, 0, 0, 0, 0.40)
    cr.set_source(rg)
    cr.paint()
    surf.write_to_png(path)


def make_logo(w, h, path):
    """Знак + надпись LG в одной прозрачной картинке (по центру холста)."""
    surf, cr = surface(w, h)
    cy = h / 2.0
    mark = h * 0.80
    word_h = h * 0.74

    cr.save()
    cr.select_font_face("DejaVu Sans", cairo.FONT_SLANT_NORMAL,
                        cairo.FONT_WEIGHT_BOLD)
    cr.set_font_size(word_h)
    word_w = cr.text_extents("LG").width
    cr.restore()

    mark_w = mark * 0.87
    gap = h * 0.18
    total = mark_w + gap + word_w
    left = (w - total) / 2.0
    mark_cx = left + mark * 0.3875
    word_cx = left + mark_w + gap + word_w / 2.0

    theme.draw_lg_mark(cr, mark_cx, cy, mark, ACCENT)
    # аккуратный блик по верхней дуге кольца
    cr.save()
    cr.set_line_width(max(1.0, mark * 0.012))
    cr.set_source_rgba(1, 1, 1, 0.10)
    cr.arc(mark_cx, cy, mark * 0.31, math.radians(-152), math.radians(-62))
    cr.stroke()
    cr.restore()
    theme.draw_lg_wordmark(cr, word_cx, cy, word_h, WORD)
    surf.write_to_png(path)


def make_tagline(w, h, path):
    surf, cr = surface(w, h)
    text(cr, "Life's Good", w / 2.0, h / 2.0, h * 0.60, SUB,
         italic=True, spacing=h * 0.11)
    surf.write_to_png(path)


def make_track(w, h, path):
    surf, cr = surface(w, h)
    r = h / 2.0
    theme.round_rect(cr, 0, 0, w, h, r)
    cr.set_source_rgba(1, 1, 1, 0.13)
    cr.fill()
    surf.write_to_png(path)


def make_bar_frames(dest, steps=PROGRESS_STEPS):
    """Кадры заполнения тонкой линии: от 0 до полной ширины."""
    names = []
    for i in range(steps):
        frac = i / float(steps - 1)
        width = max(BAR_H, BAR_W * frac)
        path = os.path.join(dest, "bar-%02d.png" % i)
        surf, cr = surface(BAR_W, BAR_H)
        theme.round_rect(cr, 0, 0, width, BAR_H, BAR_H / 2.0)
        cr.set_source_rgba(ACCENT[0], ACCENT[1], ACCENT[2], 0.95)
        cr.fill()
        surf.write_to_png(path)
        names.append(os.path.basename(path))
    return names


def make_caption(w, h, value, path):
    surf, cr = surface(w, h)
    text(cr, value, w / 2.0, h / 2.0, h * 0.52, SUB, alpha=0.92,
         spacing=h * 0.04)
    surf.write_to_png(path)


SCRIPT = r"""# ---------------------------------------------------------------------------
#  LG UX power-on splash — Plymouth "script" plugin
#  Чёрный экран, знак LG и тонкая линия загрузки. Стиль прошивки ноутбука.
#  Generated by tools/gen_boot_animation.py. Do not edit by hand.
# ---------------------------------------------------------------------------

Plymouth.SetRefreshRate(60);

fun smoothstep (x)
{
    if (x <= 0.0) return 0.0;
    if (x >= 1.0) return 1.0;
    return x * x * (3.0 - 2.0 * x);
}

fun clamp01 (x)
{
    if (x < 0.0) return 0.0;
    if (x > 1.0) return 1.0;
    return x;
}

# ------------------------------- state -------------------------------------
mode = Plymouth.GetMode();
frame = 0;
t = 0.0;
boot_progress = 0.0;
is_ready = 0;
last_w = 0;
last_h = 0;
sw = 1920;
sh = 1080;
s = 1.0;
cx = 960.0;
cy = 470.0;
last_bar = -1;

# ------------------------------- assets ------------------------------------
bg_img   = Image("bg.png");
logo_img = Image("logo.png");
tag_img  = Image("tagline.png");
track_img = Image("track.png");
cap_off  = Image("caption_shutdown.png");
cap_reb  = Image("caption_reboot.png");

bar_frames = [
__BAR_IMAGES__
];

bar_draw = [];
i = 0;
while (i < __STEPS__)
{
    bar_draw[i] = null;
    i = i + 1;
}

# ------------------------------- sprites -----------------------------------
bg_sprite = Sprite(bg_img);
bg_sprite.SetPosition(0, 0, -1000);

logo_sprite = Sprite(logo_img);
logo_sprite.SetPosition(0, 0, 0);
logo_sprite.SetOpacity(0.0);

tag_sprite = Sprite(tag_img);
tag_sprite.SetPosition(0, 0, 10);
tag_sprite.SetOpacity(0.0);

track_sprite = Sprite(track_img);
track_sprite.SetPosition(0, 0, 20);
track_sprite.SetOpacity(0.0);

bar_sprite = Sprite(bar_frames[0]);
bar_sprite.SetPosition(0, 0, 30);
bar_sprite.SetOpacity(0.0);

cap_sprite = Sprite(cap_off);
cap_sprite.SetPosition(0, 0, 40);
cap_sprite.SetOpacity(0.0);

# ------------------------------- layout ------------------------------------
fun relayout ()
{
    w = Window.GetWidth();
    h = Window.GetHeight();
    if (w <= 0) w = 1920;
    if (h <= 0) h = 1080;
    if (w == last_w && h == last_h) return;

    global.last_w = w;
    global.last_h = h;
    global.sw = w;
    global.sh = h;
    s = Math.Min(w / 1920.0, h / 1080.0);
    if (s < 0.35) s = 0.35;
    if (s > 2.0) s = 2.0;
    global.s = s;
    global.cx = w / 2.0;
    global.cy = h / 2.0 - 20.0 * s;

    bg_sprite.SetImage(bg_img.Scale(w, h));
    bg_sprite.SetPosition(0, 0, -1000);

    logo_draw = logo_img.Scale(Math.Int(600.0 * s), Math.Int(216.0 * s));
    tag_draw = tag_img.Scale(Math.Int(384.0 * s), Math.Int(54.0 * s));
    track_draw = track_img.Scale(Math.Int(__BAR_W__ * s), Math.Int(__BAR_H__ * s));
    track_sprite.SetImage(track_draw);
    track_sprite.SetPosition(Math.Int(cx - track_draw.GetWidth() / 2.0),
                             Math.Int(cy + 205.0 * s), 20);

    i = 0;
    while (i < __STEPS__)
    {
        bar_draw[i] = bar_frames[i].Scale(Math.Int(__BAR_W__ * s),
                                       Math.Int(__BAR_H__ * s));
        i = i + 1;
    }
    bar_sprite.SetPosition(Math.Int(cx - track_draw.GetWidth() / 2.0),
                           Math.Int(cy + 205.0 * s), 30);
    global.last_bar = -1;

    logo_sprite.SetImage(logo_draw);
    logo_sprite.SetPosition(Math.Int(cx - logo_draw.GetWidth() / 2.0),
                            Math.Int(cy - logo_draw.GetHeight() / 2.0), 0);
    tag_sprite.SetImage(tag_draw);
    tag_sprite.SetPosition(Math.Int(cx - tag_draw.GetWidth() / 2.0),
                           Math.Int(cy + 125.0 * s), 10);

    cap_src = cap_off;
    if (mode == "reboot") cap_src = cap_reb;
    cap_draw = cap_src.Scale(Math.Int(620.0 * s), Math.Int(60.0 * s));
    cap_sprite.SetImage(cap_draw);
    cap_sprite.SetPosition(Math.Int(cx - cap_draw.GetWidth() / 2.0),
                           Math.Int(cy + 215.0 * s), 40);
}

# ------------------------------- animation ---------------------------------
fun refresh ()
{
    relayout();

    t = frame / 60.0;
    global.frame = frame + 1;

    appear = smoothstep((t - 0.10) / 0.65);
    tag_in = smoothstep((t - 0.55) / 0.70);

    bg_sprite.SetOpacity(1.0);
    logo_sprite.SetOpacity(appear);
    tag_sprite.SetOpacity(tag_in * 0.95);

    if (mode == "shutdown" || mode == "reboot")
    {
        track_sprite.SetOpacity(0.0);
        bar_sprite.SetOpacity(0.0);
        cap_sprite.SetOpacity(smoothstep((t - 0.55) / 0.70) * 0.95);
        tag_sprite.SetOpacity(0.0);
    }
    else
    {
        cap_sprite.SetOpacity(0.0);
        track_sprite.SetOpacity(smoothstep((t - 0.65) / 0.55) * 0.90);

        p = clamp01(boot_progress);
        creep = clamp01(t / 16.0) * 0.80;
        if (p < creep) p = creep;
        if (is_ready == 1) p = 1.0;

        idx = Math.Int(p * (__STEPS__ - 1));
        if (idx < 0) idx = 0;
        if (idx > __STEPS__ - 1) idx = __STEPS__ - 1;
        if (idx != last_bar)
        {
            bar_sprite.SetImage(bar_draw[idx]);
            global.last_bar = idx;
        }
        bar_sprite.SetOpacity(smoothstep((t - 0.70) / 0.55));
    }
}

# ------------------------------- callbacks ---------------------------------
fun on_progress (value)
{
    global.boot_progress = value;
    if (value >= 0.995) global.is_ready = 1;
}

fun on_display_normal ()
{
    global.is_ready = 1;
}

Plymouth.SetBootProgressFunction(on_progress);
Plymouth.SetDisplayNormalFunction(on_display_normal);
Plymouth.SetRefreshFunction(refresh);

relayout();
"""

PLYMOUTH = """[Plymouth Theme]
Name=LG UX
Description=LG UX power-on splash (black screen, LG logo, thin progress line)
ModuleName=script

[script]
ImageDir=__DEST__
ScriptFile=__DEST__/lg-ux.script
"""


def write_script(dest, bars, image_dir):
    bar_lines = ",\n    ".join('Image("%s")' % name for name in bars)
    body = SCRIPT.replace("__BAR_IMAGES__", bar_lines)
    body = body.replace("__STEPS__", str(len(bars)))
    body = body.replace("__BAR_W__", str(BAR_W))
    body = body.replace("__BAR_H__", str(BAR_H))
    with open(os.path.join(dest, "lg-ux.script"), "w", encoding="utf-8") as fh:
        fh.write(body)
    with open(os.path.join(dest, "lg-ux.plymouth"), "w", encoding="utf-8") as fh:
        fh.write(PLYMOUTH.replace("__DEST__", image_dir))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default=os.path.join(
        os.path.dirname(HERE), "boot", "theme"))
    ap.add_argument("--size", default="1920x1080")
    ap.add_argument("--lang", default="ru", choices=sorted(CAPTIONS))
    ap.add_argument("--image-dir", default="/usr/share/plymouth/themes/lg-ux",
                    help="каталог темы на момент загрузки (для .plymouth)")
    args = ap.parse_args()

    try:
        w, h = (int(v) for v in args.size.lower().split("x"))
    except Exception:
        sys.stderr.write("Неверный размер: %s\n" % args.size)
        return 1

    os.makedirs(args.dest, exist_ok=True)
    make_bg(w, h, os.path.join(args.dest, "bg.png"))
    make_logo(int(h * 0.20 * 2.78), int(h * 0.20),
              os.path.join(args.dest, "logo.png"))
    make_tagline(int(w * 0.20), int(h * 0.050),
                 os.path.join(args.dest, "tagline.png"))
    make_track(BAR_W, BAR_H, os.path.join(args.dest, "track.png"))
    bars = make_bar_frames(args.dest)
    shutdown, reboot = CAPTIONS[args.lang]
    make_caption(int(w * 0.33), int(h * 0.055), shutdown,
                 os.path.join(args.dest, "caption_shutdown.png"))
    make_caption(int(w * 0.33), int(h * 0.055), reboot,
                 os.path.join(args.dest, "caption_reboot.png"))
    write_script(args.dest, bars, args.image_dir)
    print("Plymouth-тема LG UX собрана: %s" % args.dest)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация заставок LG UX (оригинальная геометрическая графика).

Стиль LG UX 10: тёплый фон, большой «сквиркл» (форма плитки приложений),
фирменный красный и разреженная сетка точек. Никаких волн и градиентных
пятен — только чистые формы.

Использование: gen_wallpaper.py [--dest /usr/share/backgrounds/lg]
                               [--size 1920x1080]
"""

import argparse
import math
import os
import sys

import cairo

ACCENT = (0.647, 0.000, 0.204)      # #A50034
ACCENT2 = (0.847, 0.106, 0.376)     # #D81B60
INK = (0.10, 0.08, 0.09)


def squircle_path(cr, cx, cy, rx, ry, n=4.0, steps=180):
    """Суперэллипс — фирменная форма плиток LG UX."""
    for i in range(steps + 1):
        a = 2.0 * math.pi * i / steps
        ca, sa = math.cos(a), math.sin(a)
        x = cx + rx * math.copysign(abs(ca) ** (2.0 / n), ca)
        y = cy + ry * math.copysign(abs(sa) ** (2.0 / n), sa)
        if i == 0:
            cr.move_to(x, y)
        else:
            cr.line_to(x, y)
    cr.close_path()


def dot_grid(cr, x0, y0, cols, rows, gap, radius, rgba):
    cr.set_source_rgba(*rgba)
    for r in range(rows):
        for c in range(cols):
            cr.arc(x0 + c * gap, y0 + r * gap, radius, 0, 2 * math.pi)
            cr.fill()


def wordmark(cr, x, y, size, rgba, text="LG", bold=True, italic=False):
    cr.save()
    cr.set_source_rgba(*rgba)
    cr.select_font_face(
        "DejaVu Sans",
        cairo.FONT_SLANT_ITALIC if italic else cairo.FONT_SLANT_NORMAL,
        cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL,
    )
    cr.set_font_size(size)
    ext = cr.text_extents(text)
    cr.move_to(x - ext.x_bearing, y - ext.height - ext.y_bearing)
    cr.show_text(text)
    cr.restore()


def light_wallpaper(w, h):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(surf)

    # тёплая «бумага»
    grad = cairo.LinearGradient(0, 0, w * 0.35, h)
    grad.add_color_stop_rgb(0.0, 0.976, 0.957, 0.937)
    grad.add_color_stop_rgb(0.55, 0.965, 0.941, 0.922)
    grad.add_color_stop_rgb(1.0, 0.937, 0.910, 0.894)
    cr.set_source(grad)
    cr.paint()

    # большой красный сквиркл справа — главный акцент
    cx, cy = w * 0.835, h * 0.33
    rx, ry = w * 0.160, w * 0.160
    grad = cairo.LinearGradient(cx - rx, cy - ry, cx + rx, cy + ry)
    grad.add_color_stop_rgb(0.0, 0.702, 0.008, 0.224)
    grad.add_color_stop_rgb(0.55, 0.647, 0.000, 0.204)
    grad.add_color_stop_rgb(1.0, 0.780, 0.047, 0.290)
    squircle_path(cr, cx, cy, rx, ry)
    cr.set_source(grad)
    cr.fill()

    # тонкая светлая кромка внутри — «стеклянная» плитка
    cr.set_line_width(max(1.0, w * 0.0014))
    squircle_path(cr, cx, cy, rx * 0.93, ry * 0.93)
    cr.set_source_rgba(1, 1, 1, 0.16)
    cr.stroke()

    # светлый ореол вокруг плитки
    squircle_path(cr, cx, cy, rx * 1.085, ry * 1.085)
    cr.set_source_rgba(0.988, 0.973, 0.957, 0.55)
    cr.set_line_width(max(2.0, w * 0.0020))
    cr.stroke()

    # сетка точек в левом нижнем углу — отсылка к сетке приложений
    dot_grid(cr, w * 0.075, h * 0.74, 9, 5, w * 0.026,
             max(1.4, w * 0.0019), (0.10, 0.08, 0.09, 0.10))

    # подпись в правом нижнем углу
    wordmark(cr, w * 0.83, h * 0.955, h * 0.030, (0.647, 0.0, 0.204, 0.22))
    wordmark(cr, w * 0.895, h * 0.952, h * 0.018,
             (0.35, 0.30, 0.32, 0.16), "Life's Good", bold=False, italic=True)

    return surf


def dark_wallpaper(w, h):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(surf)

    grad = cairo.LinearGradient(0, 0, w * 0.30, h)
    grad.add_color_stop_rgb(0.0, 0.055, 0.043, 0.051)
    grad.add_color_stop_rgb(0.55, 0.031, 0.024, 0.030)
    grad.add_color_stop_rgb(1.0, 0.012, 0.010, 0.013)
    cr.set_source(grad)
    cr.paint()

    cx, cy = w * 0.78, h * 0.37
    rx, ry = w * 0.180, w * 0.180

    # мягкое красное свечение за контуром
    rg = cairo.RadialGradient(cx, cy, rx * 0.35, cx, cy, rx * 1.9)
    rg.add_color_stop_rgba(0.0, ACCENT[0], ACCENT[1], ACCENT[2], 0.16)
    rg.add_color_stop_rgba(0.55, ACCENT[0], ACCENT[1], ACCENT[2], 0.05)
    rg.add_color_stop_rgba(1.0, ACCENT[0], ACCENT[1], ACCENT[2], 0.0)
    cr.set_source(rg)
    cr.paint()

    # контурный сквиркл
    squircle_path(cr, cx, cy, rx, ry)
    cr.set_line_width(max(1.5, w * 0.0022))
    cr.set_source_rgba(ACCENT2[0], ACCENT2[1], ACCENT2[2], 0.46)
    cr.stroke()

    squircle_path(cr, cx, cy, rx * 0.985, ry * 0.985)
    cr.set_line_width(max(1.0, w * 0.0008))
    cr.set_source_rgba(1, 1, 1, 0.055)
    cr.stroke()

    # маленькая заполненная плитка в левом нижнем углу
    sx, sy = w * 0.270, h * 0.760
    sr = w * 0.042
    rg = cairo.RadialGradient(sx, sy, 0, sx, sy, sr * 2.6)
    rg.add_color_stop_rgba(0.0, ACCENT[0], ACCENT[1], ACCENT[2], 0.30)
    rg.add_color_stop_rgba(1.0, ACCENT[0], ACCENT[1], ACCENT[2], 0.0)
    cr.set_source(rg)
    cr.arc(sx, sy, sr * 2.6, 0, 2 * math.pi)
    cr.fill()
    grad = cairo.LinearGradient(sx - sr, sy - sr, sx + sr, sy + sr)
    grad.add_color_stop_rgb(0.0, ACCENT2[0], ACCENT2[1], ACCENT2[2])
    grad.add_color_stop_rgb(1.0, ACCENT[0], ACCENT[1], ACCENT[2])
    squircle_path(cr, sx, sy, sr, sr)
    cr.set_source(grad)
    cr.fill()

    # сетка точек справа сверху
    dot_grid(cr, w * 0.075, h * 0.115, 8, 4, w * 0.026,
             max(1.2, w * 0.0017), (1.0, 0.95, 0.97, 0.07))

    wordmark(cr, w * 0.83, h * 0.955, h * 0.030, (0.95, 0.93, 0.94, 0.13))
    wordmark(cr, w * 0.895, h * 0.952, h * 0.018,
             (0.78, 0.72, 0.76, 0.12), "Life's Good", bold=False, italic=True)

    return surf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default="/usr/share/backgrounds/lg")
    ap.add_argument("--size", default="1920x1080")
    args = ap.parse_args()

    try:
        w, h = (int(v) for v in args.size.lower().split("x"))
    except Exception:
        sys.stderr.write("Неверный размер: %s\n" % args.size)
        return 1

    os.makedirs(args.dest, exist_ok=True)
    for name, fn in (("lg-dark.png", dark_wallpaper),
                     ("lg-light.png", light_wallpaper)):
        path = os.path.join(args.dest, name)
        fn(w, h).write_to_png(path)
        print("Заставка: %s" % path)
    return 0


if __name__ == "__main__":
    sys.exit(main())

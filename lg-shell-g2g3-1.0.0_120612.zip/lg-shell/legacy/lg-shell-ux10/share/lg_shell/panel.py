# -*- coding: utf-8 -*-
"""Верхняя панель LG: часы, календарь, статусы, центр управления."""

import datetime
import os
import subprocess

from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk

from . import config, i18n, sysinfo, tasklist, theme, tray as trayhost, widgets, windows, x11
from .i18n import _


def _rgba_pixel(rgba):
    """(r, g, b, a) из 0..1 -> 0xRRGGBBAA для GdkPixbuf.fill()."""
    r, g, b, a = [max(0, min(255, int(round(c * 255)))) for c in rgba]
    return (r << 24) | (g << 16) | (b << 8) | a


def _spawn(cmd):
    try:
        subprocess.Popen(cmd, start_new_session=True)
    except Exception:
        pass


class PanelApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.lgux.Panel")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(PanelWindow(self))
        self.win.present()


class PanelWindow(widgets.ThemedWindow):
    def __init__(self, app):
        super().__init__()
        self.set_title("LG Panel")
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        # 24-битный visual: значки трея — чужие окна той же глубины, что и
        # родитель, а RGBA-окно принимает только 32-битные окна
        widgets.set_rgb(self)

        cfg = config.load()
        self.height = cfg.getint("panel", "height", fallback=36)
        self.show_date = cfg.getboolean("panel", "show_date", fallback=True)
        self.dnd = cfg.getboolean("general", "dnd", fallback=False)

        self._calendar = None
        self._bg_uri = ""
        self._bg_key = None
        self._bg_seq = 0
        self._build_ui()
        geo = widgets.primary_geometry()
        # фон готовим до показа окна: иначе при старте мелькает пустая панель
        self._sync_backdrop((geo.x, max(0, geo.y), geo.width, self.height))
        self.show_all()
        self.set_size_request(geo.width, self.height)
        self.move(geo.x, max(0, geo.y))
        widgets.GLib_idle_strut(self.get_window(), "top", self.height)

        self.tray = None
        if cfg.getboolean("panel", "tray", fallback=True):
            self.tray = trayhost.TrayHost(self, self.tray_box)
            self._tray_tries = 0
            GLib.timeout_add(400, self._start_tray)

        GLib.timeout_add_seconds(8, self._sync_backdrop)

        GLib.timeout_add_seconds(1, self._tick_clock)
        GLib.timeout_add_seconds(5, self._tick_sys)
        self._tick_clock()
        self._tick_sys()

    def _sync_backdrop(self, area=None):
        """Фон панели: обои под панелью + цвет панели с прозрачностью.

        Окно панели 24-битное (иначе в него не встроить значки трея), поэтому
        настоящую прозрачность заменяем снимком обоев из корневого pixmap:
        выглядит как rgba-фон, но не зависит от композитора.
        """
        if area is None:
            if self.get_window() is None:
                return True
            w = max(1, self.get_allocated_width())
            h = max(1, self.get_allocated_height())
            try:
                x, y = self.get_position()
            except Exception:
                x, y = 0, 0
        else:
            x, y, w, h = area
        w = max(1, w)
        h = max(1, h)

        rgba = theme.palette()["panel_rgba"]
        src = widgets.wallpaper_pixbuf(x, y, w, h)
        raw = bytes(src.get_pixels()) if src is not None else b""
        key = (x, y, w, h, tuple(round(c, 3) for c in rgba), hash(raw))
        if key == self._bg_key:
            return True
        self._bg_key = key

        dest = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, False, 8, w, h)
        dest.fill(_rgba_pixel(rgba))
        if src is not None:
            alpha = int(round((1.0 - rgba[3]) * 255))
            try:
                src.composite(dest, 0, 0, w, h, 0, 0, 1.0, 1.0,
                              GdkPixbuf.InterpType.NEAREST, alpha)
            except Exception:
                pass
        path = self._write_backdrop(dest)
        if path is None:
            return True
        self._bg_uri = "file://" + path
        try:
            widgets.update_provider(self.css_prov, self.build_css())
        except Exception:
            pass
        return True

    def _write_backdrop(self, pixbuf):
        base = os.path.join(GLib.get_user_cache_dir(), "lg-shell")
        try:
            os.makedirs(base, exist_ok=True)
            self._bg_seq = (self._bg_seq % 20) + 1
            path = os.path.join(base, "panel-bg-%d.png" % self._bg_seq)
            pixbuf.savev(path, "png", [], [])
            return path
        except Exception:
            return None

    def before_relaunch(self):
        # отпускаем значки трея по-хорошему: при перезапуске (смена языка)
        # приложения должны снова подключиться к новой панели
        if self.tray is not None:
            self.tray.stop()

    def _start_tray(self):
        if self.tray is None:
            return False
        try:
            if self.tray.start():
                return False
        except Exception:
            # трей не критичен для панели: пишем след в лог и пробуем ещё раз
            import traceback
            traceback.print_exc()
        self._tray_tries += 1
        return self._tray_tries < 25

    # ------------------------------------------------------------- построение

    def _build_ui(self):
        pal = theme.palette()
        tc = pal["panel_text"]
        sc = pal["panel_sub"]

        self.css_prov = widgets.css_provider(self.build_css())

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        box.set_margin_start(6)
        box.set_margin_end(6)

        # слева: фирменный блок LG UX (открывает домашний экран)
        self.menu_btn = Gtk.Button()
        self.menu_btn.set_relief(Gtk.ReliefStyle.NONE)
        self.menu_btn.set_can_focus(False)
        self.menu_btn.set_tooltip_text(_("Приложения (Super+Пробел)"))
        brand = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        mark = widgets.IconArea("logo", pal["accent"], 22)
        self.brand_mark = mark
        brand.pack_start(mark, False, False, 0)
        brand_name = Gtk.Label(label="LG UX")
        brand_name.get_style_context().add_class("lg-brand")
        brand.pack_start(brand_name, False, False, 0)
        self.menu_btn.add(brand)
        self.menu_btn.get_style_context().add_class("lg-brandbtn")
        self.menu_btn.connect("clicked", lambda *_: _spawn(["lg-launcher"]))
        box.pack_start(self.menu_btn, False, False, 0)

        # открытые окна — слева, сразу после знака
        self.tasks = tasklist.TaskList()
        box.pack_start(self.tasks, True, True, 10)

        # справа: часы, затем статусы
        right = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)

        self.clock_btn = Gtk.Button()
        self.clock_btn.set_relief(Gtk.ReliefStyle.NONE)
        self.clock_btn.set_can_focus(False)
        self.clock_label = Gtk.Label(label="")
        self.clock_label.get_style_context().add_class("lg-clock")
        self.clock_btn.add(self.clock_label)
        self.clock_btn.connect("clicked", self._on_clock_clicked)
        right.pack_start(self.clock_btn, False, False, 6)
        self.batt_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.batt_icon = widgets.IconArea("battery", sc, 18)
        self.batt_label = Gtk.Label(label="")
        self.batt_label.get_style_context().add_class("lg-status")
        self.batt_box.pack_start(self.batt_icon, False, False, 0)
        self.batt_box.pack_start(self.batt_label, False, False, 0)
        right.pack_start(self.batt_box, False, False, 6)

        self.wifi_btn = widgets.icon_button("wifi", sc, icon_size=18,
                                            tooltip="Wi-Fi")
        self.wifi_btn.connect("clicked", self._on_wifi_clicked)
        right.pack_start(self.wifi_btn, False, False, 0)

        self.vol_btn = widgets.icon_button("volume", sc, icon_size=18,
                                           tooltip=_("Громкость: колесо — регулировка"))
        self.vol_btn.connect("clicked", self._on_volume_clicked)
        right.pack_start(self.vol_btn, False, False, 0)

        self.dnd_btn = widgets.icon_button("bell", sc, icon_size=18,
                                           tooltip=_("Уведомления: «Не беспокоить»"))
        self.dnd_btn.connect("clicked", self._on_dnd_clicked)
        right.pack_start(self.dnd_btn, False, False, 0)

        self.cc_btn = widgets.icon_button("gear", tc, icon_size=18,
                                          tooltip=_("Центр управления (Super+A)"))
        self.cc_btn.connect("clicked", lambda *_: _spawn(["lg-control-center"]))
        right.pack_start(self.cc_btn, False, False, 0)

        # прокрутка на статусной области: громкость, Shift — яркость
        ev = Gtk.EventBox()
        ev.add(right)
        ev.set_visible_window(False)
        ev.connect("scroll-event", self._on_scroll)
        ev.connect("button-press-event", self._on_status_press)
        box.pack_end(ev, False, False, 0)

        # системный трей (значки приложений) — слева от индикаторов
        self.tray_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        box.pack_end(self.tray_box, False, False, 2)

        self.add(box)
        self.get_style_context().add_class("lg-panel")
        self.clock_btn.get_style_context().add_class("lg-clockbtn")
        self.use_css(self.css_prov)

        # контекстное меню панели
        self.connect("button-press-event", self._on_panel_press)

    def build_css(self):
        pal = theme.palette()
        t = pal["panel_rgba"]
        txt = "rgb(%d,%d,%d)" % tuple(round(c * 255) for c in pal["panel_text"])
        sub = "rgb(%d,%d,%d)" % tuple(round(c * 255) for c in pal["panel_sub"])
        accent = pal["accent"]
        bg = ""
        if self._bg_uri:
            bg = ("background-image: url('%s');\n"
                  "                background-size: 100%% 100%%;\n"
                  "                background-color: transparent;"
                  % self._bg_uri)
        else:
            bg = ("background-color: rgba({tr},{tg},{tb},{ta});"
                  .format(tr=round(t[0] * 255), tg=round(t[1] * 255),
                          tb=round(t[2] * 255), ta=t[3]))
        return """
            window.lg-panel {{
                {bg}
                color: {txt};
                border-bottom: 1px solid {line};
            }}
            .lg-brandbtn {{
                background: transparent;
                border: none;
                border-radius: 10px;
                padding: 2px 8px 2px 4px;
            }}
            .lg-brandbtn:hover {{ background-color: {hover}; }}
            .lg-brand {{
                color: {txt};
                font-size: 12px;
                font-weight: 800;
                letter-spacing: 1.4px;
            }}
            .lg-clock, .lg-status {{
                color: {txt};
                font-size: 11.5px;
                font-weight: 600;
                letter-spacing: 0.2px;
            }}
            .lg-tray {{ margin: 0 2px; }}
            .lg-clockbtn {{
                background: transparent; border: none; border-radius: 10px;
                padding: 2px 8px;
            }}
            .lg-clockbtn:hover {{
                background-color: {hover};
            }}
            .lg-task {{
                background: transparent;
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 10px 10px 0 0;
                padding: 3px 10px;
                min-height: 26px;
            }}
            .lg-task:hover {{
                background-color: {hover};
            }}
            .lg-task-active {{
                background: transparent;
                border-bottom-color: {accent};
            }}
            .lg-task-active:hover {{
                background-color: {hover};
            }}
            .lg-task label {{
                color: {txt};
                font-size: 11.5px;
            }}
            menu, menuitem {{
                background-color: {surface};
                color: {text};
                border: 1px solid {border};
                border-radius: 14px;
                padding: 4px;
            }}
            menuitem {{
                padding: 7px 16px;
                border: none;
                border-radius: 9px;
            }}
            menuitem:hover {{
                background-color: {accent_soft};
                color: {text};
            }}
        """.format(
            tr=round(t[0] * 255), tg=round(t[1] * 255), tb=round(t[2] * 255), ta=t[3],
            txt=txt, sub=sub, accent=pal["accent"],
            accent_soft=theme.css_rgba(pal["accent"], 0.16),
            accent_soft2=theme.css_rgba(pal["accent"], 0.24),
            hover=theme.css_rgba(pal["text"], 0.10),
            line=theme.css_rgba(pal["border"], 0.85),
            bg=bg,
            surface=pal["surface"], text=pal["text"], border=pal["border"],
        )

    def apply_theme(self):
        self.dnd = config.load().getboolean("general", "dnd", fallback=False)
        pal = theme.palette()
        try:
            self._sync_backdrop()   # фон пересобирается под новый цвет панели
        except Exception:
            pass
        widgets.update_provider(self.css_prov, self.build_css())
        tc = pal["panel_text"]
        sc = pal["panel_sub"]
        self.brand_mark.set_icon(color=pal["accent"])
        self.cc_btn.icon_area.set_icon(color=tc)
        self._tick_sys()

    # ---------------------------------------------------------------- часы

    def _tick_clock(self):
        now = datetime.datetime.now()
        if self.show_date:
            txt = "%s, %s · %s" % (
                widgets.ru_weekday(now), now.strftime("%d.%m"), now.strftime("%H:%M")
            )
        else:
            txt = now.strftime("%H:%M")
        if self.clock_label.get_text() != txt:
            self.clock_label.set_text(txt)
        # на блокировке и в полноэкранных приложениях (видео, игры, лаунчер)
        # панель убирается с экрана
        hide = config.is_locked() or windows.is_fullscreen(windows.active_app())
        if hide:
            if self.get_visible():
                self.hide()
        elif not self.get_visible() or not self.get_mapped():
            # панель не должна теряться: показываем заново, если окно
            # скрылось или его размапил оконный менеджер
            self.show_all()
            self.deiconify()
        return True

    def _on_clock_clicked(self, *_args):
        self._show_calendar()

    def _show_calendar(self):
        if getattr(self, "_calendar", None) is not None:
            self._hide_calendar()
        pop = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        pop.set_title(_("Календарь"))
        pop.set_type_hint(Gdk.WindowTypeHint.POPUP_MENU)
        pop.set_decorated(False)
        pop.set_resizable(False)
        pop.set_skip_taskbar_hint(True)
        pop.set_skip_pager_hint(True)
        pop.set_keep_above(True)
        pop.set_transient_for(self)
        pop.set_accept_focus(True)
        widgets.set_rgba(pop)
        pop.get_style_context().add_class("lg-popover")
        self._calendar = pop

        now = datetime.datetime.now()
        grid = Gtk.Grid()
        grid.get_style_context().add_class("lg-calendar")
        grid.set_row_spacing(2)
        grid.set_column_spacing(2)
        grid.set_margin_top(8)
        grid.set_margin_bottom(8)
        grid.set_margin_start(10)
        grid.set_margin_end(10)

        title = Gtk.Label()
        title.set_markup(
            "<b>%s %d</b>" % (i18n.months_nom()[now.month - 1], now.year)
        )
        title.set_margin_bottom(6)
        grid.attach(title, 0, 0, 7, 1)

        for i, d in enumerate(i18n.days_short()):
            lbl = Gtk.Label(label=d)
            lbl.get_style_context().add_class("lg-dayname")
            if i >= 5:
                lbl.get_style_context().add_class("lg-weekend")
            grid.attach(lbl, i, 1, 1, 1)

        import calendar as _cal  # noqa: PLC0415
        cal = _cal.Calendar(firstweekday=0).monthdayscalendar(now.year, now.month)
        row = 2
        for week in cal:
            for i, day in enumerate(week):
                if day == 0:
                    continue
                lbl = Gtk.Label(label=str(day))
                if day == now.day:
                    lbl.get_style_context().add_class("lg-today")
                elif i >= 5:
                    lbl.get_style_context().add_class("lg-weekend")
                grid.attach(lbl, i, row, 1, 1)
            row += 1

        pop.add(grid)
        widgets.apply_css_screen("""
            window.lg-popover {{
                background-color: transparent;
            }}
            window.lg-popover > decoration {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 14px;
            }}
            .lg-calendar {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 14px;
                color: {text};
                padding: 4px 6px;
            }}
            .lg-calendar .lg-dayname {{ color: {sub}; font-size: 11px; }}
            .lg-calendar .lg-weekend {{ color: {danger}; }}
            .lg-calendar .lg-today {{
                background-color: {accent}; color: {accent_text};
                border-radius: 8px; font-weight: bold;
            }}
            .lg-calendar label {{ min-width: 26px; min-height: 22px; font-size: 12px; }}
        """.format(**theme.palette()))
        pop.show_all()
        # под часами
        px, py = self.get_position()
        try:
            cx, _cy = self.clock_btn.translate_coordinates(self, 0, 0)
        except Exception:
            cx = self.clock_btn.get_allocation().x
        pop.move(px + cx, py + self.height + 4)
        pop.present()
        # замыкание не должно держать ссылку на pop: иначе PyGObject
        # финализирует окно позже и процесс может упасть
        pop.connect("focus-out-event", self._on_calendar_focus_out)
        pop.connect("key-press-event", self._on_calendar_key)

    def _on_calendar_focus_out(self, *_args):
        GLib.idle_add(self._hide_calendar)
        return False

    def _hide_calendar(self):
        pop = getattr(self, "_calendar", None)
        self._calendar = None
        if pop is not None:
            try:
                pop.destroy()
            except Exception:
                pass
        return False

    def _on_calendar_key(self, _win, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self._hide_calendar()
            return True
        return False

    # ------------------------------------------------------------ статусы

    def _tick_sys(self):
        pal = theme.palette()
        sc = pal["panel_sub"]
        acc = theme.hex_rgba(pal["accent"])[:3]

        bat = sysinfo.battery()
        if bat is None:
            self.batt_box.hide()
        else:
            cap, charging = bat
            self.batt_box.show()
            color = sc
            if charging:
                color = theme.hex_rgba(pal["success"])[:3]
            elif cap <= 20:
                color = theme.hex_rgba(pal["danger"])[:3]
            self.batt_icon.set_icon(color=color, level=cap / 100.0,
                                    charging=charging)
            self.batt_label.set_text("%d%%" % cap)

        wifi = sysinfo.wifi_enabled()
        if wifi is None:
            self.wifi_btn.hide()
        else:
            self.wifi_btn.show()
            self.wifi_btn.icon_area.set_icon(
                name="wifi" if wifi else "wifi-off",
                color=(acc if wifi else sc),
            )

        mute = sysinfo.get_mute()
        vol = sysinfo.get_volume()
        self.vol_btn.icon_area.set_icon(
            name="volume-mute" if mute else "volume",
            color=(theme.hex_rgba(pal["danger"])[:3] if mute else sc),
        )
        self.vol_btn.set_tooltip_text(
            _("Громкость: %s · колесо — регулировка, Shift+колесо — яркость")
            % (_("выкл") if mute else "%d%%" % (vol if vol is not None else 0))
        )

        self.dnd_btn.icon_area.set_icon(
            name=("moon" if self.dnd else "bell"),
            color=(acc if self.dnd else sc),
        )
        self.dnd_btn.set_tooltip_text(
            _("«Не беспокоить»: вкл") if self.dnd else _("«Не беспокоить»: выкл")
        )
        return True

    def _on_wifi_clicked(self, *_a):
        cur = sysinfo.wifi_enabled()
        if cur is not None:
            sysinfo.set_wifi(not cur)
        GLib.timeout_add_seconds(1, self._tick_sys)

    def _on_volume_clicked(self, *_a):
        sysinfo.toggle_mute()
        self._tick_sys()

    def _on_dnd_clicked(self, *_a):
        self.dnd = not self.dnd
        config.set_option("general", "dnd", "true" if self.dnd else "false")
        self._tick_sys()

    def _on_scroll(self, _w, ev):
        direction = ev.direction
        if direction not in (Gdk.ScrollDirection.UP, Gdk.ScrollDirection.DOWN):
            return False
        delta = 5 if direction == Gdk.ScrollDirection.UP else -5
        if ev.state & Gdk.ModifierType.SHIFT_MASK:
            cur = sysinfo.get_brightness()
            if cur is not None:
                sysinfo.set_brightness(cur + delta)
        else:
            cur = sysinfo.get_volume() or 0
            sysinfo.set_volume(cur + delta)
        self._tick_sys()
        return True

    def _on_status_press(self, _w, ev):
        if ev.button == 1:
            _spawn(["lg-control-center"])
            return True
        return False

    def _on_panel_press(self, _w, ev):
        if ev.button != 3:
            return False
        menu = Gtk.Menu()
        items = [
            (_("Лаунчер приложений"), lambda *_: _spawn(["lg-launcher"])),
            (_("Центр управления"), lambda *_: _spawn(["lg-control-center"])),
            (_("Заблокировать"), lambda *_: sysinfo.lock_screen()),
            (None, None),
            (_("Перезапустить панель"), self._restart_panel),
            (_("Выйти из сеанса LG UX"), lambda *_: sysinfo.logout()),
        ]
        for label, cb in items:
            if label is None:
                menu.append(Gtk.SeparatorMenuItem())
                continue
            mi = Gtk.MenuItem(label=label)
            if cb:
                mi.connect("activate", cb)
            menu.append(mi)
        menu.show_all()
        menu.connect("selection-done", lambda m: GLib.idle_add(m.destroy))
        menu.popup_at_pointer(ev)
        return True

    def _restart_panel(self, *_a):
        _spawn(["lg-panel"])
        GLib.timeout_add_seconds(1, Gio.Application.get_default().quit)


def main():
    # Gtk.Application — единственный экземпляр панели
    PanelApp().run([])


if __name__ == "__main__":
    main()

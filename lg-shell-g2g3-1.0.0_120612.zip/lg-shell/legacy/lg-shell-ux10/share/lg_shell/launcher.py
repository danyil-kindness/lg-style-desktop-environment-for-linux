# -*- coding: utf-8 -*-
"""Домашний экран LG UX: приложения, категории и поиск.

В отличие от классического «оверлея с сеткой», это полноэкранный домашний
экран в духе LG UX 10: матовое стекло поверх обоев, фирменный знак слева,
поиск справа, лента категорий и крупные плитки приложений с подписями.
"""

import cairo

from gi.repository import Gdk, Gio, GLib, Gtk, Pango

from . import apps, theme, widgets
from .i18n import _

CATEGORIES = (
    ("all", "Все"),
    ("internet", "Интернет"),
    ("media", "Медиа"),
    ("games", "Игры"),
    ("office", "Офис"),
    ("system", "Система"),
)

# Ключевые слова Categories= из .desktop
CAT_WORDS = {
    "internet": ("network", "webbrowser", "email", "news", "remoteaccess"),
    "media": ("audiovideo", "audio", "video", "graphics", "player",
              "photography", "recorder"),
    "games": ("game",),
    "office": ("office", "texteditor", "spreadsheet", "wordprocessor",
               "presentation", "calendar", "database"),
    "system": ("system", "settings", "utility", "terminalemulator",
               "filemanager", "package", "monitor"),
}


def _app_category(app):
    try:
        raw = (app.info.get_categories() or "").lower()
    except Exception:
        raw = ""
    for key, words in CAT_WORDS.items():
        if any(word in raw for word in words):
            return key
    return "system"


class LauncherApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.lgux.Launcher")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(LauncherWindow(self))
        self.win.toggle()


class LauncherWindow(widgets.ThemedWindow):
    def __init__(self, app):
        super().__init__()
        self.set_title("LG Home")
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(True)
        self.set_keep_above(True)
        widgets.set_rgba(self)
        self.get_style_context().add_class("lg-launcher")
        self.css_prov = widgets.css_provider(self.build_css())
        self.use_css(self.css_prov)

        self.category = "all"
        self.query = ""
        self.chips = {}
        self.all_apps = apps.list_apps()
        self._apps_reload_id = 0
        self._app_monitor = Gio.AppInfoMonitor.get()
        self._app_monitor.connect("changed", self._on_apps_changed)
        self.visible_apps = list(self.all_apps)

        # фон — размытые обои с тёплой вуалью (матовое стекло)
        self.bg_area = Gtk.DrawingArea()
        self.bg_area.set_hexpand(True)
        self.bg_area.set_vexpand(True)
        self.bg_area.connect("draw", self._draw_bg)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        content.set_margin_top(18)
        content.set_margin_bottom(12)
        content.set_margin_start(44)
        content.set_margin_end(44)

        # ------------------------------------------------------------ шапка
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        pal = theme.palette()

        brand = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
        mark = widgets.IconArea("logo", pal["accent"], 30)
        brand.pack_start(mark, False, False, 0)
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        title = Gtk.Label(label="LG UX")
        title.set_halign(Gtk.Align.START)
        title.get_style_context().add_class("lg-home-title")
        sub = Gtk.Label(label="Life's Good")
        sub.set_halign(Gtk.Align.START)
        sub.get_style_context().add_class("lg-home-sub")
        names.pack_start(title, False, False, 0)
        names.pack_start(sub, False, False, 0)
        brand.pack_start(names, False, False, 0)
        head.pack_start(brand, False, False, 0)

        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        head.pack_start(spacer, True, True, 0)

        # поиск справа — в отличие от центрированного поиска «в стиле Flyme»
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text(_("Поиск приложений…"))
        self.search.set_size_request(340, 42)
        self.search.get_style_context().add_class("lg-search")
        self.search.connect("changed", self._on_search_changed)
        self.search.connect("key-press-event", self._on_search_key)

        self.search_ph = Gtk.Label(label=_("Поиск приложений…"))
        self.search_ph.set_halign(Gtk.Align.START)
        self.search_ph.set_valign(Gtk.Align.CENTER)
        self.search_ph.set_margin_start(46)
        self.search_ph.set_can_focus(False)
        self.search_ph.get_style_context().add_class("lg-search-ph")
        search_overlay = Gtk.Overlay()
        search_overlay.set_halign(Gtk.Align.END)
        search_overlay.add(self.search)
        search_overlay.add_overlay(self.search_ph)
        head.pack_start(search_overlay, False, False, 0)

        close = widgets.icon_button("close", pal["text"], icon_size=16,
                                    tooltip=_("Esc — закрыть"))
        close.get_style_context().add_class("lg-closebtn")
        close.connect("clicked", lambda *_: self.hide())
        head.pack_start(close, False, False, 0)
        content.pack_start(head, False, False, 0)

        # -------------------------------------------------------- категории
        cats = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        cats.set_halign(Gtk.Align.START)
        for key, label in CATEGORIES:
            chip = Gtk.Button(label=_(label))
            chip.set_relief(Gtk.ReliefStyle.NONE)
            chip.set_can_focus(False)
            chip.get_style_context().add_class("lg-chip")
            if key == "all":
                chip.get_style_context().add_class("lg-chip-active")
            chip.connect("clicked", self._on_category, key)
            self.chips[key] = chip
            cats.pack_start(chip, False, False, 0)
        content.pack_start(cats, False, False, 0)

        # ------------------------------------------------------------ сетка
        self.flow = Gtk.FlowBox()
        self.flow.set_valign(Gtk.Align.START)
        self.flow.set_halign(Gtk.Align.FILL)
        self.flow.set_max_children_per_line(7)
        self.flow.set_min_children_per_line(3)
        self.flow.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.flow.set_activate_on_single_click(False)
        self.flow.set_homogeneous(True)
        self.flow.set_column_spacing(4)
        self.flow.set_row_spacing(8)
        self.flow.connect("child-activated", self._on_child_activated)
        self.flow.connect("move-cursor", self._on_move_cursor)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_overlay_scrolling(True)
        scroller.set_vexpand(True)
        scroller.add(self.flow)
        scroller.get_style_context().add_class("lg-scroll")
        content.pack_start(scroller, True, True, 0)

        # ------------------------------------------------------------ низ
        foot = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.count_label = Gtk.Label()
        self.count_label.get_style_context().add_class("lg-foot")
        foot.pack_start(self.count_label, False, False, 0)

        center = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        center.set_halign(Gtk.Align.CENTER)
        center.set_hexpand(True)
        home_line = Gtk.DrawingArea()
        home_line.set_size_request(52, 4)
        home_line.set_valign(Gtk.Align.CENTER)
        home_line.connect("draw", self._draw_home_line)
        center.pack_start(home_line, False, False, 0)
        foot.pack_start(center, True, True, 0)

        hint = Gtk.Label(label=_("Enter — запустить · Esc — закрыть"))
        hint.get_style_context().add_class("lg-foot")
        foot.pack_end(hint, False, False, 0)
        content.pack_start(foot, False, False, 0)

        overlay = Gtk.Overlay()
        overlay.add(self.bg_area)
        overlay.add_overlay(content)
        self.add(overlay)
        self.connect("key-press-event", self._on_key)

        self._apply_filter()
        self.connect("show", self._on_show)

    # ---------------------------------------------------------------- тема

    def build_css(self):
        pal = theme.palette()
        return """
            window.lg-launcher {{
                background-color: transparent;
            }}
            .lg-home-title {{
                color: {text}; font-size: 19px; font-weight: 800;
                letter-spacing: 0.4px;
            }}
            .lg-home-sub {{
                color: {sub}; font-size: 10.5px; font-style: italic;
            }}
            .lg-search {{
                background-color: {surface};
                border: 1px solid transparent;
                border-radius: 21px;
                padding: 0 18px;
                color: {text};
                font-size: 13.5px;
                caret-color: {accent};
                box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            }}
            .lg-search:focus {{
                border-color: {accent};
                box-shadow: 0 0 0 1px {accent};
            }}
            .lg-search-ph {{
                color: {sub};
                font-size: 13.5px;
            }}
            .lg-closebtn {{
                background: {surface};
                border: 1px solid transparent;
                border-radius: 21px;
                padding: 8px;
            }}
            .lg-closebtn:hover {{
                background: {surface2};
            }}
            .lg-chip {{
                background: transparent;
                border: 1px solid {border};
                border-radius: 17px;
                padding: 5px 14px;
                color: {sub};
                font-size: 12px;
                min-height: 18px;
            }}
            .lg-chip:hover {{
                background: {hover};
                color: {text};
            }}
            .lg-chip-active, .lg-chip-active:hover {{
                background: {accent};
                border-color: {accent};
                color: {accent_text};
                font-weight: bold;
            }}
            .lg-homeapp {{
                background: transparent;
                border: none;
                border-radius: 24px;
                padding: 10px 4px 12px;
                color: {text};
            }}
            .lg-homeapp:hover {{
                background: {hover};
            }}
            .lg-homeapp:selected {{
                background: {accent_soft};
            }}
            .lg-applabel {{
                color: {text};
                font-size: 12px;
                font-weight: 500;
            }}
            .lg-foot {{
                color: {sub};
                font-size: 11px;
            }}
            .lg-scroll, .lg-scroll frame,
            .lg-scroll viewport, .lg-scroll scrolledwindow {{
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar {{
                min-width: 14px;
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar trough {{
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar slider {{
                background-color: {slider};
                border: none;
                border-radius: 6px;
                min-width: 10px;
                min-height: 48px;
            }}
            scrollbar slider:hover {{
                background-color: {slider_hover};
            }}
            scrollbar slider:active {{
                background-color: {accent};
            }}
            scrollbar button {{
                min-width: 0; min-height: 0;
                padding: 0; margin: 0;
                border: none;
                background: none;
                box-shadow: none;
            }}
        """.format(
            text=pal["text"], sub=pal["sub"], accent=pal["accent"],
            accent_text=pal["accent_text"],
            surface=pal["surface"], surface2=pal["surface2"],
            border=pal["border"],
            hover=theme.css_rgba(pal["text"], 0.08),
            accent_soft=theme.css_rgba(pal["accent"], 0.16),
            slider=theme.css_rgba(pal["sub"], 0.45),
            slider_hover=theme.css_rgba(pal["sub"], 0.65),
        )

    def apply_theme(self):
        widgets.update_provider(self.css_prov, self.build_css())
        if self.get_window() is not None:
            self.bg_area.queue_draw()

    # ------------------------------------------------------------ фон/стекло

    def _draw_home_line(self, area, cr):
        pal = theme.palette()
        accent = theme.hex_rgba(pal["accent"])
        cr.set_source_rgba(accent[0], accent[1], accent[2], 0.92)
        theme.round_rect(cr, 0, 0, area.get_allocated_width(),
                         area.get_allocated_height(), 2)
        cr.fill()
        return False

    def _draw_bg(self, area, cr):
        alloc = area.get_allocation()
        w = max(1, alloc.width)
        h = max(1, alloc.height)
        geo = widgets.workarea_geometry()
        pb = widgets.wallpaper_blur_pixbuf(geo.x, geo.y, w, h)
        if pb is not None:
            Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
            cr.paint()
        else:
            cr.set_source_rgb(0.96, 0.94, 0.93)
            cr.paint()
        pal = theme.palette()
        o = pal["overlay"]
        cr.set_source_rgba(o[0], o[1], o[2], o[3])
        cr.paint()
        # лёгкая вертикальная вуаль — подписи читаются на любых обоях
        g = cairo.LinearGradient(0, 0, 0, h)
        g.add_color_stop_rgba(0.0, o[0], o[1], o[2], 0.0)
        g.add_color_stop_rgba(1.0, o[0], o[1], o[2], 0.28)
        cr.set_source(g)
        cr.paint()
        return False

    # ------------------------------------------------------------ наполнение

    def _apply_filter(self):
        q = self.query.lower().strip()
        out = []
        for app in self.all_apps:
            if self.category != "all" and _app_category(app) != self.category:
                continue
            if q and not app.matches(q):
                continue
            out.append(app)
        self.visible_apps = out
        self._fill(out)
        self.count_label.set_text(_("Приложений: %d") % len(out))

    def _fill(self, plist):
        for child in self.flow.get_children():
            self.flow.remove(child)
        pal = theme.palette()
        tile_bg = pal["tile_bg"]
        for app in plist:
            btn = Gtk.Button()
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_can_focus(False)
            btn.get_style_context().add_class("lg-homeapp")
            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            pb = widgets.squircle_pixbuf(app.icon_pixbuf(54), 64, tile_bg)
            img = Gtk.Image()
            if pb is not None:
                img.set_from_pixbuf(pb)
            else:
                img.set_from_icon_name("application-x-executable",
                                       Gtk.IconSize.DIALOG)
            img.set_halign(Gtk.Align.CENTER)
            vbox.pack_start(img, False, False, 0)
            label = Gtk.Label(label=app.name)
            label.set_ellipsize(Pango.EllipsizeMode.END)
            label.set_max_width_chars(16)
            label.set_halign(Gtk.Align.CENTER)
            label.get_style_context().add_class("lg-applabel")
            vbox.pack_start(label, False, False, 0)
            btn.add(vbox)
            btn.connect("clicked", self._on_button_clicked, app)
            self.flow.add(btn)
            btn.app_ref = app
        self.flow.show_all()
        if self.get_window() is not None:
            self.bg_area.queue_draw()

    def _on_category(self, _btn, key):
        self.category = key
        for name, chip in self.chips.items():
            ctx = chip.get_style_context()
            if name == key:
                ctx.add_class("lg-chip-active")
            else:
                ctx.remove_class("lg-chip-active")
        self._apply_filter()

    def _on_search_changed(self, entry):
        self.query = entry.get_text()
        self.search_ph.set_visible(not self.query.strip())
        self._apply_filter()

    # ------------------------------------------------------------- запуск

    def _launch(self, app):
        app.launch()
        self.hide()

    def _on_button_clicked(self, _btn, app):
        self._launch(app)

    def _on_child_activated(self, _fb, child):
        btn = child.get_child()
        app = getattr(btn, "app_ref", None)
        if app:
            self._launch(app)

    # ------------------------------------------------------------ клавиатура

    def _first_app(self):
        if not self.visible_apps:
            return None
        row = self.flow.get_children()
        if not row:
            return None
        sel = self.flow.get_selected_children()
        if sel:
            btn = sel[0].get_child()
            app = getattr(btn, "app_ref", None)
            if app:
                return app
        btn = row[0].get_child()
        return getattr(btn, "app_ref", None)

    def _on_search_key(self, _w, ev):
        key = ev.keyval
        if key in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_ISO_Enter):
            app = self._first_app()
            if app:
                self._launch(app)
            return True
        if key == Gdk.KEY_Escape:
            self.hide()
            return True
        if key == Gdk.KEY_Down:
            self.flow.grab_focus()
            return True
        return False

    def _on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.hide()
            return True
        return False

    def _on_move_cursor(self, _fb, _step, _count):
        return False

    # ---------------------------------------------------------------- показ

    def _on_apps_changed(self, *_a):
        # пакетный менеджер может создать десятки .desktop-файлов подряд
        if not self._apps_reload_id:
            self._apps_reload_id = GLib.timeout_add(250, self._reload_apps)
        return False

    def _reload_apps(self):
        self._apps_reload_id = 0
        apps.invalidate()
        self.all_apps = apps.list_apps()
        self._apply_filter()
        return False

    def _on_show(self, *_a):
        geo = widgets.workarea_geometry()
        self.move(geo.x, geo.y)
        self.resize(geo.width, geo.height)
        # на случай, если монитор .desktop-файлов пропустил событие
        apps.invalidate()
        self.all_apps = apps.list_apps()
        self._apply_filter()
        self.bg_area.queue_draw()
        GLib.idle_add(lambda: (self.search.grab_focus(), False)[1])

    def toggle(self):
        if self.get_visible():
            self.hide()
        else:
            self.search.set_text("")
            self.query = ""
            self.category = "all"
            for name, chip in self.chips.items():
                ctx = chip.get_style_context()
                if name == "all":
                    ctx.add_class("lg-chip-active")
                else:
                    ctx.remove_class("lg-chip-active")
            self._apply_filter()
            self.show_all()
            self.present()


def main():
    LauncherApp().run([])


if __name__ == "__main__":
    main()

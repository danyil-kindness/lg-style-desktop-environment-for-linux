# -*- coding: utf-8 -*-
"""Анимация включения LG UX: экран питания в стиле прошивки ноутбука.

Рисуется целиком cairo — без видеофайлов и внешних зависимостей. Тот же
мотив используется в Plymouth-теме загрузки (tools/gen_boot_animation.py):
почти чёрный экран, по центру знак LG со слоганом и тонкая красная линия
загрузки. Никаких точек и служебных подписей — это экран включения
устройства, а не оверлей оболочки.

Режимы:

* ``lg-splash``            — заставка на весь экран, сама закрывается;
* ``lg-splash --preview``  — окно 960×540 с повтором (Esc — выход);
* ``lg-splash --once``     — один проход на весь экран без автозакрытия.
"""

import math
import sys
import time

import cairo

from gi.repository import Gdk, GLib, Gtk

from . import config, theme, widgets

# Цвета экрана включения (всегда тёмные, независимо от темы рабочего стола)
BG_TOP = (0.020, 0.014, 0.018)
BG_BOTTOM = (0.004, 0.003, 0.005)
GLOW = (0.647, 0.000, 0.204)      # глубокий LG-красный для свечения
MARK = (0.914, 0.208, 0.361)      # #E9355C — знак на тёмном
WORD = (0.980, 0.965, 0.973)
SUB = (0.66, 0.61, 0.65)

FPS = 60


def _clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))


def _ease_out(x):
    x = _clamp(x)
    return 1.0 - (1.0 - x) ** 3


def _ease_in_out(x):
    x = _clamp(x)
    return x * x * (3.0 - 2.0 * x)


def _fade(t, start, span=0.5):
    """Плавное появление: 0 до start, 1 после start+span."""
    return _ease_in_out((t - start) / span)


def _radial(cr, cx, cy, radius, color, alpha):
    grad = cairo.RadialGradient(cx, cy, 0, cx, cy, max(1.0, radius))
    grad.add_color_stop_rgba(0.0, color[0], color[1], color[2], alpha)
    grad.add_color_stop_rgba(0.55, color[0], color[1], color[2], alpha * 0.35)
    grad.add_color_stop_rgba(1.0, color[0], color[1], color[2], 0.0)
    cr.set_source(grad)
    cr.paint()


def _draw_text(cr, text, cx, cy, size, color, alpha=1.0, bold=True,
               italic=False, spacing=0.0):
    cr.save()
    cr.set_source_rgba(color[0], color[1], color[2], alpha)
    cr.select_font_face(
        "DejaVu Sans",
        cairo.FONT_SLANT_ITALIC if italic else cairo.FONT_SLANT_NORMAL,
        cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL,
    )
    cr.set_font_size(size)
    if spacing:
        width = sum(cr.text_extents(ch).x_advance for ch in text)
        width += spacing * max(0, len(text) - 1)
        x = cx - width / 2.0
        for ch in text:
            e = cr.text_extents(ch)
            cr.move_to(x, cy - e.height / 2.0 - e.y_bearing)
            cr.show_text(ch)
            x += e.x_advance + spacing
    else:
        ext = cr.text_extents(text)
        cr.move_to(cx - ext.width / 2.0 - ext.x_bearing,
                   cy - ext.height / 2.0 - ext.y_bearing)
        cr.show_text(text)
    cr.restore()


def _word_width(cr, text, size):
    cr.save()
    cr.select_font_face("DejaVu Sans", cairo.FONT_SLANT_NORMAL,
                        cairo.FONT_WEIGHT_BOLD)
    cr.set_font_size(size)
    width = cr.text_extents(text).width
    cr.restore()
    return width


def draw_scene(cr, w, h, t, duration=3.0):
    """Нарисовать кадр экрана включения для момента t (секунды)."""
    # почти чёрный фон с очень мягким красным дыханием
    grad = cairo.LinearGradient(0, 0, 0, h)
    grad.add_color_stop_rgb(0.0, *BG_TOP)
    grad.add_color_stop_rgb(0.62, 0.010, 0.007, 0.010)
    grad.add_color_stop_rgb(1.0, *BG_BOTTOM)
    cr.set_source(grad)
    cr.paint()

    cx = w / 2.0
    cy = h / 2.0 - h * 0.025
    lh = min(h * 0.30, w * 0.20)          # высота логотипного блока
    mark_size = lh * 0.95
    word_h = lh * 0.85
    gap = lh * 0.18
    word_w = _word_width(cr, "LG", word_h)
    mark_w = mark_size * 0.87
    total = mark_w + gap + word_w
    left = cx - total / 2.0
    mark_cx = left + mark_size * 0.3875
    word_cx = left + mark_w + gap + word_w / 2.0
    logo_cy = cy - lh * 0.06

    # мягкое свечение за знаком
    glow_in = _fade(t, 0.0, 0.85)
    if glow_in > 0:
        _radial(cr, mark_cx, logo_cy, lh * 1.55, GLOW, 0.13 * glow_in)

    # появление: знак, затем надпись, затем слоган
    mark_in = _ease_out((t - 0.05) / 0.60)
    word_in = _ease_out((t - 0.30) / 0.60)
    tag_in = _ease_out((t - 0.65) / 0.60)

    if mark_in > 0:
        cr.save()
        scale = 0.94 + 0.06 * mark_in
        cr.translate(mark_cx, logo_cy)
        cr.scale(scale, scale)
        cr.translate(-mark_cx, -logo_cy)
        cr.push_group()
        theme.draw_lg_mark(cr, mark_cx, logo_cy, mark_size, MARK)
        # тонкий блик по верхней дуге
        cr.save()
        cr.set_line_width(max(1.0, mark_size * 0.012))
        cr.set_source_rgba(1, 1, 1, 0.10)
        cr.arc(mark_cx, logo_cy, mark_size * 0.31,
               math.radians(-150), math.radians(-62))
        cr.stroke()
        cr.restore()
        cr.pop_group_to_source()
        cr.paint_with_alpha(mark_in)
        cr.restore()

    if word_in > 0:
        cr.push_group()
        theme.draw_lg_wordmark(cr, word_cx, logo_cy, word_h, WORD)
        cr.pop_group_to_source()
        cr.paint_with_alpha(word_in)

    # слоган
    tag_size = lh * 0.165
    tag_cy = cy + lh * 0.52
    if tag_in > 0:
        cr.push_group()
        theme.draw_tagline(cr, cx, tag_cy, tag_size, SUB,
                           text="Life's Good")
        cr.pop_group_to_source()
        cr.paint_with_alpha(tag_in)

    # тонкая линия загрузки
    bar_w = min(w * 0.34, 360.0)
    bar_h = max(2.0, bar_w * 0.010)
    bar_y = cy + lh * 0.78
    bar_x = cx - bar_w / 2.0
    p = _ease_in_out((t - 0.55) / max(0.25, duration - 0.65))
    line_in = _fade(t, 0.45, 0.55)
    if line_in > 0:
        r = bar_h / 2.0
        theme.round_rect(cr, bar_x, bar_y, bar_w, bar_h, r)
        cr.set_source_rgba(1, 1, 1, 0.12 * line_in)
        cr.fill()
        if p > 0:
            theme.round_rect(cr, bar_x, bar_y, max(bar_h, bar_w * p),
                             bar_h, r)
            cr.set_source_rgba(MARK[0], MARK[1], MARK[2],
                               0.96 * line_in)
            cr.fill()


class SplashWindow(Gtk.Window):
    def __init__(self, app, monitor=None, preview=False):
        super().__init__()
        self.app = app
        self.monitor = monitor
        self.preview = preview
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_app_paintable(True)
        self.set_title("LG UX")
        if preview:
            self.set_default_size(960, 540)
            self.set_resizable(True)
            self.set_accept_focus(True)
            self.set_position(Gtk.WindowPosition.CENTER)
        else:
            self.set_accept_focus(False)
            self.set_type_hint(Gdk.WindowTypeHint.SPLASHSCREEN)
        self.area = Gtk.DrawingArea()
        self.area.set_double_buffered(True)
        self.area.connect("draw", self._on_draw)
        self.add(self.area)
        self.connect("key-press-event", self._on_key)
        self.connect("button-press-event", lambda *_: self.app.finish())
        self.connect("destroy", lambda *_: self.app.window_closed(self))

    def _on_draw(self, _area, cr):
        alloc = self.area.get_allocation()
        draw_scene(cr, max(1, alloc.width), max(1, alloc.height),
                   self.app.elapsed(), self.app._duration)
        return False

    def _on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.app.finish()
            return True
        if ev.keyval == Gdk.KEY_space and self.preview:
            self.app.restart()
            return True
        return False

    def do_show(self):
        Gtk.Window.do_show(self)
        if self.preview:
            return
        geo = self.monitor.get_geometry() if self.monitor is not None \
            else widgets.primary_geometry()
        widgets.fullscreen_on_geometry(self, geo)


class SplashApp(widgets.ShellApp):
    def __init__(self, preview=False, auto_close=True, loop=False):
        super(SplashApp, self).__init__("org.lgux.Splash")
        self.preview = preview
        self.auto_close = auto_close
        self.loop = loop
        self.windows = []
        self._start = time.monotonic()
        self._duration = max(1.0, config.load().getfloat(
            "splash", "duration", fallback=3.0))
        self._fading = False
        self._tick_id = 0
        self._held = False

    # ------------------------------------------------------------- время
    def elapsed(self):
        return time.monotonic() - self._start

    def restart(self):
        self._start = time.monotonic()
        self._fading = False
        for win in self.windows:
            try:
                win.set_opacity(1.0)
            except Exception:
                pass
        self._queue_draw()

    def _queue_draw(self):
        for win in self.windows:
            try:
                win.area.queue_draw()
            except Exception:
                pass

    # ------------------------------------------------------------- показ
    def do_activate(self):
        if self.windows:
            # повторный запуск: просто приветствуем уже открытую заставку
            self.restart()
            return
        # держим GApplication живым, пока открыты окна заставки
        self._held = True
        self.hold()
        display = Gdk.Display.get_default()
        if self.preview:
            win = SplashWindow(self, None, preview=True)
            self.windows.append(win)
            win.show_all()
        else:
            count = display.get_n_monitors() if display is not None else 1
            for i in range(max(1, count)):
                monitor = display.get_monitor(i) if display is not None else None
                win = SplashWindow(self, monitor)
                self.windows.append(win)
                win.show_all()
        self._tick_id = GLib.timeout_add(max(8, 1000 // FPS), self._tick)
        if not self.preview and self.auto_close:
            ms = int((self._duration + 0.7) * 1000)
            GLib.timeout_add(ms, self.finish)

    def _tick(self):
        if not self.windows:
            return False
        t = self.elapsed()
        if self.preview and self.loop and t > self._duration + 0.9:
            self.restart()
        if not self.preview and self.auto_close and not self._fading \
                and t >= self._duration:
            self._fading = True
            GLib.timeout_add(30, self._fade_step, 1.0)
        self._queue_draw()
        return True

    def _fade_step(self, value):
        if not self.windows:
            return False
        value = max(0.0, value - 0.08)
        done = value <= 0.0
        for win in self.windows:
            try:
                win.set_opacity(0.0 if done else value)
            except Exception:
                pass
        if done:
            self.finish()
            return False
        return True

    def finish(self):
        if self._tick_id:
            try:
                GLib.source_remove(self._tick_id)
            except Exception:
                pass
            self._tick_id = 0
        wins, self.windows = self.windows, []
        for win in wins:
            try:
                win.destroy()
            except Exception:
                pass
        self._release()
        GLib.idle_add(self.quit)

    def _release(self):
        if self._held:
            self._held = False
            try:
                self.release()
            except Exception:
                pass

    def window_closed(self, win):
        if win in self.windows:
            self.windows.remove(win)
        if not self.windows:
            if self._tick_id:
                try:
                    GLib.source_remove(self._tick_id)
                except Exception:
                    pass
                self._tick_id = 0
            self._release()
            GLib.idle_add(self.quit)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    preview = "--preview" in argv
    once = "--once" in argv
    loop = "--loop" in argv or preview
    app = SplashApp(preview=preview, auto_close=not once, loop=loop)
    app.run([sys.argv[0]] if argv else [])


if __name__ == "__main__":
    main()

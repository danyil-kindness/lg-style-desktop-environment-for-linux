# -*- coding: utf-8 -*-
"""Системный трей панели: XEmbed (_NET_SYSTEM_TRAY_S0).

Приложения (Steam, Telegram, мессенджеры и т. п.) кладут значки в системный
трей. Здесь мы сами становимся владельцем выбора ``_NET_SYSTEM_TRAY_S<экран>``
и принимаем запросы на «док», встраивая окна значков в панель через
``Gtk.Socket``.

Управление значком:

* левая кнопка — как обычно у приложения (чаще всего открывает окно);
* правая — меню самого приложения (там обычно есть «Выход»);
* средняя — закрыть приложение (как средняя кнопка в списке окон панели).
"""

import ctypes
import os
import signal

from gi.repository import GLib, Gtk

from . import windows, x11

CLIENT_MESSAGE = 33
DESTROY_NOTIFY = 17
REPARENT_NOTIFY = 21
SELECTION_CLEAR = 29
BUTTON_PRESS = 4

STRUCTURE_NOTIFY = 1 << 17
BUTTON_PRESS_MASK = 1 << 2
BUTTON_RELEASE_MASK = 1 << 3
GRAB_MODE_ASYNC = 1
ANY_MODIFIER = 1 << 15

SYSTEM_TRAY_REQUEST_DOCK = 0


def _log(text):
    try:
        import sys
        sys.stderr.write("lg-tray: %s\n" % text)
        sys.stderr.flush()
    except Exception:
        pass


class TrayHost(object):
    """Владелец системного трея; значки пакуются в ``box``."""

    def __init__(self, panel, box):
        self.panel = panel
        self.box = box
        self.dpy = x11.display()
        self.owner = 0
        self.sel_atom = 0
        self.opcode_atom = 0
        self.manager_atom = 0
        self.visual_atom = 0
        self.orientation_atom = 0
        self.clients = {}          # plug xid -> Gtk.Socket
        self.started = False
        self._poll_id = 0

    # --------------------------------------------------------------- запуск

    def start(self):
        """Стать владельцем трея. True — получилось (или уже получилось)."""
        if self.started:
            return True
        if not self.dpy:
            return False
        try:
            gdk_win = self.panel.get_window()
            panel_xid = gdk_win.get_xid() if gdk_win is not None else 0
        except Exception:
            panel_xid = 0
        if not panel_xid:
            return False

        root = x11.atom_root()
        screen = 0
        try:
            from gi.repository import Gdk  # noqa: PLC0415
            sc = Gdk.Screen.get_default()
            if sc is not None:
                screen = sc.get_number()
        except Exception:
            pass

        self.sel_atom = x11.atom("_NET_SYSTEM_TRAY_S%d" % screen)
        self.opcode_atom = x11.atom("_NET_SYSTEM_TRAY_OPCODE")
        self.manager_atom = x11.atom("MANAGER")
        self.visual_atom = x11.atom("_NET_SYSTEM_TRAY_VISUAL")
        self.orientation_atom = x11.atom("_NET_SYSTEM_TRAY_ORIENTATION")
        if not (self.sel_atom and self.opcode_atom and self.manager_atom):
            return False

        self.owner = int(x11.X.XCreateSimpleWindow(
            self.dpy, root, -20, -20, 1, 1, 0, 0, 0))
        if not self.owner:
            return False
        x11.X.XSelectInput(self.dpy, self.owner, STRUCTURE_NOTIFY)
        x11.X.XSetSelectionOwner(self.dpy, self.sel_atom, self.owner, 0)
        x11.X.XSync(self.dpy, 0)
        if int(x11.X.XGetSelectionOwner(self.dpy, self.sel_atom)) != self.owner:
            # трей уже занят другим хостом (например, xfce4-panel)
            x11.X.XDestroyWindow(self.dpy, self.owner)
            self.owner = 0
            _log("трей уже занят другим приложением")
            return False

        self._set_cardinal(self.owner, self.orientation_atom, 0)  # horizontal
        visual = self._panel_visual(panel_xid)
        if visual:
            # Клиентам нужен тот же visual, что и у окон Gtk.Socket внутри
            # панели, иначе XReparentWindow падает с ошибкой BadMatch
            # (дочернее окно обязано иметь глубину родителя). Панель рисуется
            # в обычном 24-битном visual, поэтому и здесь он же.
            self._set_cardinal(self.owner, self.visual_atom, visual, "CARDINAL")
            self._set_cardinal(root, self.visual_atom, visual, "CARDINAL")

        self._announce(root)
        self.started = True
        self._poll_id = GLib.timeout_add(120, self._pump)
        return True

    def stop(self):
        """Отпустить значки по-хорошему (перед os.execv панели).

        GtkSocket при уничтожении возвращает встроенные окна в корень, но
        запросы Xlib ещё в буфере: без XSync они не дойдут до сервера, и после
        exec окна значков будут просто уничтожены вместе с соединением.
        """
        if self._poll_id:
            try:
                GLib.source_remove(self._poll_id)
            except Exception:
                pass
            self._poll_id = 0
        # возвращаем окна значков в корень: приложение увидит, что его
        # «выселили», и после появления новой панели подключится снова
        root = x11.atom_root()
        for xid in list(self.clients):
            try:
                x11.X.XReparentWindow(self.dpy, int(xid), int(root), 0, 0)
            except Exception:
                pass
        try:
            x11.X.XSync(self.dpy, 0)
        except Exception:
            pass
        for xid in list(self.clients):
            self._undock(xid)
        if self.owner:
            try:
                x11.X.XDestroyWindow(self.dpy, self.owner)
            except Exception:
                pass
            self.owner = 0
        try:
            x11.X.XSync(self.dpy, 0)   # до сервера должны дойти reparent-запросы
        except Exception:
            pass
        self.started = False

    # ------------------------------------------------------------- мелочи X

    def _set_cardinal(self, win, atom_id, value, type_name="CARDINAL"):
        if not (win and atom_id):
            return
        card = x11.atom(type_name)
        if not card:
            return
        arr = (ctypes.c_long * 1)(int(value))
        x11.X.XChangeProperty(self.dpy, int(win), int(atom_id), card, 32, 0,
                              ctypes.byref(arr), 1)
        x11.X.XFlush(self.dpy)

    def _panel_visual(self, panel_xid):
        """VisualID окна панели — его унаследуют Gtk.Socket внутри."""
        try:
            attrs = x11.XWindowAttributes()
            if not x11.X.XGetWindowAttributes(
                    self.dpy, int(panel_xid), ctypes.byref(attrs)):
                return 0
            if not attrs.visual:
                return 0
            return int(x11.X.XVisualIDFromVisual(attrs.visual))
        except Exception:
            return 0

    def _announce(self, root):
        """Разослать MANAGER: приложения переподключатся к новому трею."""
        ev = x11.XEvent()
        ev.xclient.type = CLIENT_MESSAGE
        ev.xclient.send_event = 1
        ev.xclient.window = int(root)
        ev.xclient.message_type = int(self.manager_atom)
        ev.xclient.format = 32
        ev.xclient.data[0] = 0
        ev.xclient.data[1] = int(self.sel_atom)
        ev.xclient.data[2] = int(self.owner)
        # маска StructureNotifyMask обязательна: при маске 0 событие для
        # корневого окна отбрасывается (у корня нет создавшего клиента)
        x11.X.XSendEvent(self.dpy, int(root), 0, STRUCTURE_NOTIFY,
                         ctypes.byref(ev))
        x11.X.XFlush(self.dpy)

    # -------------------------------------------------------------- события

    def _pump(self):
        ev = x11.XEvent()
        n = 0
        while n < 64 and x11.X.XPending(self.dpy):
            x11.X.XNextEvent(self.dpy, ctypes.byref(ev))
            n += 1
            try:
                self._handle(ev)
            except Exception as exc:  # pragma: no cover
                _log("ошибка обработки события: %r" % (exc,))
        return True

    def _handle(self, ev):
        etype = ev.type
        if etype == CLIENT_MESSAGE:
            if (int(ev.xclient.message_type) == self.opcode_atom
                    and int(ev.xclient.data[1]) == SYSTEM_TRAY_REQUEST_DOCK):
                xid = int(ev.xclient.data[2])
                if xid:
                    self._dock(xid)
        elif etype == DESTROY_NOTIFY:
            # окно значка закрылось (приложение вышло или убрало иконку)
            self._undock(int(ev.xany.window))
        elif etype == SELECTION_CLEAR:
            if int(ev.xany.window) == self.owner:
                _log("трей перехватило другое приложение")
        elif etype == BUTTON_PRESS:
            if int(ev.xbutton.button) == 2:
                self._close_window_app(int(ev.xbutton.window))

    # ------------------------------------------------------------------ док

    def _dock(self, xid):
        if xid in self.clients:
            return
        sock = Gtk.Socket()
        sock.get_style_context().add_class("lg-tray")
        self.box.pack_start(sock, False, False, 0)
        sock.show_all()
        try:
            sock.add_id(xid)
        except Exception as exc:
            _log("не удалось встроить значок %s: %r" % (xid, exc))
            sock.destroy()
            return
        if sock.get_plug_window() is None:
            _log("значок %s не встроился (вероятно, другая глубина окна)" % xid)
            sock.destroy()
            return

        sock.connect("plug-removed", lambda _s: self._forget(xid) or False)
        self.clients[xid] = sock
        try:
            x11.X.XSelectInput(self.dpy, xid, STRUCTURE_NOTIFY)
            # средняя кнопка — наша: закрыть приложение
            x11.X.XGrabButton(self.dpy, 2, ANY_MODIFIER, xid, False,
                              BUTTON_PRESS_MASK | BUTTON_RELEASE_MASK,
                              GRAB_MODE_ASYNC, GRAB_MODE_ASYNC, 0, 0)
            x11.X.XFlush(self.dpy)
        except Exception:
            pass
        _log("значок %s добавлен (класс: %s)"
             % (xid, " / ".join(x11.wm_class(xid)) or "?"))

    def _forget(self, xid):
        """Gtk.Socket сам убрал встроенное окно — чистим список."""
        if self.clients.pop(xid, None) is not None:
            try:
                x11.X.XUngrabButton(self.dpy, 2, ANY_MODIFIER, xid)
            except Exception:
                pass

    def _undock(self, xid):
        sock = self.clients.pop(xid, None)
        if sock is None:
            return

        try:
            x11.X.XUngrabButton(self.dpy, 2, ANY_MODIFIER, xid)
        except Exception:
            pass
        try:
            sock.destroy()
        except Exception:
            pass

    # -------------------------------------------------------------- закрытие

    def _close_window_app(self, plug_xid):
        pid = self._pid_for(plug_xid)
        if not pid:
            _log("не удалось определить процесс значка %s" % plug_xid)
            return
        _log("закрываю приложение pid=%d" % pid)
        wins = []
        try:
            for win in windows.windows():
                try:
                    if int(win.get_pid() or 0) == pid:
                        wins.append(int(win.get_xid()))
                except Exception:
                    continue
        except Exception:
            wins = []
        for xid in wins:
            try:
                x11.close_window(xid)
            except Exception:
                pass
        GLib.timeout_add(2500, _terminate_if_alive, pid)

    def _pid_for(self, plug_xid):
        pid = 0
        try:
            pid = int(x11.pid_of(plug_xid) or 0)
        except Exception:
            pid = 0
        if pid:
            return pid
        # запасной путь: то же WM_CLASS у обычного окна приложения
        classes = set(x11.wm_class(plug_xid))
        if not classes:
            return 0
        try:
            for win in windows.windows():
                same = classes.intersection(x11.wm_class(int(win.get_xid())))
                if same:
                    return int(win.get_pid() or 0)
        except Exception:
            pass
        return 0


def _terminate_if_alive(pid):
    """SIGTERM приложению, если после закрытия окон оно всё ещё живо."""
    try:
        os.kill(int(pid), 0)
    except OSError:
        return False
    try:
        os.kill(int(pid), signal.SIGTERM)
        _log("приложение pid=%d не закрылось окном — послал SIGTERM" % pid)
    except Exception:
        pass
    return False

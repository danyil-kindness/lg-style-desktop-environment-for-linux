# -*- coding: utf-8 -*-
"""Общие GTK-виджеты и помощники для окон оболочки."""

import ctypes
import os
import sys

import cairo

from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk

from . import config, i18n, theme, x11

_TILE_CACHE = {}
_BLUR_CACHE = {}


def squircle_pixbuf(pb, size, bg_rgba=(1, 1, 1, 1), radius=None):
    """Иконка приложения в «сквиркле» — фирменной форме LG UX.

    Рисуем плашку с крупным скруглением и кладём иконку по центру. Так
    разношёрстные иконки Linux выглядят единым набором, как в LG UX.
    """
    if pb is None:
        return None
    radius = size * 0.30 if radius is None else radius
    key = (id(pb), size, tuple(round(c, 3) for c in bg_rgba), round(radius, 2))
    hit = _TILE_CACHE.get(key)
    if hit is not None:
        return hit
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size)
    cr = cairo.Context(surf)
    theme.round_rect(cr, 0.75, 0.75, size - 1.5, size - 1.5, radius)
    cr.set_source_rgba(*bg_rgba)
    cr.fill_preserve()
    cr.set_source_rgba(0, 0, 0, 0.06)
    cr.set_line_width(1.2)
    cr.stroke()

    inner = max(8, int(size * 0.70))
    try:
        scaled = pb.scale_simple(inner, inner, GdkPixbuf.InterpType.BILINEAR)
    except Exception:
        scaled = pb
    cr.save()
    theme.round_rect(cr, 0.75, 0.75, size - 1.5, size - 1.5, radius)
    cr.clip()
    Gdk.cairo_set_source_pixbuf(cr, scaled, (size - inner) / 2.0,
                                (size - inner) / 2.0)
    cr.paint()
    cr.restore()
    out = Gdk.pixbuf_get_from_surface(surf, 0, 0, size, size)
    if len(_TILE_CACHE) > 600:
        _TILE_CACHE.clear()
    _TILE_CACHE[key] = out
    return out


class ShellApp(Gio.Application):
    """Один экземпляр компонента оболочки (аналог Gtk.Application).

    Gtk.Application при старте синхронно спрашивает xdg-desktop-portal; если
    портал в системе отвечает медленно, окно появляется только через ~25 с.
    Gio.Application даёт то же единичное владение D-Bus-именем и активацию
    второго запуска, но портал не задействует.
    """

    def __init__(self, app_id):
        super().__init__(application_id=app_id)

    def track(self, window):
        """Держать приложение живым, пока окно не закрыто."""
        self.hold()
        window.connect("destroy", lambda *_a: self.release())
        return window


class IconArea(Gtk.DrawingArea):
    """Компактная иконка, нарисованная cairo."""

    def __init__(self, name, color=(0, 0, 0), size=24, **kw):
        super().__init__()
        self.icon_name = name
        self.icon_color = color
        self.icon_size = size
        self.icon_kwargs = kw
        self.set_size_request(size, size)
        self.connect("draw", self._on_draw)

    def set_icon(self, name=None, color=None, **kw):
        if name:
            self.icon_name = name
        if color is not None:
            self.icon_color = color
        self.icon_kwargs = kw
        self.queue_draw()

    def _on_draw(self, _area, cr):
        theme.draw(
            cr, self.icon_name, self.icon_color, self.icon_size, **self.icon_kwargs
        )
        return False


def css_provider(data):
    provider = Gtk.CssProvider()
    provider.load_from_data(data.encode("utf-8"))
    return provider


def apply_css(widget, data, priority=Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION):
    """CSS только для самого виджета (не для его потомков)."""
    widget.get_style_context().add_provider(css_provider(data), priority)


def add_screen_provider(provider, priority=Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 10):
    """Добавить провайдер для всего экрана: правила действуют и на потомков."""
    screen = Gdk.Screen.get_default()
    if screen is not None:
        Gtk.StyleContext.add_provider_for_screen(screen, provider, priority)
    return provider


def remove_screen_provider(provider):
    screen = Gdk.Screen.get_default()
    if screen is not None:
        Gtk.StyleContext.remove_provider_for_screen(screen, provider)


def apply_css_screen(data, priority=Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 10):
    return add_screen_provider(css_provider(data), priority)


def update_provider(provider, data):
    try:
        provider.load_from_data(data.encode("utf-8"))
    except Exception:
        pass


def set_rgba(window):
    screen = window.get_screen()
    visual = screen.get_rgba_visual()
    if visual and screen.is_composited():
        window.set_visual(visual)
        return True
    return False


def set_rgb(window):
    """Обычный 24-битный visual: в него можно встраивать окна чужих приложений.

    Дочерние окна обязаны иметь ту же глубину, что и родитель, поэтому окно,
    в которое встраиваются значки трея (XEmbed), не может быть RGBA.
    """
    screen = window.get_screen()
    visual = None
    if screen is not None:
        try:
            visual = screen.get_system_visual()
        except Exception:
            visual = None
    if visual is not None:
        window.set_visual(visual)
        return True
    return False


def wallpaper_pixbuf(x, y, w, h):
    """Кусок обоев из корневого pixmap (_XROOTPMAP_ID).

    Pixmap не перекрывается окнами, поэтому снимок всегда содержит обои,
    даже когда панель уже нарисована сверху.
    """
    dpy = x11.display()
    if not dpy or w <= 0 or h <= 0:
        return None
    ids = x11._card32(x11.atom_root(), "_XROOTPMAP_ID")
    if not ids:
        return None
    ptr = x11.get_image(dpy, ids[0], x, y, w, h)
    if not ptr:
        return None
    try:
        img = ctypes.cast(ptr, ctypes.POINTER(x11.XImage)).contents
        bpp = max(1, img.bits_per_pixel // 8)
        stride = max(1, img.bytes_per_line)
        data = ctypes.string_at(img.data, stride * img.height)
        out = bytearray(w * h * 3)
        for row in range(h):
            base = row * stride
            line = data[base:base + w * bpp]
            start = row * w * 3
            end = start + w * 3
            out[start:end:3] = line[2::bpp]
            out[start + 1:end:3] = line[1::bpp]
            out[start + 2:end:3] = line[0::bpp]
        return GdkPixbuf.Pixbuf.new_from_bytes(
            GLib.Bytes.new(bytes(out)), GdkPixbuf.Colorspace.RGB, False, 8,
            w, h, w * 3)
    except Exception:
        return None
    finally:
        x11.destroy_image(ptr)


def wallpaper_blur_pixbuf(x, y, w, h, factor=24):
    """Размытые обои для «матового стекла» лаунчера.

    Настоящего blur в GdkPixbuf нет, поэтому уменьшаем снимок в factor раз
    и растягиваем обратно билинейно — получается мягкое свечение цветов.
    """
    key = (x, y, w, h, factor)
    hit = _BLUR_CACHE.get(key)
    if hit is not None:
        return hit
    src = wallpaper_pixbuf(x, y, w, h)
    if src is None:
        return None
    try:
        small = src.scale_simple(max(1, w // factor), max(1, h // factor),
                                 GdkPixbuf.InterpType.BILINEAR)
        out = small.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
    except Exception:
        out = src
    if len(_BLUR_CACHE) > 6:
        _BLUR_CACHE.clear()
    _BLUR_CACHE[key] = out
    return out


def primary_geometry():
    display = Gdk.Display.get_default()
    monitor = display.get_primary_monitor()
    if monitor is None and display.get_n_monitors() > 0:
        monitor = display.get_monitor(0)
    if monitor is None:
        return Gdk.Rectangle()
    return monitor.get_geometry()


def workarea_geometry():
    """Рабочая область основного монитора (без полосы, занятой панелью)."""
    display = Gdk.Display.get_default()
    monitor = display.get_primary_monitor()
    if monitor is None and display.get_n_monitors() > 0:
        monitor = display.get_monitor(0)
    if monitor is None:
        return primary_geometry()
    try:
        wa = monitor.get_workarea()
        if wa and wa.width > 0 and wa.height > 0:
            return wa
    except Exception:
        pass
    return primary_geometry()


def fullscreen_on_geometry(window, geo=None):
    """Развернуть окно на заданном мониторе (совместимо со старым GI)."""
    if geo is None:
        geo = primary_geometry()
    screen = window.get_screen()
    cx = geo.x + max(1, geo.width // 2)
    cy = geo.y + max(1, geo.height // 2)
    try:
        idx = screen.get_monitor_at_point(cx, cy)
    except Exception:
        idx = 0
    try:
        window.fullscreen_on_monitor(screen, idx)
    except TypeError:
        try:
            window.fullscreen()
        except Exception:
            pass


def reserve_top(window, size):
    window.get_window().stick()
    GLib_idle_strut(window, "top", size)


def GLib_idle_strut(gdk_window, side, size):
    """gdk_window — GdkWindow окна (window.get_window())."""
    from gi.repository import GLib  # noqa: PLC0415

    def do():
        geo = primary_geometry()
        x11.set_strut(gdk_window, side, size, geo.width, geo.height)
        return False

    GLib.idle_add(do)


class ThemedWindow(Gtk.Window):
    """Окно с переключаемой темой: переопределяйте build_css() и apply_theme()."""

    #: перезапускать процесс при смене языка (окно настроек — False)
    relaunch_on_language = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._theme_providers = []
        self._screen_providers = []
        self._config_monitor = config.watch(self._on_config_changed)
        self.connect("destroy", self._drop_screen_providers)
        # монитор конфига держит ссылку на окно: отпускаем её при закрытии,
        # иначе PyGObject финализирует окно позже и может уронить процесс
        self.connect("destroy", lambda *_: GLib.idle_add(self._drop_monitor))
        GLib.timeout_add(500, self._lock_watch)

    def _drop_monitor(self):
        monitor = getattr(self, "_config_monitor", None)
        self._config_monitor = None
        if monitor is not None:
            try:
                monitor.cancel()
            except Exception:
                pass
        return False

    def _lock_watch(self):
        """Скрыть оверлеи при блокировке (панель/док показываются сами)."""
        if config.is_locked() and self.get_visible():
            self.hide()
        return True

    def use_css(self, provider):
        """Подключить CSS-провайдер ко всему экрану (для дочерних виджетов)."""
        add_screen_provider(provider)
        if provider not in self._screen_providers:
            self._screen_providers.append(provider)

    def _drop_screen_providers(self, *_a):
        for provider in self._screen_providers:
            remove_screen_provider(provider)
        self._screen_providers = []

    def build_css(self):
        return ""

    def apply_theme(self):
        raise NotImplementedError

    def refresh_css(self):
        self.apply_theme()

    def _on_config_changed(self):
        if self.relaunch_on_language and i18n.started() != i18n.current():
            # язык сменился: переводить все подписи на лету слишком сложно,
            # поэтому компонент перезапускается с новым языком
            GLib.idle_add(self._relaunch)
            return False
        if self.get_window() is not None:
            self.refresh_css()
        return False

    def before_relaunch(self):
        """Хук для подклассов: убрать за собой до os.execv()."""

    def _relaunch(self):
        try:
            self.before_relaunch()
        except Exception:
            pass
        argv = list(getattr(sys, "argv", None) or [])
        exe = sys.executable or ""
        if not argv or not exe or not os.path.isfile(argv[0] or ""):
            return False
        try:
            os.execv(exe, [exe, os.path.abspath(argv[0])] + argv[1:])
        except Exception:
            pass
        return False


def icon_button(icon_name, color, size=24, icon_size=20, tooltip=""):
    """Кнопка-иконка без рамки."""
    btn = Gtk.Button()
    btn.set_relief(Gtk.ReliefStyle.NONE)
    btn.set_can_focus(False)
    area = IconArea(icon_name, color, icon_size)
    btn.add(area)
    btn.icon_area = area
    if tooltip:
        btn.set_tooltip_text(tooltip)
    css = "button { background: transparent; border: none; border-radius: 8px; padding: 4px; }" \
          "button:hover { background-color: rgba(127,127,127,0.18); }"
    apply_css(btn, css)
    return btn


def ru_date(dt):
    return i18n.date_text(dt)


def ru_weekday(dt):
    return i18n.weekday_text(dt)

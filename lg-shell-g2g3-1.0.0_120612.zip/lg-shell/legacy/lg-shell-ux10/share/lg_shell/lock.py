# -*- coding: utf-8 -*-
"""Экран блокировки LG (эстетический; для защиты — light-locker, см. README).

Сцена в духе LG UX: почти чёрный фон, разомкнутое красное кольцо-знак,
крупные часы слева и тонкая красная линия. Никакого центрированного
«обоечного» макета — фирменный левый блок и воздух справа.
"""

import datetime

from gi.repository import Gdk, GLib, Gtk

import cairo

from . import config, theme, widgets
from .i18n import _

PANEL_GAP = 40


class LockApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.lgux.Lock")
        self.windows = []

    def do_activate(self):
        if self.windows:
            return
        config.set_locked()
        display = Gdk.Display.get_default()
        for i in range(display.get_n_monitors()):
            win = self.track(LockWindow(self, display.get_monitor(i)))
            self.windows.append(win)
            win.show_all()
        GLib.timeout_add_seconds(1, self._tick)

    def _tick(self):
        alive = False
        for win in self.windows:
            if win.get_realized():
                win._update_clock()
                alive = True
        if not alive:
            config.clear_locked()
            self.quit()
            return False
        return True

    def unlock(self):
        config.clear_locked()
        self.quit()


class LockWindow(Gtk.Window):
    def __init__(self, app, monitor):
        super().__init__()
        self.lock_app = app
        self.monitor = monitor
        self.set_title("LG Lock")
        self.set_type_hint(Gdk.WindowTypeHint.NORMAL)
        self.set_decorated(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(True)
        self.set_can_focus(True)
        widgets.set_rgba(self)
        self.get_style_context().add_class("lg-lock")

        pal = theme.palette()
        css = """
            window.lg-lock {
                background-color: #080607;
            }
            .lg-lock-date {
                color: rgba(255,255,255,0.62);
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 2.2px;
            }
            .lg-clocklabel {
                color: #FFFFFF;
                font-size: 132px;
                font-weight: 200;
                letter-spacing: -3px;
            }
            .lg-tagline {
                color: {accent2};
                font-size: 15px;
                font-style: italic;
                letter-spacing: 0.4px;
            }
            .lg-hintlabel {
                color: rgba(255,255,255,0.42);
                font-size: 12px;
            }
            .lg-lock-brand {
                color: rgba(255,255,255,0.90);
                font-size: 13px;
                font-weight: 800;
                letter-spacing: 1.6px;
            }
            .lg-lock-life {
                color: rgba(255,255,255,0.38);
                font-size: 11px;
                font-style: italic;
            }
            .lg-unlockbtn {
                background-color: transparent;
                color: #FFFFFF;
                border: 1.5px solid {accent};
                border-radius: 24px;
                padding: 12px 38px;
                font-size: 14px;
                font-weight: 600;
            }
            .lg-unlockbtn:hover {
                background-color: {accent};
                color: #FFFFFF;
            }
            .lg-unlockbtn:active {
                background-color: {accent2};
                border-color: {accent2};
            }
        """.replace("{accent2}", pal["accent2"]).replace("{accent}", pal["accent"])
        widgets.apply_css_screen(css)

        overlay = Gtk.Overlay()
        self.bg_area = Gtk.DrawingArea()
        self.bg_area.set_hexpand(True)
        self.bg_area.set_vexpand(True)
        self.bg_area.connect("draw", self._draw_bg)
        overlay.add(self.bg_area)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.set_margin_top(46)
        root.set_margin_bottom(36)
        root.set_margin_start(92)
        root.set_margin_end(92)

        # шапка: фирменный блок слева, слоган справа
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
        mark = widgets.IconArea("logo", pal["accent2"], 26)
        head.pack_start(mark, False, False, 0)
        brand = Gtk.Label(label="LG UX")
        brand.get_style_context().add_class("lg-lock-brand")
        head.pack_start(brand, False, False, 0)
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        head.pack_start(spacer, True, True, 0)
        life = Gtk.Label(label="Life's Good")
        life.get_style_context().add_class("lg-lock-life")
        head.pack_end(life, False, False, 0)
        root.pack_start(head, False, False, 0)

        # основной блок: дата, часы, линия, слоган, кнопка
        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        main.set_valign(Gtk.Align.CENTER)
        main.set_halign(Gtk.Align.START)

        self.date = Gtk.Label()
        self.date.set_halign(Gtk.Align.START)
        self.date.get_style_context().add_class("lg-lock-date")
        main.pack_start(self.date, False, False, 0)

        self.clock = Gtk.Label()
        self.clock.set_halign(Gtk.Align.START)
        self.clock.get_style_context().add_class("lg-clocklabel")
        main.pack_start(self.clock, False, False, 0)

        self.line = Gtk.DrawingArea()
        self.line.set_size_request(72, 4)
        self.line.set_halign(Gtk.Align.START)
        self.line.set_margin_top(2)
        self.line.set_margin_bottom(12)
        self.line.connect("draw", self._draw_line)
        main.pack_start(self.line, False, False, 0)

        tagline = Gtk.Label(label="Life's Good")
        tagline.set_halign(Gtk.Align.START)
        tagline.get_style_context().add_class("lg-tagline")
        main.pack_start(tagline, False, False, 0)

        btn = Gtk.Button(label=_("Разблокировать"))
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_halign(Gtk.Align.START)
        btn.set_margin_top(30)
        btn.get_style_context().add_class("lg-unlockbtn")
        btn.connect("clicked", lambda *_: app.unlock())
        main.pack_start(btn, False, False, 0)

        root.pack_start(main, True, True, 0)

        hint = Gtk.Label(label=_("Нажмите Enter или Esc, чтобы разблокировать"))
        hint.set_halign(Gtk.Align.CENTER)
        hint.get_style_context().add_class("lg-hintlabel")
        root.pack_start(hint, False, False, 0)

        overlay.add_overlay(root)
        self.add(overlay)
        self.connect("key-press-event", self._on_key)
        self.connect("button-press-event", lambda *_: False)
        self._update_clock()

    # ------------------------------------------------------------ графика

    def _draw_bg(self, area, cr):
        alloc = area.get_allocation()
        w = max(1, alloc.width)
        h = max(1, alloc.height)
        pal = theme.palette()
        accent = theme.hex_rgba(pal["accent2"])

        grad = cairo.LinearGradient(0, 0, w * 0.30, h)
        grad.add_color_stop_rgb(0.0, 0.055, 0.039, 0.047)
        grad.add_color_stop_rgb(0.55, 0.031, 0.023, 0.027)
        grad.add_color_stop_rgb(1.0, 0.016, 0.012, 0.015)
        cr.set_source(grad)
        cr.paint()

        # разомкнутое кольцо — знак LG на правой половине сцены
        cx, cy = w * 0.79, h * 0.40
        r = min(w, h) * 0.31
        rg = cairo.RadialGradient(cx, cy, r * 0.55, cx, cy, r * 2.1)
        rg.add_color_stop_rgba(0.0, accent[0], accent[1], accent[2], 0.20)
        rg.add_color_stop_rgba(0.55, accent[0], accent[1], accent[2], 0.07)
        rg.add_color_stop_rgba(1.0, accent[0], accent[1], accent[2], 0.0)
        cr.set_source(rg)
        cr.paint()

        cr.save()
        cr.set_line_width(max(10.0, r * 0.055))
        cr.set_line_cap(cairo.LINE_CAP_ROUND)
        cr.set_source_rgba(accent[0], accent[1], accent[2], 0.62)
        cr.arc(cx, cy, r, -2.60, 0.95)
        cr.stroke()
        cr.set_line_width(max(1.0, r * 0.006))
        cr.set_source_rgba(1, 1, 1, 0.12)
        cr.arc(cx, cy, r * 0.93, -2.60, 0.95)
        cr.stroke()
        # точка в разрыве кольца
        dot_r = r * 0.075
        cr.set_source_rgba(accent[0], accent[1], accent[2], 0.85)
        cr.arc(cx + r * 0.73, cy - r * 0.55, dot_r, 0, 6.2832)
        cr.fill()
        cr.restore()

        # вертикальная линия под кольцом
        cr.set_line_width(1.0)
        cr.set_source_rgba(1, 1, 1, 0.10)
        cr.move_to(cx, cy + r * 1.12)
        cr.line_to(cx, h * 0.90)
        cr.stroke()

        # виньетка
        rg = cairo.RadialGradient(w / 2, h / 2, min(w, h) * 0.32,
                                  w / 2, h / 2, max(w, h) * 0.80)
        rg.add_color_stop_rgba(0.0, 0, 0, 0, 0.0)
        rg.add_color_stop_rgba(1.0, 0, 0, 0, 0.42)
        cr.set_source(rg)
        cr.paint()
        return False

    def _draw_line(self, area, cr):
        pal = theme.palette()
        accent = theme.hex_rgba(pal["accent"])
        cr.set_source_rgba(accent[0], accent[1], accent[2], 0.95)
        theme.round_rect(cr, 0, 0, area.get_allocated_width(),
                         area.get_allocated_height(), 2)
        cr.fill()
        return False

    # ------------------------------------------------------------ события

    def do_show(self):
        Gtk.Window.do_show(self)
        geo = self.monitor.get_geometry() if self.monitor is not None \
            else widgets.primary_geometry()
        widgets.fullscreen_on_geometry(self, geo)
        self.grab_focus()

    def _update_clock(self):
        now = datetime.datetime.now()
        self.clock.set_text(now.strftime("%H:%M"))
        self.date.set_text("%s · %s" % (
            widgets.ru_weekday(now).upper(), widgets.ru_date(now).upper()))

    def _on_key(self, _w, ev):
        if ev.keyval in (Gdk.KEY_Escape, Gdk.KEY_Return, Gdk.KEY_KP_Enter,
                         Gdk.KEY_space):
            self.lock_app.unlock()
            return True
        return False


def main():
    LockApp().run([])


if __name__ == "__main__":
    main()
